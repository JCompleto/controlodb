"""Ponte entre a página do telemóvel (JavaScript) e a aplicação Flask, que corre aqui mesmo, no browser (Pyodide).

Não há servidor: cada clique ou formulário é passado à aplicação como um pedido de teste e a página
mostra o HTML devolvido. A base de dados é um ficheiro em memória que o JavaScript guarda no telemóvel.
"""
from __future__ import annotations

import io
import json
import os
import sys
from urllib.parse import urlsplit

os.environ["CONTROLO_SEM_NAVEGADOR"] = "1"
os.environ["CONTROLO_TELEMOVEL"] = "1"
if "/app" not in sys.path:
    sys.path.insert(0, "/app")

import app as _aplicacao  # noqa: E402  (a aplicação do PC, sem alterações de lógica)
from werkzeug.datastructures import FileStorage, MultiDict  # noqa: E402

APP = _aplicacao.app
CLIENTE = APP.test_client()
PREFIXO = ""  # caminho onde a página está alojada (ex.: «/controlo»)
VERSAO = _aplicacao.VERSAO


def configurar(prefixo: str) -> None:
    global PREFIXO
    PREFIXO = (prefixo or "").rstrip("/")


def abrir_base(caminho: str) -> str:
    """Abre (e, se for de uma versão antiga, atualiza) a base; devolve o nome da empresa."""
    from core.db import get_conn, nome_empresa

    c = get_conn(caminho)
    try:
        nome = nome_empresa(c)
    finally:
        c.close()
    APP.config["DB_PATH"] = caminho
    return nome


def fechar_base() -> None:
    APP.config["DB_PATH"] = None


def criar_demo(caminho: str) -> str:
    from pathlib import Path

    from core import demo

    if os.path.exists(caminho):
        os.remove(caminho)
    nome = demo.criar_demo(Path(caminho))
    return abrir_base(caminho) or nome


def _caminho_local(url: str) -> tuple[str, str]:
    """«https://x/controlo/lancamentos?ano=2026#a» -> («/lancamentos?ano=2026», «a»)."""
    u = urlsplit(url)
    caminho = u.path or "/"
    if PREFIXO and (caminho == PREFIXO or caminho.startswith(PREFIXO + "/")):
        caminho = caminho[len(PREFIXO):] or "/"
    return caminho + ("?" + u.query if u.query else ""), u.fragment


def pedido(metodo: str, url: str, campos=None, ficheiros=None):
    """Faz o pedido à aplicação e segue os redirecionamentos.
    Devolve (meta em JSON, corpo em bytes)."""
    caminho, frag = _caminho_local(url)
    base = "http://localhost" + PREFIXO + "/"
    dados = None
    if metodo.upper() == "POST":
        dados = MultiDict()
        for k, v in (campos.to_py() if hasattr(campos, "to_py") else (campos or [])):
            dados.add(k, v)
        for k, nome, tipo, conteudo in (ficheiros.to_py() if hasattr(ficheiros, "to_py") else (ficheiros or [])):
            corpo = bytes(conteudo) if not isinstance(conteudo, (bytes, bytearray)) else conteudo
            dados.add(k, FileStorage(io.BytesIO(corpo), filename=nome, content_type=tipo or "application/octet-stream"))
    resp = CLIENTE.open(caminho, method=metodo.upper(), data=dados, base_url=base)
    alterou = metodo.upper() == "POST"
    for _ in range(10):
        if resp.status_code not in (301, 302, 303, 307, 308):
            break
        caminho, f2 = _caminho_local(resp.headers.get("Location", "/"))
        frag = f2
        resp = CLIENTE.open(caminho, method="GET", base_url=base)
    disp = resp.headers.get("Content-Disposition", "")
    nome_fich = ""
    if "attachment" in disp and "filename=" in disp:
        nome_fich = disp.split("filename=", 1)[1].split(";")[0].strip().strip('"')
        if "filename*=" in disp:  # nomes com acentos: filename*=UTF-8''...
            from urllib.parse import unquote

            nome_fich = unquote(disp.split("filename*=", 1)[1].split("''", 1)[-1].split(";")[0])
    meta = {"estado": resp.status_code, "caminho": caminho.split("?")[0], "url": caminho, "frag": frag,
            "tipo": resp.headers.get("Content-Type", ""), "ficheiro": nome_fich, "alterou": alterou}
    return json.dumps(meta), resp.get_data()
