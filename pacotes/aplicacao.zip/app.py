"""Controlo Empresa — aplicação web local (Flask + SQLite).

Arranque:  python app.py     (abre http://localhost:5055 no browser)
"""
from __future__ import annotations

import ast
import io
import operator
import os
import re
import sqlite3
import tempfile
import threading
import webbrowser
from datetime import date
from pathlib import Path
from urllib.parse import urlparse

import openpyxl
from flask import Flask, abort, flash, g, redirect, render_template, request, send_file, url_for
from markupsafe import Markup
from openpyxl.styles import Alignment, Font, PatternFill

from core import calc, irs, tabelas
from core.calendario import dias_uteis

VERSAO = "1.9.0"  # MAJOR.MINOR.PATCH: estrutural . alterações médias . pequenas correções
from core.calc import MESES, calcular_mapa, calcular_saldo, carregar_ano, iva_trimestres, r2
from core import bases, contabilidade, demo, previsao, simulacao
from core.db import IMPOSTOS, TIPOS_DESPESA_FIXOS, anos as lista_anos, criar_ano, get_conn, gravar_nome_empresa, iniciais, nome_empresa
from core.importar_excel import importar

app = Flask(__name__)
app.secret_key = os.environ.get("CONTROLO_SECRET", "controlo-empresa-local")
app.config["MAX_CONTENT_LENGTH"] = 25 * 1024 * 1024


# ----------------------------------------------------------------- utilitários
def db() -> sqlite3.Connection:
    """Ligação à base de dados escolhida no arranque (ver /bd)."""
    if "db" not in g:
        caminho = app.config.get("DB_PATH")
        if not caminho:
            abort(redirect(url_for("bd")))
        g.db = get_conn(caminho)
    return g.db


_LOCAL = {"localhost", "127.0.0.1", "::1"}


@app.before_request
def _so_local():
    """Só aceita pedidos feitos ao próprio computador (e, nos POST, vindos de páginas da própria aplicação)."""
    if (urlparse("//" + request.host).hostname or "") not in _LOCAL:
        abort(400)
    if request.method == "POST":
        origem = request.headers.get("Origin") or request.headers.get("Referer")
        if origem and (urlparse(origem).hostname or "") not in _LOCAL:
            abort(403)


ROTAS_SEM_BD = {"bd", "bd_abrir", "bd_nova", "bd_renomear", "bd_fechar", "bd_eliminar", "static"}


@app.before_request
def _exigir_bd():
    """Sem base escolhida, só se vê o ecrã de escolha."""
    if not app.config.get("DB_PATH") and request.endpoint not in ROTAS_SEM_BD:
        return redirect(url_for("bd"))


@app.teardown_appcontext
def _fechar(_exc):
    c = g.pop("db", None)
    if c is not None:
        c.close()


_OPS = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul, ast.Div: operator.truediv}


def _avaliar(no):
    if isinstance(no, ast.Expression):
        return _avaliar(no.body)
    if isinstance(no, ast.Constant) and isinstance(no.value, (int, float)) and not isinstance(no.value, bool):
        return float(no.value)
    if isinstance(no, ast.BinOp) and type(no.op) in _OPS:
        return _OPS[type(no.op)](_avaliar(no.left), _avaliar(no.right))
    if isinstance(no, ast.UnaryOp) and isinstance(no.op, (ast.USub, ast.UAdd)):
        v = _avaliar(no.operand)
        return -v if isinstance(no.op, ast.USub) else v
    if isinstance(no, ast.Call) and isinstance(no.func, ast.Name) and no.func.id.lower() == "round" and 1 <= len(no.args) <= 2 and not no.keywords:
        return r2(_avaliar(no.args[0]))
    raise ValueError("expressão inválida")


def parse_valor(texto) -> float:
    """Aceita '1234,56', '1.234,56', '260*21*1,23', '=ROUND(1800*1.23,2)+50' ..."""
    s = (texto or "").strip().replace("€", "").replace(" ", "")
    if s.startswith("="):
        s = s[1:]
    if not s:
        return 0.0
    if re.search(r"round\s*\(", s, re.I):
        s = s.replace(";", ",")  # em ROUND(x;2) / ROUND(x,2) a vírgula separa argumentos; o decimal é o ponto
    elif "," in s:
        s = s.replace(".", "").replace(",", ".")
    try:
        return r2(_avaliar(ast.parse(s, mode="eval")))
    except (SyntaxError, ValueError, ZeroDivisionError, RecursionError):
        raise ValueError(f"Valor inválido: «{texto}»") from None


def fmt_eur(x, simbolo=True):
    if x is None:
        return "—"
    if abs(x) < 0.005:
        x = 0.0
    s = f"{x:,.2f}".translate(str.maketrans({",": ".", ".": ","}))
    return f"{s} €" if simbolo else s


@app.template_filter("eur")
def _eur(x):
    return fmt_eur(x)


@app.template_filter("numero")
def _f_numero(x):
    return f"{x:,.2f}".rstrip("0").rstrip(".").replace(",", " ").replace(".", ",") if x else "0"


@app.template_filter("num")
def _num(x):
    return fmt_eur(x, simbolo=False)


@app.template_filter("cel")
def _cel(x):
    return "" if x is None or abs(x) < 0.005 else fmt_eur(x, False)


@app.template_filter("pct")
def _pct(x):
    return "—" if x is None else f"{x * 100:.2f}".replace(".", ",") + " %"


@app.template_filter("campo")
def _campo(x):
    """Valor para um <input>: vazio se zero."""
    return "" if x is None or abs(x) < 0.005 else f"{x:.2f}".replace(".", ",")


def ano_pedido() -> int | None:
    anos = lista_anos(db())
    if not anos:
        return None
    a = request.values.get("ano", type=int)
    return a if a in anos else anos[-1]


@app.context_processor
def _contexto():
    base = {"MESES": MESES, "endpoint": request.endpoint, "hoje": date.today().isoformat(),
            "EMPRESA": "", "INICIAIS": "", "DEMO": False, "bd_nome": None, "VERSAO": VERSAO}
    if not app.config.get("DB_PATH") or request.endpoint in ROTAS_SEM_BD:
        return {**base, "anos": [], "ano": None}  # no ecrã de escolha não se mostra nada da base anterior
    base["bd_nome"] = Path(app.config["DB_PATH"]).name
    base["EMPRESA"] = nome_empresa(db())  # guardado na base de dados (Configurações → Empresa)
    base["INICIAIS"] = iniciais(base["EMPRESA"])
    base["DEMO"] = demo.e_demo(db())
    return {**base, "anos": lista_anos(db()), "ano": ano_pedido()}


def exigir_ano() -> int:
    a = ano_pedido()
    if a is None:
        abort(redirect(url_for("config")))
    return a


def voltar(endpoint, ano, **kw):
    return redirect(url_for(endpoint, ano=ano, **kw))


def grafico_barras(receitas: list[float], gastos: list[float]) -> Markup:
    """Gráfico SVG simples: receitas vs gastos por mês."""
    W, H, M, ML, MR = 720, 240, 34, 58, 14
    topo = max(max(receitas + gastos + [1.0]), 1.0)
    passo = 10 ** (len(str(int(topo))) - 1)
    topo = ((int(topo) // passo) + 1) * passo
    larg = (W - ML - MR) / 12
    p = [f'<svg viewBox="0 0 {W} {H}" role="img" aria-label="Receitas e gastos por mês" class="grafico">']
    for i in range(5):
        y = H - M - (H - 2 * M) * i / 4
        p.append(f'<line x1="{ML}" x2="{W - MR}" y1="{y:.1f}" y2="{y:.1f}" class="g-eixo"/>')
        p.append(f'<text x="{ML - 6}" y="{y + 4:.1f}" text-anchor="end" class="g-txt">{topo * i / 4:,.0f}</text>'.replace(",", "."))
    for m in range(12):
        x0 = ML + m * larg
        for j, (val, cls) in enumerate(((receitas[m], "g-rec"), (gastos[m], "g-gas"))):
            h = (H - 2 * M) * max(val, 0) / topo
            p.append(
                f'<rect x="{x0 + larg * (0.12 + 0.38 * j):.1f}" y="{H - M - h:.1f}" width="{larg * 0.36:.1f}" height="{max(h, 0):.1f}" rx="3" class="{cls}">'
                f"<title>{MESES[m]} · {'Receitas' if cls == 'g-rec' else 'Gastos'}: {fmt_eur(val)}</title></rect>"
            )
        p.append(f'<text x="{x0 + larg / 2:.1f}" y="{H - M + 16}" text-anchor="middle" class="g-txt">{MESES[m]}</text>')
    p.append("</svg>")
    return Markup("".join(p))


# ----------------------------------------------------------------- painel
def _indicadores_fat(ano, total, base):
    """Média mensal e dias faturados, só com os meses que já têm faturas (não conta os que faltam)."""
    cfg = db().execute("SELECT iva, valor_dia FROM config_ano WHERE ano=?", (ano,)).fetchone()
    por_mes, dias = {}, 0.0
    for r in db().execute(
        "SELECT mes, rubrica, valor, base, quantidade FROM movimento WHERE ano=? AND rubrica IN (%s)" % ",".join("?" * len(RUB_FATURA)),
        (ano, *RUB_FATURA),
    ):
        por_mes[r["mes"]] = por_mes.get(r["mes"], 0.0) + r["valor"]
        if r["quantidade"]:
            dias += r["quantidade"]
        elif r["rubrica"] == "avenca" and r["valor"] > 0 and cfg["valor_dia"]:
            dias += (r["base"] or r["valor"] / (1 + cfg["iva"])) / cfg["valor_dia"]
    n = sum(1 for v in por_mes.values() if v > 0)
    return {"meses": n, "media": total / n if n else 0.0, "media_base": base / n if n else 0.0,
            "dias": round(dias, 2), "dias_mes": round(dias / n, 2) if n else 0.0}


@app.route("/")
def painel():
    ano = exigir_ano()
    s = calcular_saldo(db(), ano)
    mapa = s["mapa"]
    v, tot = mapa["v"], mapa["tot"]
    gastos = [v["receitas"][i] - v["rend_gastos"][i] for i in range(12)]
    iva_ano = tot["iva"]
    fat = {"base": tot["receitas"] - iva_ano, "iva": iva_ano, "total": tot["receitas"]}
    fat.update(_indicadores_fat(ano, fat["total"], fat["base"]))
    todos = construir_itens(ano, "tudo", None, "", "")
    por_pagar = construir_itens(ano, "porpagar", None, "", "")  # do mais antigo para o mais recente
    fechado = ano < date.today().year  # ano já terminado: textos de valores finais em vez de estimativas
    tri = None if fechado else _lucro_trimestre(ano)
    irc_ano = _irc_do_ano(ano, s["imposto"])
    contab = contabilidade.comparar_guardado(db(), ano)
    contab = {"info": contab[0], "rai": (contab[1].get("lucro") or {}).get("rai_ct"), "mes": contab[1]["meses"][-1]} if contab else None
    return render_template(
        "painel.html", s=s, tot=tot, tri=tri, fechado=fechado, irc_ano=irc_ano, contab=contab, grafico=grafico_barras(v["receitas"], gastos), pend=pendentes(por_pagar),
        tot_graf={"receitas": sum(v["receitas"]), "gastos": sum(gastos), "dif": sum(v["receitas"]) - sum(gastos)},
        por_pagar=por_pagar, fat=fat, em_falta=_em_falta(ano), recentes=todos[:6],
        etiqueta=ETIQUETA,
    )


def _irc_do_ano(ano: int, im: dict) -> dict:
    """IRC do ano: pago (se a liquidação final já estiver paga) ou estimado.
    O IRC de um ano = pagamentos por conta + IRC (e tributações autónomas) desse ano. Conta pelo «ano a que respeita»;
    os lançamentos sem esse dado (os importados do Excel) contam no ano em que estão, como no Excel."""
    linhas = [dict(r) for r in db().execute(
        "SELECT ano, mes, rubrica, valor, pago, data_pagamento FROM movimento WHERE rubrica IN ('irc','ta','pag_conta') "
        "AND COALESCE(ano_ref, ano)=? ORDER BY ano, mes", (ano,))]
    final_pago = any(l["rubrica"] == "irc" and l["pago"] for l in linhas)
    total = sum(l["valor"] for l in linhas if l["pago"])
    valor = total if final_pago else im["irc_est"]
    apos = im["lucro"] - valor
    nomes = {"irc": "IRC", "ta": "Tributações autónomas", "pag_conta": "Pagamento por conta"}
    return {"pago": final_pago, "valor": valor, "apos": apos, "liquido": max(0.0, apos) * (1 - im["div_taxa"]),
            "linhas": [{**l, "nome": nomes[l["rubrica"]]} for l in linhas if l["pago"]]}


def _lucro_trimestre(ano: int) -> dict | None:
    """Lucro (antes de impostos) até ao fim do último trimestre já terminado: é o que se confronta com o Mapa de Exploração."""
    hoje_d = date.today()
    t = 4 if ano < hoje_d.year else (max([q for q in range(1, 5) if q * 3 < hoje_d.month], default=0) if ano == hoje_d.year else 0)
    if not t:
        return None
    from core import simulacao

    r = simulacao._lucro_imposto(db(), ano, t * 3 - 1, {})
    ultimo_dia = {3: "31 mar", 6: "30 jun", 9: "30 set", 12: "31 dez"}[t * 3]
    return {"t": t, "ate": ultimo_dia, "lucro": r["lucro"], "iva_pendente": t in r["iva_pendentes"]}


def _em_falta(ano: int) -> list[dict]:
    """Lançamentos do mês anterior (avença, salário, contabilista) que ainda não existem neste mês."""
    hoje_d = date.today()
    if hoje_d.year != ano:
        return []
    m = hoje_d.month
    a0, m0 = (ano, m - 1) if m > 1 else (ano - 1, 12)

    def tem(a, mm, rub):
        return db().execute("SELECT 1 FROM movimento WHERE ano=? AND mes=? AND rubrica=?", (a, mm, rub)).fetchone() is not None

    out = []
    for rub, tipo, nome in (("avenca", "fatura", "Fatura da avença"), ("vencimento", "salario", "Salário"), ("contabilista", "custo", "Contabilista")):
        if tem(a0, m0, rub) and not tem(ano, m, rub):
            out.append({"nome": f"{nome} de {MESES[m - 1]}",
                        "url": url_for("lancamento_form", tipo=tipo, ano=ano, mes=m, rubrica=None if tipo == "salario" else rub)})
    return out


# ----------------------------------------------------------------- mapa mensal
@app.route("/mapa")
def mapa():
    ano = exigir_ano()
    d = carregar_ano(db(), ano)
    return render_template("mapa.html", m=calcular_mapa(d))


XLSX_MIME = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
_NUM = '#,##0.00;[Red]-#,##0.00'


def _cabecalho_xlsx(ws):
    for c in ws[1]:
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor="2F4858")
        c.alignment = Alignment(horizontal="center")
    ws.freeze_panes = "A2"


def _folha_mapa(wb, ano: int, first: bool = False):
    m = calcular_mapa(carregar_ano(db(), ano))
    ws = wb.active if first else wb.create_sheet()
    ws.title = str(ano)
    ws.append(["Rubricas", *MESES, "Total"])
    _cabecalho_xlsx(ws)
    for l in m["linhas"]:
        if l["tipo"] == "cabecalho":
            ws.append([l["nome"]])
            ws.cell(ws.max_row, 1).font = Font(bold=True)
            continue
        ws.append([l["nome"], *[round(x, 2) for x in l["valores"]], round(l["total"], 2)])
        if l["tipo"] in ("total", "destaque"):
            for c in ws[ws.max_row]:
                c.font = Font(bold=True)
    for row in ws.iter_rows(min_row=2, min_col=2, max_col=14):
        for c in row:
            c.number_format = _NUM
    ws.column_dimensions["A"].width = 38
    for col in "BCDEFGHIJKLMN":
        ws.column_dimensions[col].width = 12
    ws.freeze_panes = "B2"


def _enviar_xlsx(wb, nome: str):
    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return send_file(buf, as_attachment=True, download_name=nome, mimetype=XLSX_MIME)


@app.route("/mapa.xlsx")
def mapa_xlsx():
    ano = exigir_ano()
    wb = openpyxl.Workbook()
    _folha_mapa(wb, ano, first=True)
    return _enviar_xlsx(wb, f"mapa_{ano}.xlsx")


@app.route("/exportar.xlsx")
def exportar_xlsx():
    """O Excel «Controlo Empresa.xlsx» com a estrutura de sempre, preenchido com os dados atuais."""
    from core.exportar_excel import MODELO, exportar
    if not lista_anos(db()):
        abort(404)
    if not MODELO.exists():  # a versão telemóvel não leva o modelo (é uma cópia do Excel com dados da empresa)
        flash("A exportação para o Excel «Controlo Empresa» só está disponível na app do PC. Aqui pode exportar o mapa mensal.", "info")
        return redirect(request.referrer or url_for("lancamentos", ano=ano_pedido()))
    buf = io.BytesIO(exportar(db()))
    return send_file(buf, as_attachment=True, download_name=f"Controlo Empresa {date.today().isoformat()}.xlsx", mimetype=XLSX_MIME)


def _ler_despesa(f):
    data = (f.get("data") or "").strip()
    date.fromisoformat(data)  # valida
    tipo = (f.get("tipo") or "").strip()
    if not tipo:
        raise ValueError("Escolha o tipo de despesa.")
    return (data, parse_valor(f.get("valor")), (f.get("descricao") or "").strip() or None, tipo,
            (f.get("meio") or "").strip() or None, (f.get("notas") or "").strip() or None)


# ----------------------------------------------------------------- lançamentos (diário)
TIPOS_LANC = [
    ("fatura", "Fatura emitida", "Avença, extra, prémio…"),
    ("salario", "Salário do mês", "Vencimento, subsídios, kms…"),
    ("custo", "Custo da empresa", "Contabilista, renda, carro…"),
    ("imposto", "Imposto", "IRC, TA, IES, pagamento por conta"),
    ("despesa", "Despesa avulsa", "Restauração, combustível…"),
]
TIPOS_VALIDOS = {t[0] for t in TIPOS_LANC} | {"iva"}  # o IVA só se edita (os trimestres existem sempre)
FILTROS = [("tudo", "Tudo"), ("porpagar", "Por pagar / receber"), ("faturas", "Faturas"), ("salarios", "Salários"),
           ("custos", "Custos"), ("impostos", "Impostos e IVA"), ("despesas", "Despesas")]
KINDS_DE_FILTRO = {"faturas": {"fatura"}, "salarios": {"salario"}, "custos": {"custo"}, "impostos": {"imposto", "iva"},
                   "despesas": {"despesa"}}
TIPO_NOVO_DE_FILTRO = {"faturas": "fatura", "salarios": "salario", "custos": "custo", "impostos": "imposto", "despesas": "despesa"}
RUB_FATURA = ["avenca", "extra", "premio", "isento"]
RUB_SALARIO = calc.SALARIO_ENTRADAS + ["irs"]
RUB_CUSTO = ["contabilista", "man_conta", "custos_banc", "renda", "carro", "outras", "luz", "mcontab_conta", "fct", "fgct"]
RUB_IMPOSTO = IMPOSTOS
ETIQUETA = {"fatura": "Fatura", "salario": "Salário", "custo": "Custo", "imposto": "Imposto", "iva": "IVA", "despesa": "Despesa"}
# (texto quando já foi, texto quando ainda não foi) — o que importa é se o dinheiro já entrou/saiu da conta
ROTULOS_ESTADO = {
    "fatura": ("Recebido", "Por receber"), "custo": ("Pago", "Por pagar"), "imposto": ("Pago", "Por pagar"),
    "iva": ("Pago", "Por pagar"), "despesa": ("Retirada", "Por retirar"),
}
ROTULOS_DESPESA = {"socio": ("Reembolsada ao sócio", "Por reembolsar ao sócio"), "empresa": ("Paga pela empresa", "Por pagar")}
ROTULOS_RENDA = {"unico": ("Pago", "Por pagar"), "senhorio": ("Renda paga", "Renda por pagar"),
                 "retencao": ("Retenção paga", "Retenção por pagar")}
PAGO_POR = [("socio", "Paguei eu (sócio)"), ("empresa", "Pagou a empresa")]
ROTULOS_SALARIO = {"liquido": ("Líquido pago", "Líquido por pagar"), "estado": ("SS + IRS pagos", "SS + IRS por pagar")}
ENTRADAS = {"fatura"}  # tudo o resto é dinheiro que sai


def _kind_de_rubrica(rubrica: str) -> str:
    if rubrica in RUB_FATURA:
        return "fatura"
    if rubrica in RUB_SALARIO:
        return "salario"
    if rubrica in RUB_IMPOSTO:
        return "imposto"
    return "custo"


def _nomes_rubricas() -> dict[str, str]:
    return {r["codigo"]: r["nome"] for r in db().execute("SELECT codigo, nome FROM rubrica")}


def _cfg(ano: int) -> dict:
    return dict(db().execute("SELECT * FROM config_ano WHERE ano=?", (ano,)).fetchone())


def _qtd(x: float) -> str:
    return f"{x:g}".replace(".", ",")


def _estado(kind: str, valor: float, pago, data, parte: str = "unico", rot: tuple | None = None) -> dict:
    sim, nao = rot or (ROTULOS_SALARIO[parte] if kind == "salario" else ROTULOS_ESTADO[kind])
    return {"parte": parte, "sim": sim, "nao": nao, "pago": bool(pago), "data": data or None, "valor": valor}


def _trimestre_terminado(ano: int, t: int) -> bool:
    hoje_d = date.today()
    return ano < hoje_d.year or (ano == hoje_d.year and t * 3 < hoje_d.month)


def construir_itens(ano: int, filtro: str, mes: "int | list | None", rubrica: str, tdesp: str, est: str = "") -> list[dict]:
    """Junta num só diário os lançamentos do mapa, os impostos, o IVA trimestral e as despesas avulsas.
    Cada item traz o seu `estado` (já pago/recebido ou não)."""
    con = db()
    meses = [mes] if isinstance(mes, int) else sorted(mes or [])  # um ou vários meses; vazio = ano todo
    nomes = _nomes_rubricas()
    cfg = _cfg(ano)
    k_iva = 1 + cfg["iva"]
    itens: list[dict] = []
    kinds = KINDS_DE_FILTRO.get(filtro)  # None = todos

    def quer(kind: str) -> bool:
        return kinds is None or kind in kinds

    d = mapa = None

    def mapa_ano():
        nonlocal d, mapa
        if mapa is None:
            d = carregar_ano(con, ano)
            mapa = calcular_mapa(d)
        return d, mapa

    # --- movimentos (faturas, custos, impostos, salários)
    if filtro != "despesas" and not tdesp:
        sql, par = "SELECT * FROM movimento WHERE ano=?", [ano]
        if meses:
            sql += f" AND mes IN ({','.join('?' * len(meses))})"
            par += meses
        if rubrica:
            sql += " AND rubrica=?"
            par.append(rubrica)
        salarios: dict[int, list] = {}
        for r in con.execute(sql + " ORDER BY mes, COALESCE(data,''), id", par):
            kind = _kind_de_rubrica(r["rubrica"])
            if not quer(kind):
                continue
            if kind == "salario":
                salarios.setdefault(r["mes"], []).append(r)
                continue
            if kind == "fatura":
                base = r["base"]
                if base is None:
                    base = r["valor"] if r["rubrica"] == "isento" else r["valor"] / k_iva
                iva = r["valor"] - base
                if r["quantidade"]:
                    det = f"{_qtd(r['quantidade'])} dias × {fmt_eur(r['preco_unit'])} = {fmt_eur(base)}"
                else:
                    det = f"s/ IVA {fmt_eur(base)}"
                det += f" · IVA {fmt_eur(iva)}" if abs(iva) > 0.004 else " · sem IVA"
                titulo = nomes[r["rubrica"]] + (f" · {r['cliente']}" if r["cliente"] else "")
            else:
                titulo = nomes[r["rubrica"]] + (f" de {r['ano_ref']}" if kind == "imposto" and r["ano_ref"] else "") + (f" · {r['descricao']}" if r["descricao"] else "")
                det = ""
            estados = [_estado(kind, r["valor"], r["pago"], r["data_pagamento"])]
            if kind == "custo" and r["retencao"]:  # renda: parte do senhorio + retenção na fonte, cada uma com o seu estado
                liq = r["valor"] - r["retencao"]
                pct = 100 * r["retencao"] / r["valor"] if r["valor"] else 0
                det = (f"Fatura {fmt_eur(r['valor'])} · retenção {_qtd(round(pct, 2))} % = {fmt_eur(r['retencao'])}"
                       f" · a pagar ao senhorio {fmt_eur(liq)} · sem IVA")
                estados = [_estado(kind, liq, r["pago"], r["data_pagamento"], "senhorio", ROTULOS_RENDA["senhorio"]),
                           _estado(kind, r["retencao"], r["retencao_pago"], r["retencao_data"], "retencao", ROTULOS_RENDA["retencao"])]
            itens.append({"kind": kind, "id": r["id"], "mes": r["mes"], "data": r["data"], "titulo": titulo, "detalhe": det,
                          "valor": r["valor"], "rubrica": r["rubrica"], "estado": estados})
        if salarios:
            _, mp = mapa_ano()
            est_sal = {r["mes"]: r for r in con.execute("SELECT * FROM salario_estado WHERE ano=?", (ano,))}
            for m, linhas in salarios.items():
                bruto = sum(l["valor"] for l in linhas if l["rubrica"] != "irs")
                irs_ss = mp["v"]["irs_ss"][m - 1]
                liquido = mp["v"]["total_salario"][m - 1]
                estado_v = mp["v"]["irs"][m - 1] + mp["v"]["ss_empresa"][m - 1] + mp["v"]["ss_colab"][m - 1]
                e = est_sal.get(m)
                itens.append({"kind": "salario", "id": m, "mes": m, "data": None, "titulo": f"Salário de {MESES[m - 1]} {ano}",
                              "detalhe": f"Bruto e subsídios {fmt_eur(bruto)} · IRS+SS retidos {fmt_eur(irs_ss)} · SS empresa {fmt_eur(mp['v']['ss_empresa'][m - 1])}",
                              "valor": liquido, "rubrica": "vencimento",
                              "estado": [_estado("salario", liquido, e and e["liquido_pago"], e and e["liquido_data"], "liquido"),
                                         _estado("salario", estado_v, e and e["estado_pago"], e and e["estado_data"], "estado")]})

    # --- IVA trimestral (existe sempre; o «pago» é o valor entregue ao Estado)
    if quer("iva") and not tdesp and rubrica in ("", "iva"):
        dd, mp = mapa_ano()
        for t in iva_trimestres(dd, mp):
            mes_t = t["trimestre"] * 3
            if meses and mes_t not in meses:
                continue
            if t["pago"] is None and abs(t["estimativa"]) < 0.005:
                continue
            valor = t["pago"] if t["pago"] is not None else t["estimativa"]
            data_p = con.execute("SELECT data_pagamento FROM iva_trimestre WHERE ano=? AND trimestre=?", (ano, t["trimestre"])).fetchone()[0]
            pend = t["pago"] is None and not _trimestre_terminado(ano, t["trimestre"])
            itens.append({"kind": "iva", "id": t["trimestre"], "mes": mes_t, "data": None, "rubrica": "iva",
                          "titulo": f"IVA do {t['trimestre']}.º trimestre",
                          "detalhe": f"Estimativa {fmt_eur(t['estimativa'])}" + (f" · entregue {fmt_eur(t['pago'])}" if t["pago"] is not None else ""),
                          "valor": valor, "futuro": pend, "estado": [_estado("iva", valor, t["pago"] is not None, data_p)]})

    # --- despesas avulsas
    if quer("despesa") and not rubrica:
        sql, par = "SELECT * FROM despesa WHERE strftime('%Y', data)=?", [str(ano)]
        if meses:
            sql += f" AND CAST(strftime('%m', data) AS INTEGER) IN ({','.join('?' * len(meses))})"
            par += meses
        if tdesp:
            sql += " AND tipo=?"
            par.append(tdesp)
        for r in con.execute(sql, par):
            det = (r["tipo"] + (f" · {r['notas']}" if r["notas"] else "")
                   + (" · paga pela empresa" if r["pago_por"] == "empresa" else " · paga pelo sócio"))
            itens.append({"kind": "despesa", "id": r["id"], "mes": int(r["data"][5:7]), "data": r["data"],
                          "titulo": r["descricao"] or r["tipo"], "detalhe": det, "valor": r["valor"], "rubrica": "",
                          "socio": r["pago_por"] != "empresa",
                          "estado": [_estado("despesa", r["valor"], r["pago"], r["data_pagamento"], rot=ROTULOS_DESPESA[r["pago_por"] if r["pago_por"] in ROTULOS_DESPESA else "socio"])]})

    if est == "pago":
        itens = [i for i in itens if all(e["pago"] for e in i["estado"])]
    elif est == "pendente":
        itens = [i for i in itens if any(not e["pago"] for e in i["estado"])]
    if filtro == "porpagar":
        itens = [i for i in itens if not i.get("futuro") and any(not e["pago"] for e in i["estado"])]
    itens.sort(key=lambda i: (i["mes"], i["data"] or "", i["id"]), reverse=(filtro != "porpagar"))
    return itens


def pendentes(itens: list[dict]) -> dict:
    """Quanto falta receber, pagar (a terceiros) e reembolsar ao sócio (só o que ainda não passou pela conta)."""
    receber = pagar = socio = 0.0
    n = 0
    for i in itens:
        if i.get("futuro"):
            continue
        for e in i["estado"]:
            if e["pago"]:
                continue
            n += 1
            if i["kind"] in ENTRADAS:
                receber += e["valor"]
            else:
                if i.get("socio"):
                    socio += e["valor"]  # dívida ao sócio: fica à parte do «a pagar» a terceiros
                else:
                    pagar += e["valor"]
    return {"receber": receber, "pagar": pagar, "n": n, "socio": socio}


def _meses_pedidos() -> list[int]:
    """«mes=3,4,5» (ou só «mes=3») -> [3, 4, 5]; ignora o que não for mês."""
    out = set()
    for t in request.args.get("mes", "").split(","):
        if t.strip().isdigit() and 1 <= int(t) <= 12:
            out.add(int(t))
    return sorted(out)


@app.route("/lancamentos")
def lancamentos():
    ano = exigir_ano()
    filtro = request.args.get("tipo", "tudo")
    if filtro not in dict(FILTROS):
        filtro = "tudo"
    sel = _meses_pedidos()
    mes = ",".join(map(str, sel)) or None  # texto para os links: «3,4,5»
    rubrica = request.args.get("rubrica", "")
    tdesp = request.args.get("tdesp", "")
    est = request.args.get("est", "")
    est = est if est in ("pago", "pendente") else ""
    itens = construir_itens(ano, filtro, sel, rubrica, tdesp, est)
    kinds_f = KINDS_DE_FILTRO.get(filtro)
    rubricas = [(r["codigo"], r["nome"]) for r in db().execute("SELECT codigo, nome FROM rubrica ORDER BY rowid")
                if _kind_de_rubrica(r["codigo"]) not in ("despesa",) and (kinds_f is None or _kind_de_rubrica(r["codigo"]) in kinds_f)]
    totais = {k: sum(i["valor"] for i in itens if i["kind"] == k) for k in ETIQUETA}
    tipos_desp = [r["nome"] for r in db().execute("SELECT nome FROM tipo_despesa ORDER BY rowid")]
    return render_template("lancamentos.html", itens=itens, totais=totais, filtros=FILTROS, filtro=filtro, mes=mes, sel=sel, alternar={m: ",".join(map(str, sorted(set(sel) ^ {m}))) or None for m in range(1, 13)}, rubrica=rubrica,
                           tdesp=tdesp, est=est, rubricas=rubricas, etiqueta=ETIQUETA, nomes=_nomes_rubricas(), tipos_desp=tipos_desp,
                           tipo_novo=TIPO_NOVO_DE_FILTRO.get(filtro, "fatura"), pend=pendentes(itens) if filtro == "porpagar" else None)


@app.route("/lancamentos/novo")
def lancamento_novo_atalho():
    return redirect(url_for("lancamento_form", tipo="fatura", ano=ano_pedido(), mes=request.args.get("mes")))


def _proximo(padrao: str) -> str:
    """Página para onde voltar depois de uma ação (só caminhos da própria aplicação)."""
    p = request.form.get("next", "")
    return p if p.startswith("/") and not p.startswith("//") else padrao


@app.route("/lancamentos/estado/<tipo>/<int:id>", methods=["POST"])
def lancamento_estado(tipo, id):
    """Marca um lançamento como já pago/recebido (ou volta a «por pagar»), com a data em que foi."""
    ano = exigir_ano()
    con = db()
    destino = _proximo(url_for("lancamentos", ano=ano))
    pago = 1 if request.form.get("pago") == "1" else 0
    try:
        data = _data_opcional(request.form, ano) if pago else None
    except ValueError as e:
        flash(f"Não guardei: {e}", "erro")
        return redirect(destino)
    if tipo == "custo" and request.form.get("parte") == "retencao":
        n = con.execute("UPDATE movimento SET retencao_pago=?, retencao_data=? WHERE id=? AND ano=? AND retencao<>0", (pago, data, id, ano)).rowcount
    elif tipo in ("fatura", "custo", "imposto"):
        n = con.execute("UPDATE movimento SET pago=?, data_pagamento=? WHERE id=? AND ano=?", (pago, data, id, ano)).rowcount
    elif tipo == "despesa":
        n = con.execute("UPDATE despesa SET pago=?, data_pagamento=? WHERE id=?", (pago, data, id)).rowcount
    elif tipo == "salario":  # id = mês
        parte = request.form.get("parte")
        if parte not in ("liquido", "estado") or not 1 <= id <= 12:
            abort(400)
        con.execute("INSERT OR IGNORE INTO salario_estado (ano, mes) VALUES (?,?)", (ano, id))
        n = con.execute(f"UPDATE salario_estado SET {parte}_pago=?, {parte}_data=? WHERE ano=? AND mes=?", (pago, data, ano, id)).rowcount
    elif tipo == "iva":  # id = trimestre
        if not 1 <= id <= 4:
            abort(400)
        if pago:
            d = carregar_ano(con, ano)
            est = iva_trimestres(d, calcular_mapa(d))[id - 1]["estimativa"]
            txt_v = (request.form.get("valor") or "").strip()
            try:
                valor_pago = r2(parse_valor(txt_v)) if txt_v else r2(est)
            except ValueError:
                flash("Não guardei: valor do IVA inválido.", "erro")
                return redirect(destino)
            n = con.execute("UPDATE iva_trimestre SET pago=?, data_pagamento=? WHERE ano=? AND trimestre=?",
                            (valor_pago, data, ano, id)).rowcount
        else:
            n = con.execute("UPDATE iva_trimestre SET pago=NULL, data_pagamento=NULL WHERE ano=? AND trimestre=?", (ano, id)).rowcount
    else:
        abort(404)
    if not n:
        abort(404)
    con.commit()
    flash("Estado atualizado.", "ok")
    return redirect(destino)


def _contexto_form(ano: int, tipo: str, valores: dict, editar) -> dict:
    cfg = _cfg(ano)
    nomes = _nomes_rubricas()
    hoje_d = date.today()
    mes_padrao = request.args.get("mes", type=int) or (hoje_d.month if hoje_d.year == ano else 1)
    return {
        "tipo": tipo, "tipos": TIPOS_LANC, "v": valores, "editar": editar, "cfg": cfg, "nomes": nomes,
        "rub_fatura": [(c, nomes[c]) for c in RUB_FATURA], "rub_custo": [(c, nomes[c]) for c in RUB_CUSTO],
        "rub_imposto": [(c, nomes[c]) for c in RUB_IMPOSTO], "mes_padrao": mes_padrao,
        "rotulos": ROTULOS_ESTADO, "rotulos_sal": ROTULOS_SALARIO, "pago_por": PAGO_POR,
        "retencao_padrao": "25",
        "tipos_desp": [r["nome"] for r in db().execute("SELECT nome FROM tipo_despesa ORDER BY rowid")],
        "meios": [r["nome"] for r in db().execute("SELECT nome FROM meio_pagamento ORDER BY rowid")],
        "data_padrao": hoje_d.isoformat() if hoje_d.year == ano else f"{ano}-01-01",
        "anos_ref": list(range(ano, ano - 5, -1)),
        "irs_js": irs.tabela_para_js(ano), "irs_sit": _situacao_irs(),
    }


def _valores_salario(ano: int, mes: int) -> tuple[dict, bool]:
    """Valores do formulário do salário: do próprio mês se existir, senão do último mês lançado."""
    cfg = _cfg(ano)
    con = db()
    linhas = {r["rubrica"]: r for r in con.execute("SELECT * FROM movimento WHERE ano=? AND mes=? AND rubrica IN (%s)" % ",".join("?" * len(RUB_SALARIO)), (ano, mes, *RUB_SALARIO))}
    existe = bool(linhas)
    if not existe:
        ant = con.execute("SELECT ano, mes FROM movimento WHERE rubrica='vencimento' AND (ano<? OR (ano=? AND mes<?)) ORDER BY ano DESC, mes DESC LIMIT 1", (ano, ano, mes)).fetchone()
        if ant:
            linhas = {r["rubrica"]: r for r in con.execute("SELECT * FROM movimento WHERE ano=? AND mes=? AND rubrica IN (%s)" % ",".join("?" * len(RUB_SALARIO)), (ant["ano"], ant["mes"], *RUB_SALARIO))}

    def val(c):
        return linhas[c]["valor"] if c in linhas else 0.0

    def qtd(c, preco):
        if c not in linhas:
            return ""
        q = linhas[c]["quantidade"]
        if not q and preco:
            q = round(linhas[c]["valor"] / preco, 2)
        return _qtd(q) if q else ""

    v = {"mes": mes, "vencimento": _campo(val("vencimento")), "isencao": _campo(val("isencao")),
         "sub_ferias": _campo(val("sub_ferias")), "sub_natal": _campo(val("sub_natal")), "irs": _campo(val("irs")),
         "dias_alim": qtd("sub_alim", cfg["subs_alim_dia"]) if existe else _qtd(dias_uteis(ano, mes)),
         "kms": qtd("kms", cfg["km_valor"]) if existe else "", "dias_ajudas": qtd("ajudas", cfg["ajuda_custo_dia"]) if existe else ""}
    sf, sn = _subsidios(cfg, mes, val("vencimento"), val("isencao"))  # os subsídios saem sempre da definição do ano
    v["sub_ferias"], v["sub_natal"] = _campo(sf) or "0,00", _campo(sn) or "0,00"
    if not existe:  # salário novo: o IRS sai da tabela oficial (não se copia o do mês anterior)
        c = _irs_tabela(ano, mes, val("vencimento") + val("isencao"), sf + sn)
        if c is not None:
            v["irs"] = _campo(c) or "0,00"
    e = con.execute("SELECT * FROM salario_estado WHERE ano=? AND mes=?", (ano, mes)).fetchone() if existe else None
    if e:
        v.update(liquido_pago="1" if e["liquido_pago"] else "", liquido_data=e["liquido_data"] or "",
                 estado_pago="1" if e["estado_pago"] else "", estado_data=e["estado_data"] or "")
    return v, existe


def _subsidios(cfg: dict, mes: int, vencimento: float, isencao: float) -> tuple[float, float]:
    """Subsídios de férias e de Natal do mês (regra única em core/previsao.py, usada também pelas simulações)."""
    return previsao.subsidios(cfg, mes, vencimento, isencao)


def _irs_tabela(ano: int, mes: int, remuneracao: float, subsidios: float) -> float | None:
    """IRS a reter pela tabela oficial, com a situação guardada em Configurações (None se não houver tabela).
    Os subsídios em duodécimos levam a taxa efetiva do vencimento; por inteiro, retenção autónoma."""
    tab, dep = _situacao_irs()
    if _cfg(ano).get("subs_duodecimos", 1):
        c = irs.calcular(ano, mes, remuneracao, subsidios, tab, dep)
    else:
        c = irs.calcular(ano, mes, remuneracao, 0.0, tab, dep, subsidio_inteiro=subsidios)
    return c["total"] if c else None


def _mes_padrao(ano: int) -> int:
    m = request.args.get("mes", type=int)
    if m and 1 <= m <= 12:
        return m
    hoje_d = date.today()
    return hoje_d.month if hoje_d.year == ano else 1


def _valor_dia_padrao() -> float | None:
    """Último valor por dia da avença: o do último lançamento feito na aplicação ou, senão, o da fórmula do Excel."""
    con = db()
    r = con.execute("SELECT preco_unit FROM movimento WHERE rubrica='avenca' AND preco_unit IS NOT NULL ORDER BY ano DESC, mes DESC, id DESC LIMIT 1").fetchone()
    if r:
        return r["preco_unit"]
    for r in con.execute("SELECT nota FROM movimento WHERE rubrica='avenca' AND nota LIKE 'Excel:%' ORDER BY ano DESC, mes DESC, id DESC"):
        m = re.search(r"\(\s*(\d+(?:\.\d+)?)\s*\*\s*\d+(?:\.\d+)?\s*\)\s*\*\s*1\.23", r["nota"])
        if m:
            return float(m.group(1))
    return None


def _ano_ref_padrao(ano: int, rub: str) -> int:
    """Como no Excel do João: cada imposto lança-se no ano a que respeita (o IRC de 2025 fica nas contas de 2025)."""
    return ano


def _valores_novo(ano: int, tipo: str) -> dict:
    mes = _mes_padrao(ano)
    if tipo == "fatura":
        rub = request.args.get("rubrica", "")
        return {"mes": mes, "rubrica": rub if rub in RUB_FATURA else "avenca", "dias": _qtd(dias_uteis(ano, mes)),
                "valor_dia": _campo(_valor_dia_padrao())}
    if tipo == "imposto":
        rub = request.args.get("rubrica", "") if request.args.get("rubrica", "") in RUB_IMPOSTO else RUB_IMPOSTO[0]
        return {"mes": mes, "rubrica": rub, "ano_ref": _ano_ref_padrao(ano, rub)}
    if tipo == "custo":
        rub = request.args.get("rubrica", "")
        return {"mes": mes, "rubrica": rub} if rub else {"mes": mes}
    if tipo == "despesa":
        return {"pago_por": "socio"}  # normalmente paga pelo sócio, e reembolsada mais tarde
    return {}


def _valores_edicao(ano: int, tipo: str, id: int) -> dict:
    con = db()
    if tipo in ("fatura", "custo", "imposto"):
        r = con.execute("SELECT * FROM movimento WHERE id=? AND ano=?", (id, ano)).fetchone()
        if r is None:
            abort(404)
        base = r["base"]
        if base is None and tipo == "fatura":
            base = r["valor"] if r["rubrica"] == "isento" else r["valor"] / (1 + _cfg(ano)["iva"])
        return {"rubrica": r["rubrica"], "mes": r["mes"], "data": r["data"] or "", "cliente": r["cliente"] or "",
                "modo": "dias" if r["quantidade"] else "valor", "dias": _qtd(r["quantidade"]) if r["quantidade"] else "",
                "valor_dia": _campo(r["preco_unit"]), "base": _campo(round(base, 2)) if base is not None else "",
                "valor": _campo(r["valor"]), "descricao": r["descricao"] or "",
                "pago": "1" if r["pago"] else "", "data_pagamento": r["data_pagamento"] or "",
                "retencao_pct": _qtd(round(100 * r["retencao"] / r["valor"], 2)) if r["retencao"] and r["valor"] else ("0" if r["rubrica"] == "renda" else ""),
                "retencao_pago": "1" if r["retencao_pago"] else "", "retencao_data": r["retencao_data"] or "",
                "ano_ref": r["ano_ref"] or (_ano_ref_padrao(ano, r["rubrica"]) if tipo == "imposto" else "")}
    if tipo == "despesa":
        r = con.execute("SELECT * FROM despesa WHERE id=?", (id,)).fetchone()
        if r is None:
            abort(404)
        return {"data": r["data"], "valor": _campo(r["valor"]), "descricao": r["descricao"] or "", "tipo": r["tipo"],
                "meio": r["meio"] or "", "notas": r["notas"] or "", "pago_por": r["pago_por"] or "socio",
                "pago": "1" if r["pago"] else "", "data_pagamento": r["data_pagamento"] or ""}
    if tipo == "iva":
        if not 1 <= id <= 4:
            abort(404)
        d = carregar_ano(con, ano)
        t = iva_trimestres(d, calcular_mapa(d))[id - 1]
        r = con.execute("SELECT data_pagamento FROM iva_trimestre WHERE ano=? AND trimestre=?", (ano, id)).fetchone()
        return {"trimestre": id, "estimativa": t["estimativa"], "valor": _campo(t["pago"]), "data_pagamento": (r and r[0]) or ""}
    abort(404)


@app.route("/lancamentos/novo/<tipo>", methods=["GET", "POST"])
@app.route("/lancamentos/editar/<tipo>/<int:id>", methods=["GET", "POST"])
def lancamento_form(tipo, id=None):
    ano = exigir_ano()
    if tipo not in TIPOS_VALIDOS or (tipo == "iva" and not id):
        abort(404)
    if request.method == "POST":
        try:
            destino = _guardar(ano, tipo, id)
        except ValueError as e:
            flash(f"Não guardei: {e}", "erro")
            return render_template("lanc_form.html", **_contexto_form(ano, tipo, request.form.to_dict(), id))
        return destino
    if tipo == "salario":
        mes = request.args.get("mes", type=int) or (id if id else None) or _contexto_form(ano, tipo, {}, None)["mes_padrao"]
        valores, existe = _valores_salario(ano, mes)
        # o salário abre sempre por /novo: os separadores de tipo ficam visíveis mesmo com o mês já lançado
        return render_template("lanc_form.html", **_contexto_form(ano, tipo, valores, mes if existe else None), mostrar_tipos=True)
    valores = _valores_edicao(ano, tipo, id) if id else _valores_novo(ano, tipo)
    ctx = _contexto_form(ano, tipo, valores, id)
    if tipo == "iva":
        ctx["tipo_iva"] = valores
    return render_template("lanc_form.html", **ctx)


def _mes_form(f) -> int:
    try:
        m = int(f.get("mes", ""))
    except ValueError:
        raise ValueError("Escolha o mês.") from None
    if not 1 <= m <= 12:
        raise ValueError("Mês inválido.")
    return m


def _data_opcional(f, ano: int, chave="data") -> str | None:
    txt = (f.get(chave) or "").strip()
    if not txt:
        return None
    try:
        date.fromisoformat(txt)
    except ValueError:
        raise ValueError("Data inválida.") from None
    return txt


def _ler_pago(f, chave_pago="pago", chave_data="data_pagamento") -> tuple[int, str | None]:
    pago = 1 if f.get(chave_pago) else 0
    return pago, (_data_opcional(f, 0, chave_data) if pago else None)


def _guardar(ano: int, tipo: str, id):
    f = request.form
    con = db()
    cfg = _cfg(ano)
    alvo_mes = None
    ano_ref = None
    if tipo == "iva":
        txt = (f.get("valor") or "").strip()
        pago = r2(parse_valor(txt)) if txt else None
        data = _data_opcional(f, ano, "data_pagamento") if pago is not None else None
        con.execute("UPDATE iva_trimestre SET pago=?, data_pagamento=? WHERE ano=? AND trimestre=?", (pago, data, ano, id))
        con.commit()
        flash("IVA guardado." if pago is not None else "IVA marcado como por pagar.", "ok")
        return redirect(url_for("lancamentos", ano=ano, tipo="tudo", mes=id * 3))
    if tipo == "fatura":
        rub = f.get("rubrica", "")
        if rub not in RUB_FATURA:
            raise ValueError("Escolha o tipo de fatura.")
        mes = _mes_form(f)
        if f.get("modo") == "dias":
            dias, vd = parse_valor(f.get("dias")), parse_valor(f.get("valor_dia"))
            if dias <= 0 or vd <= 0:
                raise ValueError("Indique os dias e o valor por dia.")
            base = r2(dias * vd)
        else:
            dias = vd = None
            base = parse_valor(f.get("base"))
            if base == 0:
                raise ValueError("Indique o valor da fatura.")
        valor = base if rub == "isento" else r2(base * (1 + cfg["iva"]))
        campos = (ano, mes, rub, valor, None, None, _data_opcional(f, ano), (f.get("cliente") or "").strip() or None, dias, vd, base, *_ler_pago(f), 0, 0, None)
        alvo_mes = mes
    elif tipo == "custo":
        rub = f.get("rubrica", "")
        if rub not in RUB_CUSTO:
            raise ValueError("Escolha a rubrica.")
        mes = _mes_form(f)
        valor = parse_valor(f.get("valor"))
        if valor == 0:
            raise ValueError("Indique o valor.")
        base = None
        retencao, ret_pago = 0.0, (0, None)
        if rub == "renda":  # sem IVA; o senhorio recebe o valor menos a retenção, que se paga à parte ao Estado
            pct = parse_valor(f.get("retencao_pct")) if (f.get("retencao_pct") or "").strip() else 0.0
            if not 0 <= pct < 100:
                raise ValueError("A retenção tem de estar entre 0 e 100 %.")
            retencao = r2(valor * pct / 100)
            ret_pago = _ler_pago(f, "retencao_pago", "retencao_data") if retencao else (0, None)
        elif f.get("sem_iva"):
            base = valor
            valor = r2(valor * (1 + cfg["iva"]))
        campos = (ano, mes, rub, valor, (f.get("descricao") or "").strip() or None, None, _data_opcional(f, ano), None, None, None, base, *_ler_pago(f),
                  retencao, *ret_pago)
        alvo_mes = mes
    elif tipo == "imposto":
        rub = f.get("rubrica", "")
        if rub not in RUB_IMPOSTO:
            raise ValueError("Escolha o imposto.")
        try:
            ano_ref = int(f.get("ano_ref", ""))
        except ValueError:
            raise ValueError("Escolha o ano a que o imposto respeita.") from None
        if not 2000 <= ano_ref <= ano:
            raise ValueError("O ano a que o imposto respeita não pode ser posterior ao ano aberto.")
        valor = parse_valor(f.get("valor"))
        if valor == 0:
            raise ValueError("Indique o valor.")
        data = _data_opcional(f, ano)
        if data:  # o mês do mapa é o da data (limite ou pagamento); pago já no ano seguinte (ex.: IRC em maio) → dezembro
            if int(data[:4]) == ano:
                mes = int(data[5:7])
            elif int(data[:4]) == ano + 1:
                mes = 12
            else:
                raise ValueError(f"A data tem de ser de {ano} ou de {ano + 1} (impostos de {ano} pagos no ano seguinte).")
        else:
            mes = _mes_form(f)  # sem data: mantém o mês que já tinha (ou o mês atual)
        campos = (ano, mes, rub, valor, (f.get("descricao") or "").strip() or None, None, data, None, None, None, None, *_ler_pago(f), 0, 0, None)
        alvo_mes = mes
    elif tipo == "salario":
        mes = _mes_form(f)
        vals = {k: parse_valor(f.get(k)) for k in ("vencimento", "isencao", "dias_alim", "kms", "dias_ajudas", "irs")}
        vals["sub_ferias"], vals["sub_natal"] = _subsidios(cfg, mes, vals["vencimento"], vals["isencao"])
        if not (f.get("irs") or "").strip():  # IRS em branco: calcula pela tabela oficial
            c = _irs_tabela(ano, mes, vals["vencimento"] + vals["isencao"], vals["sub_ferias"] + vals["sub_natal"])
            if c is not None:
                vals["irs"] = c
        if vals["vencimento"] <= 0:
            raise ValueError("Indique o vencimento base.")
        liq = _ler_pago(f, "liquido_pago", "liquido_data")
        est = _ler_pago(f, "estado_pago", "estado_data")
        linhas = [
            ("vencimento", vals["vencimento"], None, None), ("isencao", vals["isencao"], None, None),
            ("sub_ferias", vals["sub_ferias"], None, None), ("sub_natal", vals["sub_natal"], None, None),
            ("sub_alim", r2(vals["dias_alim"] * cfg["subs_alim_dia"]), vals["dias_alim"], cfg["subs_alim_dia"]),
            ("kms", r2(vals["kms"] * cfg["km_valor"]), vals["kms"], cfg["km_valor"]),
            ("ajudas", r2(vals["dias_ajudas"] * cfg["ajuda_custo_dia"]), vals["dias_ajudas"], cfg["ajuda_custo_dia"]),
            ("irs", vals["irs"], None, None),
        ]
        con.execute("DELETE FROM movimento WHERE ano=? AND mes=? AND rubrica IN (%s)" % ",".join("?" * len(RUB_SALARIO)), (ano, mes, *RUB_SALARIO))
        for rub, valor, q, p in linhas:
            if abs(valor) > 0.004:
                con.execute("INSERT INTO movimento (ano, mes, rubrica, valor, quantidade, preco_unit) VALUES (?,?,?,?,?,?)", (ano, mes, rub, valor, q or None, p if q else None))
        con.execute("DELETE FROM salario_estado WHERE ano=? AND mes=?", (ano, mes))
        if liq[0] or est[0]:
            con.execute("INSERT INTO salario_estado (ano, mes, liquido_pago, liquido_data, estado_pago, estado_data) VALUES (?,?,?,?,?,?)",
                        (ano, mes, liq[0], liq[1], est[0], est[1]))
        con.commit()
        flash(f"Salário de {MESES[mes - 1]} guardado.", "ok")
        return _depois(ano, tipo, mes, "salarios")
    elif tipo == "despesa":
        vals = _ler_despesa(f)
        pago, data_pag = _ler_pago(f)
        pago_por = f.get("pago_por") if f.get("pago_por") in ("socio", "empresa") else "socio"
        a = int(vals[0][:4])
        if a not in lista_anos(con):
            raise ValueError(f"O ano {a} ainda não existe (crie-o em Configurações).")
        if id:
            con.execute("UPDATE despesa SET data=?, valor=?, descricao=?, tipo=?, meio=?, notas=?, pago=?, data_pagamento=?, pago_por=? WHERE id=?", (*vals, pago, data_pag, pago_por, id))
        else:
            con.execute("INSERT INTO despesa (data, valor, descricao, tipo, meio, notas, pago, data_pagamento, pago_por) VALUES (?,?,?,?,?,?,?,?,?)", (*vals, pago, data_pag, pago_por))
        con.commit()
        flash("Despesa guardada.", "ok")
        return _depois(a, tipo, int(vals[0][5:7]), "despesas")
    else:
        abort(404)

    if id:
        con.execute("UPDATE movimento SET ano=?, mes=?, rubrica=?, valor=?, descricao=?, nota=?, data=?, cliente=?, quantidade=?, preco_unit=?, base=?, pago=?, data_pagamento=?, retencao=?, retencao_pago=?, retencao_data=?, ano_ref=? WHERE id=?", (*campos, ano_ref, id))
    else:
        con.execute("INSERT INTO movimento (ano, mes, rubrica, valor, descricao, nota, data, cliente, quantidade, preco_unit, base, pago, data_pagamento, retencao, retencao_pago, retencao_data, ano_ref) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", (*campos, ano_ref))
    con.commit()
    flash("Lançamento guardado.", "ok")
    return _depois(ano, tipo, alvo_mes, "tudo")


def _depois(ano, tipo, mes, filtro):
    """«Guardar e novo» volta ao formulário; «Guardar» volta ao diário."""
    if request.form.get("novo"):
        return redirect(url_for("lancamento_form", tipo=tipo, ano=ano, mes=mes))
    return redirect(url_for("lancamentos", ano=ano, tipo="tudo", mes=mes or None))


@app.route("/lancamentos/apagar/<tipo>/<int:id>", methods=["POST"])
def lancamento_apagar(tipo, id):
    ano = exigir_ano()
    con = db()
    if tipo in ("fatura", "custo", "imposto"):
        con.execute("DELETE FROM movimento WHERE id=? AND ano=?", (id, ano))
    elif tipo == "salario":  # id = mês
        con.execute("DELETE FROM movimento WHERE ano=? AND mes=? AND rubrica IN (%s)" % ",".join("?" * len(RUB_SALARIO)), (ano, id, *RUB_SALARIO))
        con.execute("DELETE FROM salario_estado WHERE ano=? AND mes=?", (ano, id))
    elif tipo == "despesa":
        con.execute("DELETE FROM despesa WHERE id=?", (id,))
    elif tipo == "iva":  # os trimestres não se apagam; limpa-se o pagamento
        con.execute("UPDATE iva_trimestre SET pago=NULL, data_pagamento=NULL WHERE ano=? AND trimestre=?", (ano, id))
    else:
        abort(404)
    con.commit()
    flash("Lançamento apagado." if tipo != "iva" else "Pagamento de IVA retirado.", "ok")
    return redirect(url_for("lancamentos", ano=ano, tipo=request.args.get("voltar", "tudo"), mes=",".join(map(str, _meses_pedidos())) or None))


# atalhos das páginas antigas
@app.route("/despesas")
def despesas():
    return redirect(url_for("lancamentos", ano=ano_pedido(), tipo="despesas"))


@app.route("/pagamentos")
def pagamentos():
    return redirect(url_for("lancamentos", ano=ano_pedido(), tipo="porpagar"))


# ----------------------------------------------------------------- saldo e impostos
@app.route("/saldo")
def saldo():
    ano = exigir_ano()
    s = calcular_saldo(db(), ano)
    return render_template("saldo.html", s=s, nomes_linhas=calc.SALDO_LINHAS)


@app.route("/saldo/iva", methods=["POST"])
def saldo_iva():
    ano = exigir_ano()
    try:
        for t in range(1, 5):
            txt = request.form.get(f"pago_{t}", "").strip()
            pago = parse_valor(txt) if txt else None
            db().execute("UPDATE iva_trimestre SET pago=? WHERE ano=? AND trimestre=?", (pago, ano, t))
        db().commit()
        flash("IVA trimestral guardado.", "ok")
    except ValueError as e:
        db().rollback()
        flash(f"Não guardei: {e}", "erro")
    return voltar("saldo", ano)


# ----------------------------------------------------------------- configurações
CAMPOS_TAXA = [
    ("iva", "IVA", True), ("ss_empresa", "SS Empresa", True), ("ss_colab", "SS Colaborador", True),
    ("irc_taxa", "IRC (estimado)", True), ("dividendos_taxa", "Imposto sobre dividendos", True),
    ("ta_taxa_ajudas", "TA sobre kms + ajudas de custo", True), ("ta_taxa_rest", "TA sobre restauração", True),
    ("ta_taxa_viaturas", "TA sobre viaturas (carro + combustível)", True),
    ("subs_alim_dia", "Subs. alimentação (€/dia)", False), ("km_valor", "Valor por km (€)", False),
    ("ajuda_custo_dia", "Ajuda de custo (€/dia)", False), ("capital_social", "Capital social (€)", False),
    ("valor_dia", "Valor por dia faturado (€)", False),
    ("saldo_inicial_est", "Saldo inicial estimativa (1.º ano)", False), ("saldo_inicial_real", "Saldo inicial real (1.º ano)", False),
]


@app.route("/config")
def config():
    ano = ano_pedido()
    cfg = dict(db().execute("SELECT * FROM config_ano WHERE ano=?", (ano,)).fetchone()) if ano else None
    return render_template("config.html", cfg=cfg, campos=CAMPOS_TAXA, db_path=str(app.config["DB_PATH"]), ano_novo=(max(lista_anos(db())) + 1) if ano else date.today().year,
                           vazio=ano is None, v=tabelas.verificar(db(), ano) if ano else None, tipos_desp=_tipos_despesa(),
                           irs_v=_verificar_irs(ano) if ano else None, mapas=contabilidade.listar(db()))


@app.route("/config/mapas", methods=["POST"])
def config_mapas():
    """Carrega um mapa de exploração da contabilidade e guarda-o (fica como referência do ano)."""
    f = request.files.get("ficheiro")
    if not f or not f.filename.lower().endswith((".xlsx", ".xlsm")):
        flash("Escolha o ficheiro Excel (.xlsx ou .xlsm) do mapa de exploração.", "erro")
        return redirect(url_for("config", ano=ano_pedido()) + "#contabilidade")
    with tempfile.NamedTemporaryFile(suffix=".xlsx", delete=False) as tmp:
        f.save(tmp.name)
    try:
        res = contabilidade.guardar(db(), tmp.name, f.filename)
        flash(f"Mapa de {res['ano']} guardado (até {MESES[res['meses'][-1]]}): {res['n_ok']} de {res['n_exatas']} linhas batem certo com a aplicação.", "ok")
        destino = url_for("config", ano=res["ano"]) + "#contabilidade"
    except simulacao.ErroMapa as e:
        flash(f"Não guardei o mapa: {e}", "erro")
        destino = url_for("config", ano=ano_pedido()) + "#contabilidade"
    finally:
        os.unlink(tmp.name)
    return redirect(destino)


@app.route("/config/mapas/apagar", methods=["POST"])
def config_mapas_apagar():
    if contabilidade.apagar(db(), request.form.get("id", type=int) or 0):
        flash("Mapa de exploração apagado.", "ok")
    return redirect(url_for("config", ano=ano_pedido()) + "#contabilidade")


def _situacao_irs() -> tuple[str, int]:
    """Tabela de retenção (I, II ou III) e n.º de dependentes, guardados na base de dados."""
    d = {r[0]: r[1] for r in db().execute("SELECT chave, valor FROM definicao WHERE chave IN ('irs_tabela', 'irs_dependentes')")}
    tab = d.get("irs_tabela") if d.get("irs_tabela") in irs.TABELAS else "I"
    try:
        dep = max(0, int(d.get("irs_dependentes") or 0))
    except ValueError:
        dep = 0
    return tab, dep


def _verificar_irs(ano: int) -> dict:
    """IRS retido em cada salário lançado vs. o que dá a tabela oficial."""
    tab, dep = _situacao_irs()
    d = irs.dados(ano)
    out = {"tem_tabela": d is not None, "tabela": tab, "dependentes": dep, "linhas": [], "dados": d}
    if not d:
        return out
    por_mes: dict[int, dict] = {}
    for r in db().execute("SELECT mes, rubrica, SUM(valor) v FROM movimento WHERE ano=? AND rubrica IN ('vencimento','isencao','sub_ferias','sub_natal','irs') GROUP BY mes, rubrica", (ano,)):
        por_mes.setdefault(r["mes"], {})[r["rubrica"]] = r["v"]
    for mes in sorted(por_mes):
        m = por_mes[mes]
        if not m.get("vencimento"):
            continue
        rem = (m.get("vencimento") or 0) + (m.get("isencao") or 0)
        duo = (m.get("sub_ferias") or 0) + (m.get("sub_natal") or 0)
        c = irs.calcular(ano, mes, rem, duo, tab, dep) if _cfg(ano).get("subs_duodecimos", 1) else irs.calcular(ano, mes, rem, 0.0, tab, dep, subsidio_inteiro=duo)
        lancado = round(m.get("irs") or 0, 2)
        out["linhas"].append({"mes": mes, "rem": rem, "duo": duo, "lancado": lancado, "tabela": c["total"], "ok": abs(lancado - c["total"]) < 0.05,
                              "isento": c["isento"], "ajuste": c["ajuste"] is not None, "escalao": c["escalao"]})
    return out


@app.route("/config/irs", methods=["POST"])
def config_irs():
    tab = request.form.get("irs_tabela", "I")
    try:
        dep = int(request.form.get("irs_dependentes", "0") or 0)
        if tab not in irs.TABELAS or not 0 <= dep <= 20:
            raise ValueError
    except ValueError:
        flash("Não guardei: escolha a tabela e um número de dependentes válido.", "erro")
        return redirect(url_for("config", ano=ano_pedido()) + "#irs")
    for k, v in (("irs_tabela", tab), ("irs_dependentes", str(dep))):
        db().execute("INSERT INTO definicao (chave, valor) VALUES (?, ?) ON CONFLICT(chave) DO UPDATE SET valor=excluded.valor", (k, v))
    db().commit()
    flash("Situação para a retenção de IRS guardada.", "ok")
    return redirect(url_for("config", ano=ano_pedido()) + "#irs")


def _tipos_despesa() -> list[dict]:
    usos = {r[0]: r[1] for r in db().execute("SELECT tipo, COUNT(*) FROM despesa GROUP BY tipo")}
    return [{"nome": r[0], "usos": usos.get(r[0], 0), "fixo": r[0] in TIPOS_DESPESA_FIXOS}
            for r in db().execute("SELECT nome FROM tipo_despesa ORDER BY rowid")]


def _nome_tipo(txt: str) -> str:
    nome = " ".join((txt or "").split())
    if not nome:
        raise ValueError("Escreva o nome do tipo de despesa.")
    if len(nome) > 40:
        raise ValueError("O nome é demasiado comprido (máximo 40 caracteres).")
    return nome


@app.route("/config/tipos/novo", methods=["POST"])
def config_tipo_novo():
    try:
        nome = _nome_tipo(request.form.get("nome"))
        existe = db().execute("SELECT 1 FROM tipo_despesa WHERE lower(nome)=lower(?)", (nome,)).fetchone()
        if existe:
            raise ValueError(f"Já existe o tipo «{nome}».")
        db().execute("INSERT INTO tipo_despesa (nome) VALUES (?)", (nome,))
        db().commit()
        flash(f"Tipo de despesa «{nome}» acrescentado.", "ok")
    except ValueError as e:
        flash(f"Não guardei: {e}", "erro")
    return redirect(url_for("config", ano=ano_pedido()) + "#tipos-despesa")


@app.route("/config/tipos/renomear", methods=["POST"])
def config_tipo_renomear():
    antigo = request.form.get("antigo", "")
    try:
        if antigo in TIPOS_DESPESA_FIXOS:
            raise ValueError(f"«{antigo}» é usado nos cálculos e não pode mudar de nome.")
        if not db().execute("SELECT 1 FROM tipo_despesa WHERE nome=?", (antigo,)).fetchone():
            raise ValueError("Esse tipo já não existe.")
        nome = _nome_tipo(request.form.get("nome"))
        if nome != antigo and db().execute("SELECT 1 FROM tipo_despesa WHERE lower(nome)=lower(?) AND nome<>?", (nome, antigo)).fetchone():
            raise ValueError(f"Já existe o tipo «{nome}».")
        db().execute("UPDATE tipo_despesa SET nome=? WHERE nome=?", (nome, antigo))
        db().execute("UPDATE despesa SET tipo=? WHERE tipo=?", (nome, antigo))  # as despesas antigas acompanham o novo nome
        db().commit()
        flash(f"«{antigo}» passou a chamar-se «{nome}».", "ok")
    except ValueError as e:
        db().rollback()
        flash(f"Não guardei: {e}", "erro")
    return redirect(url_for("config", ano=ano_pedido()) + "#tipos-despesa")


@app.route("/config/tipos/apagar", methods=["POST"])
def config_tipo_apagar():
    nome = request.form.get("nome", "")
    usos = db().execute("SELECT COUNT(*) FROM despesa WHERE tipo=?", (nome,)).fetchone()[0]
    if nome in TIPOS_DESPESA_FIXOS:
        flash(f"«{nome}» é usado nos cálculos e não se pode retirar.", "erro")
    elif usos:
        flash(f"Não retirei «{nome}»: há {usos} despesa(s) com este tipo. Mude-lhes o tipo primeiro, ou dê outro nome a este.", "erro")
    else:
        db().execute("DELETE FROM tipo_despesa WHERE nome=?", (nome,))
        db().commit()
        flash(f"Tipo de despesa «{nome}» retirado.", "ok")
    return redirect(url_for("config", ano=ano_pedido()) + "#tipos-despesa")


@app.route("/verificacoes")
def verificacoes():
    # as Verificações passaram para dentro das Configurações
    return redirect(url_for("config", ano=exigir_ano()) + "#verificacoes")


@app.route("/verificacoes/aplicar", methods=["POST"])
def verificacoes_aplicar():
    ano = exigir_ano()
    campo = request.form.get("campo", "")
    valor = tabelas.valor_oficial(ano, campo)
    if valor is None or campo not in ("irc_taxa", "ss_empresa", "ss_colab", "ta_taxa_viaturas"):
        abort(400)
    db().execute(f"UPDATE config_ano SET {campo}=? WHERE ano=?", (valor, ano))
    db().commit()
    flash("Taxa atualizada para o valor da tabela oficial.", "ok")
    return redirect(url_for("config", ano=ano) + "#verificacoes")


@app.route("/config/empresa", methods=["POST"])
def config_empresa():
    try:
        gravar_nome_empresa(db(), request.form.get("empresa", ""))
        flash("Nome da empresa guardado.", "ok")
    except ValueError as e:
        flash(f"Não guardei: {e}", "erro")
    return redirect(url_for("config", ano=ano_pedido()) + "#empresa")


@app.route("/config/taxas", methods=["POST"])
def config_taxas():
    ano = exigir_ano()
    try:
        vals = {}
        for k, _, pct in CAMPOS_TAXA:
            x = parse_valor(request.form.get(k))
            vals[k] = x / 100 if pct else x
    except ValueError as e:
        flash(f"Não guardei: {e}", "erro")
        return redirect(url_for("config", ano=ano) + "#taxas")
    vals["subs_duodecimos"] = 1 if request.form.get("subs_modo", "duodecimos") == "duodecimos" else 0
    for k, padrao in (("subs_mes_ferias", 6), ("subs_mes_natal", 12)):
        try:
            m = int(request.form.get(k, padrao))
        except ValueError:
            m = padrao
        vals[k] = m if 1 <= m <= 12 else padrao
    sets = ", ".join(f"{k}=?" for k in vals)
    db().execute(f"UPDATE config_ano SET {sets} WHERE ano=?", (*vals.values(), ano))
    db().commit()
    flash("Configuração guardada.", "ok")
    return redirect(url_for("config", ano=ano) + "#taxas")


@app.route("/config/novo-ano", methods=["POST"])
def config_novo_ano():
    try:
        novo = int(request.form.get("novo", ""))
        if not 2000 <= novo <= 2100:
            raise ValueError
    except ValueError:
        flash("Ano inválido.", "erro")
        return redirect(url_for("config") + "#dados")
    criar_ano(db(), novo)
    flash(f"Ano {novo} criado com as taxas do ano anterior.", "ok")
    return voltar("painel", novo)


@app.route("/config/importar", methods=["POST"])
def config_importar():
    f = request.files.get("ficheiro")
    if not f or not f.filename.lower().endswith((".xlsx", ".xlsm")):
        flash("Escolha um ficheiro Excel (.xlsx).", "erro")
        return redirect(url_for("config") + "#dados")
    tem_dados = bool(lista_anos(db()))
    if tem_dados and request.form.get("confirmar") != "sim":
        flash("A base de dados já tem dados. Marque a confirmação para os substituir.", "erro")
        return redirect(url_for("config") + "#dados")
    with tempfile.NamedTemporaryFile(suffix=".xlsx", delete=False) as tmp:
        f.save(tmp.name)
    try:
        rel = importar(tmp.name, db(), substituir=tem_dados)
        flash(f"Importado: anos {', '.join(map(str, rel['anos']))}; {rel['movimentos']} lançamentos, "
              f"{rel['pagamentos']} pagamentos reais e {rel['despesas']} despesas.", "ok")
    except Exception as e:  # noqa: BLE001 - mostrar ao utilizador
        flash(f"Falhou a importação (nada foi alterado): {e}", "erro")
    finally:
        os.unlink(tmp.name)
    return redirect(url_for("painel"))


@app.route("/config/backup")
def config_backup():
    tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
    tmp.close()
    destino = sqlite3.connect(tmp.name)
    db().backup(destino)
    destino.close()
    dados = Path(tmp.name).read_bytes()
    os.unlink(tmp.name)
    return send_file(io.BytesIO(dados), as_attachment=True, download_name=f"controlo_empresa_{date.today().isoformat()}.db",
                     mimetype="application/octet-stream")


# ----------------------------------------------------------------- simulação (mapa de exploração da contabilidade)
@app.route("/simulacao", methods=["GET", "POST"])
def simulacao_view():
    ano = exigir_ano()
    resultado = erro = None
    nome = ""
    if request.method == "POST":
        f = request.files.get("ficheiro")
        if not f or not f.filename.lower().endswith((".xlsx", ".xlsm")):
            erro = "Escolha o ficheiro Excel (.xlsx ou .xlsm) do mapa de exploração."
        else:
            nome = f.filename
            with tempfile.NamedTemporaryFile(suffix=".xlsx", delete=False) as tmp:
                f.save(tmp.name)
            try:
                resultado = simulacao.comparar(db(), simulacao.ler_mapa(tmp.name))
            except simulacao.ErroMapa as e:
                erro = str(e)
            finally:
                os.unlink(tmp.name)
    # Mapa de Exploração: duas opções — usar um mapa guardado (só quando se escolhe) ou carregar um ficheiro sem o guardar
    guardado = None
    pedido = request.args.get("mapa", type=int)
    if resultado is None and not erro and pedido:
        g = contabilidade.comparar_guardado(db(), ano, pedido)
        if g:
            guardado, resultado = g
            nome = guardado["ficheiro"]
    mapas_ano = [m for m in contabilidade.listar(db()) if m["ano"] == ano]
    return render_template("simulacao.html", resultado=resultado, erro=erro, nome_ficheiro=nome, mapa_guardado=guardado,
                           mapas_ano=mapas_ano, origem=("guardado" if guardado else ("ficheiro" if request.method == "POST" else "")),
                           **_simulacoes(ano))


def _num_arg(nome: str, padrao: float | None) -> float | None:
    txt = (request.args.get(nome) or "").strip()
    if not txt:
        return padrao
    try:
        return parse_valor(txt)
    except ValueError:
        return padrao


def _simulacoes(ano: int) -> dict:
    """Separadores «Fim do ano» e «Ordenado» da Simulação (nada é gravado)."""
    tab, dep = _situacao_irs()
    cfg = _cfg(ano)
    metodo = "media" if request.args.get("metodo") == "media" else "mediana"
    base = {"valor_dia": _num_arg("vd", cfg["valor_dia"]), "extra_mes": _num_arg("extra", 0.0) or 0.0,
            "desp_extra_mes": _num_arg("desp_extra", 0.0) or 0.0, "tabela": tab, "dependentes": dep, "metodo": metodo,
            # caixa «incluir despesas avulsas»: ligada por omissão (campo escondido «0» + caixa «1»)
            "com_despesas": "1" in request.args.getlist("desp") if request.args.getlist("desp") else True}
    fim = previsao.prever(db(), ano, **base)
    # ordenado: o atual (último lançado) contra o novo, ambos com a mesma previsão de faturação (sem a despesa extra)
    base_sal = {**base, "desp_extra_mes": 0.0}
    atual = previsao.prever(db(), ano, **base_sal)
    venc_atual = atual["sal_base"]["vencimento"]
    ise_atual = atual["sal_base"]["isencao"]
    proximo = min(12, (atual["m_real"] or 0) + 1) if ano == date.today().year else 1
    try:
        desde = max(1, min(12, int(request.args.get("desde") or proximo)))
    except ValueError:
        desde = proximo
    novo_v = _num_arg("novo", None)
    nova_i = _num_arg("nova_isencao", ise_atual) or 0.0
    novo = None
    if novo_v is not None and novo_v >= 0:
        novo = previsao.prever(db(), ano, **base_sal, salario={"vencimento": novo_v, "isencao": nova_i, "desde": desde})
    # vários níveis de vencimento, para ver a tendência
    niveis = sorted({round(venc_atual, 2), *(round(venc_atual + x, 2) for x in (250, 500, 1000, 1500)), *( [round(novo_v, 2)] if novo_v else [])})
    curva = []
    for nv in niveis:
        r = atual if abs(nv - venc_atual) < 0.005 and abs(nova_i - ise_atual) < 0.005 else previsao.prever(
            db(), ano, **base_sal, salario={"vencimento": nv, "isencao": nova_i, "desde": desde})
        curva.append({"venc": nv, "liquido": r["salario"]["liquido"], "lucro": r["lucro"], "dividendos": r["div_liquido"],
                      "total": r["total_socio"], "atual": abs(nv - venc_atual) < 0.005, "novo": novo_v is not None and abs(nv - novo_v) < 0.005})
    melhor = max(curva, key=lambda c: c["total"]) if curva else None

    def estado_total(r):
        return r["salario"]["estado"] + r["irc_est"] + max(0.0, r["apos_irc"]) * r["div_taxa"]

    sep = request.args.get("sep") or ("mapa" if request.method == "POST" else "")
    return {"fim": fim, "sal_atual": atual, "sal_novo": novo, "venc_atual": venc_atual, "ise_atual": ise_atual, "desde": desde,
            "novo_v": novo_v, "nova_i": nova_i, "curva": curva, "melhor": melhor, "estado_total": estado_total, "metodo": metodo,
            "situacao_irs": (tab, dep), "sep_inicial": sep}


# ----------------------------------------------------------------- escolha da base de dados
@app.route("/bd")
def bd():
    return render_template("bd.html", bases=bases.disponiveis(), pasta_dados=str(bases.PASTA_DADOS),
                           ativa=str(app.config.get("DB_PATH") or ""), trocar=bool(app.config.get("DB_PATH")))


def _ativar(caminho: Path, criada: bool = False):
    try:
        get_conn(caminho).close()  # abre (e migra, se for uma base antiga) já aqui, para dar o erro no ecrã certo
    except sqlite3.Error as e:
        flash(f"Não consegui abrir a base de dados: {e}", "erro")
        return redirect(url_for("bd"))
    app.config["DB_PATH"] = str(caminho)
    bases.lembrar(caminho)
    flash(f"Base de dados «{caminho.name}» {'criada e ' if criada else ''}aberta.", "ok")
    return redirect(url_for("painel"))


@app.route("/bd/abrir", methods=["POST"])
def bd_abrir():
    try:
        caminho = bases.validar_existente(request.form.get("caminho", ""))
    except bases.ErroBase as e:
        flash(str(e), "erro")
        return redirect(url_for("bd"))
    return _ativar(caminho)


@app.route("/bd/renomear", methods=["POST"])
def bd_renomear():
    """Altera o nome da empresa (guardado na base) e/ou o nome do ficheiro."""
    antigo = request.form.get("caminho", "")
    empresa = request.form.get("empresa")
    try:
        if empresa is not None:
            bases.mudar_empresa(antigo, empresa)
        nome = (request.form.get("nome") or "").strip()
        atual = Path(antigo).name
        if not nome or nome in (atual, atual[:-3] if atual.lower().endswith(".db") else atual):
            flash("Nome da empresa guardado.", "ok")
            return redirect(url_for("bd"))
        novo = bases.renomear(antigo, nome)
    except bases.ErroBase as e:
        flash(str(e), "erro")
        return redirect(url_for("bd"))
    ativa = app.config.get("DB_PATH")
    if ativa and Path(ativa).resolve() == Path(antigo).resolve():
        app.config["DB_PATH"] = str(novo)
    flash(f"Nome alterado para «{novo.name}».", "ok")
    return redirect(url_for("bd"))


@app.route("/bd/fechar", methods=["POST"])
def bd_fechar():
    """«Trocar» (depois de confirmado): fecha a base atual e mostra o ecrã de escolha."""
    app.config["DB_PATH"] = None
    return redirect(url_for("bd"))


@app.route("/bd/eliminar", methods=["POST"])
def bd_eliminar():
    """Elimina uma base de demonstração (as bases reais são recusadas)."""
    try:
        p = bases.eliminar_demo(request.form.get("caminho", ""))
    except bases.ErroBase as e:
        flash(str(e), "erro")
        return redirect(url_for("bd"))
    ativa = app.config.get("DB_PATH")
    if ativa and Path(ativa).resolve() == p:
        app.config["DB_PATH"] = None
    flash(f"Base de demonstração «{p.name}» eliminada.", "ok")
    return redirect(url_for("bd"))


@app.route("/bd/nova", methods=["POST"])
def bd_nova():
    """Cria uma base nova: vazia (com o nome da empresa, se indicado) ou com dados de demonstração aleatórios."""
    try:
        caminho = bases.caminho_novo(request.form.get("nome", ""), request.form.get("pasta", ""))
    except bases.ErroBase as e:
        flash(str(e), "erro")
        return redirect(url_for("bd"))
    empresa = (request.form.get("empresa") or "").strip()
    try:
        if request.form.get("demo"):
            demo.criar_demo(caminho, empresa=empresa)
        else:
            conn = get_conn(caminho)
            try:
                if empresa:
                    gravar_nome_empresa(conn, empresa)
            finally:
                conn.close()
    except ValueError as e:
        caminho.unlink(missing_ok=True)
        flash(f"Não criei a base: {e}", "erro")
        return redirect(url_for("bd"))
    except (sqlite3.Error, OSError) as e:
        flash(f"Não consegui criar a base: {e}", "erro")
        return redirect(url_for("bd"))
    return _ativar(caminho, criada=True)


def main():
    porta = int(os.environ.get("CONTROLO_PORT", "5055"))
    if os.environ.get("CONTROLO_DB"):  # quem define a base à partida salta o ecrã de escolha
        app.config["DB_PATH"] = os.environ["CONTROLO_DB"]
    if not os.environ.get("CONTROLO_SEM_NAVEGADOR"):  # o iniciar.bat abre o browser por si
        threading.Timer(1.2, lambda: webbrowser.open(f"http://localhost:{porta}")).start()
    app.run(host="127.0.0.1", port=porta, debug=False)


if __name__ == "__main__":
    main()
