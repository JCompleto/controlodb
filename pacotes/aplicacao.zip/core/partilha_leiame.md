# Controlo Empresa

Aplicação para o controlo de uma pequena empresa (faturas, salário, custos, impostos, IVA e despesas),
em vez de um Excel. Corre no próprio computador, no browser, e guarda tudo num único ficheiro de base de dados.

## Arrancar (Windows)

1. Instale o Python (https://www.python.org/downloads/) e, no instalador, marque «Add python.exe to PATH».
2. Abra o ficheiro `iniciar.bat`. Da primeira vez prepara a aplicação (precisa de Internet, só nessa vez).
3. O browser abre em http://localhost:5055. Para terminar, feche a janela preta.

## Primeiros passos

1. No ecrã de escolha, crie uma **base nova** com o nome da empresa. Para experimentar primeiro, crie uma base de **demonstração** (dados fictícios).
2. Em **Configurações**, crie o **primeiro ano** com os valores iniciais (ver abaixo) e reveja as taxas e valores desse ano (IVA, Segurança Social, IRC, subsídio de alimentação, valor por dia faturado…).
3. Lance tudo em **Lançamentos → + Novo lançamento**: faturas emitidas, salário do mês, custos, impostos e despesas avulsas.
4. Quando o dinheiro entra ou sai da conta, marque o lançamento como **recebido / pago**. Só o que está marcado conta para o saldo «Real».

## Valores iniciais

Ao criar o primeiro ano, a aplicação pede os valores do dia em que começa a usá-la:

- **Data de início**: o ideal é 1 de janeiro.
- **Capital social** da empresa.
- **Dinheiro no banco** nesse dia (o saldo da conta da empresa).
- **Dívida ao sócio** nesse dia, se a empresa lhe devia despesas pagas por ele (pode ficar vazia).

A aplicação soma o capital à parte, por isso guarda como saldo inicial o dinheiro no banco menos o capital. A dívida ao sócio aparece na página «Sócio» e reembolsa-se como as despesas.

O que for de antes e só se pagar ou receber depois (IVA do último trimestre, IRC do ano anterior, faturas por receber) não fica na aplicação. Por isso o primeiro ano é mais certo a começar em janeiro. Nos anos seguintes, o saldo passa sozinho de um ano para o outro.

## O que tem

- **Painel**: o que falta receber e pagar, lucro estimado, próximos prazos (IVA, Segurança Social, retenções), faturação e o ano mês a mês.
- **Lançamentos**: o diário de tudo, com filtros por mês, tipo e estado. Cada lançamento pode ter o PDF da fatura ligado (botão **Ver**).
- **Sócio**: despesas pagas pelo sócio do seu bolso e os reembolsos da empresa.
- **Mapa mensal** e **Saldo e impostos**: os valores mês a mês e a estimativa de IRC e dividendos.
- **Simulação**: compara com o mapa de exploração da contabilidade e simula o fim do ano ou outro ordenado.
- **Cópias de segurança**: automáticas, uma por dia, em `dados/copias` (Configurações → Dados e cópias).

## Faturas em PDF

A aplicação procura as faturas na pasta onde está a pasta da aplicação, organizada por ano › mês › Faturas (e Sócio para as despesas pagas pelo sócio), por exemplo `2026/10 - Outubro/Faturas/Sócio`. Pode escolher outra pasta em Configurações → Dados e cópias.

## Limites desta versão

- Pensada para uma empresa com **um colaborador** (um salário por mês) e **um sócio**.
- As rubricas de receitas e custos são fixas (avença, extra, prémio, isento; contabilista, renda com retenção na fonte, carro…). Os tipos de despesa avulsa são configuráveis.
- «Importar do Excel» só funciona com o Excel original para que foi feita; para começar do zero não é preciso.
- Os valores de impostos são estimativas: confirme sempre com a contabilidade.
