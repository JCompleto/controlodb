"""Exporta a base de dados para o Excel «Controlo Empresa.xlsx», com a mesma estrutura de sempre.

Parte de uma cópia do Excel original (core/modelo_excel.xlsx: folhas por ano, Despesas e Template) e só escreve
nas células de entrada. As fórmulas ficam como estavam; uma célula só é alterada quando o valor da base de dados
for diferente do que a fórmula dá.
"""
from __future__ import annotations

import io
import re
from datetime import date, datetime
from pathlib import Path

import openpyxl

from .calc import calcular_mapa, carregar_ano, linhas_reais
from .importar_excel import GRELHA, SALDO, _norm

MODELO = Path(__file__).with_name("modelo_excel.xlsx")
_SOMA_PURA = re.compile(r"^=\s*[-+]?\d+(?:\.\d+)?(?:\s*[-+]\s*\d+(?:\.\d+)?)*\s*$")


def _definir(ws_f, ws_v, linha: int, coluna: int, novo: float | None, so_constantes: bool = False) -> None:
    """Escreve `novo` na célula, a não ser que ela já dê o mesmo valor (então mantém a fórmula)."""
    cel = ws_f.cell(linha, coluna)
    atual = cel.value
    novo = None if novo is None or abs(novo) < 0.005 else round(float(novo), 2)
    eh_formula = isinstance(atual, str) and atual.startswith("=")
    if eh_formula and so_constantes and not _SOMA_PURA.match(atual):
        return  # fórmula com referências (ex.: =I42): não mexer
    if eh_formula:
        cache = ws_v.cell(linha, coluna).value
        cache = float(cache) if isinstance(cache, (int, float)) else 0.0
        if abs(cache - (novo or 0.0)) < 0.005:
            return
    elif atual is None or isinstance(atual, (int, float)):
        if abs(float(atual or 0.0) - (novo or 0.0)) < 0.005:
            return
    cel.value = novo


def _preencher_ano(conn, ws_f, ws_v, ano: int) -> None:
    d = carregar_ano(conn, ano)
    mapa = calcular_mapa(d)
    cfg = d["cfg"]
    ws_f["B1"].value = ano
    # --- mapa mensal (linhas de entrada)
    for r in range(4, 29):
        cod = GRELHA.get(_norm(ws_f.cell(r, 1).value or ""))
        if not cod or cod not in d["inp"]:
            continue
        for mes in range(1, 13):
            _definir(ws_f, ws_v, r, 1 + mes, d["inp"][cod][mes - 1])
    # --- bloco Saldo
    ls = next(r for r in range(1, ws_f.max_row + 1) if _norm(ws_f.cell(r, 1).value or "") == "saldo")
    for col in (2, 3):
        _definir(ws_f, ws_v, ls + 2, col, cfg["capital_social"], so_constantes=True)
    if not str(ws_f.cell(ls + 3, 2).value or "").startswith("="):
        _definir(ws_f, ws_v, ls + 3, 2, cfg["saldo_inicial_est"])
        _definir(ws_f, ws_v, ls + 3, 3, cfg["saldo_inicial_real"])
    real = linhas_reais(d, mapa)
    for r in range(ls + 4, ls + 25):
        lab = _norm(ws_f.cell(r, 1).value or "")
        if lab.startswith("total receitas"):
            break
        cod = SALDO.get(lab)
        if cod:
            _definir(ws_f, ws_v, r, 3, real.get(cod, 0.0), so_constantes=True)
    # --- IVA trimestral, impostos, taxas
    for r in range(1, ws_f.max_row + 1):
        lab = str(ws_f.cell(r, 6).value or "")
        if lab.startswith("1º Trimestre"):
            for t in range(4):
                _definir(ws_f, ws_v, r + t, 8, d["iva_pago"].get(t + 1))
        n = _norm(lab)
        if n in ("irc", "ta", "ies", "pag. p/ conta"):
            col = {"irc": "irc", "ta": "ta", "ies": "ies", "pag. p/ conta": "pag_conta"}[n]
            _definir(ws_f, ws_v, r, 7, d["imp"][col], so_constantes=True)
        if str(ws_f.cell(r, 8).value or "") == "IRC Estimado" and not str(ws_f.cell(r, 10).value or "").startswith("="):
            ws_f.cell(r, 10).value = cfg["irc_taxa"]
        if str(ws_f.cell(r, 9).value or "") == "Dividendos":
            for rr in range(r + 1, r + 4):
                if isinstance(ws_f.cell(rr, 10).value, (int, float)):
                    ws_f.cell(rr, 10).value = cfg["dividendos_taxa"]
                    break


def _preencher_despesas(conn, ws) -> None:
    linhas = conn.execute("SELECT data, valor, descricao, tipo, notas FROM despesa ORDER BY data, id").fetchall()
    for i, r in enumerate(linhas):
        lin = 2 + i
        ws.cell(lin, 1).value = datetime.strptime(r["data"], "%Y-%m-%d")
        ws.cell(lin, 2).value = r["valor"]
        ws.cell(lin, 3).value = r["descricao"]
        ws.cell(lin, 4).value = r["tipo"]
        ws.cell(lin, 5).value = r["notas"]
    for lin in range(2 + len(linhas), ws.max_row + 1):
        if ws.cell(lin, 1).value is None and ws.cell(lin, 2).value is None:
            continue
        for col in range(1, 6):
            ws.cell(lin, col).value = None
    # lista de tipos (coluna G): acrescenta os que faltam
    existentes = {str(ws.cell(r, 7).value) for r in range(2, 60) if ws.cell(r, 7).value}
    lin = 2
    for (t,) in conn.execute("SELECT nome FROM tipo_despesa ORDER BY rowid"):
        if t not in existentes:
            while ws.cell(lin, 7).value:
                lin += 1
            ws.cell(lin, 7).value = t


def exportar(conn) -> bytes:
    wb_f = openpyxl.load_workbook(MODELO)
    wb_v = openpyxl.load_workbook(MODELO, data_only=True)
    anos = [r[0] for r in conn.execute("SELECT ano FROM config_ano ORDER BY ano")]
    for ano in anos:
        nome = str(ano)
        if nome not in wb_f.sheetnames:  # ano novo: nasce da folha «Template»
            nova = wb_f.copy_worksheet(wb_f["Template"])
            nova.title = nome
            wb_v.copy_worksheet(wb_v["Template"]).title = nome
            if str(ano - 1) in wb_f.sheetnames:
                nova["B40"].value = f"='{ano - 1}'!B60"
                nova["C40"].value = f"='{ano - 1}'!C60"
        _preencher_ano(conn, wb_f[nome], wb_v[nome], ano)
    # folhas dos anos por ordem decrescente, como no original (2026, 2025, 2024, Despesas, Template)
    ordem = sorted((n for n in wb_f.sheetnames if n.isdigit()), key=int, reverse=True)
    resto = [n for n in wb_f.sheetnames if not n.isdigit()]
    wb_f._sheets = [wb_f[n] for n in ordem + resto]
    _preencher_despesas(conn, wb_f["Despesas"])
    wb_f.calculation.fullCalcOnLoad = True
    buf = io.BytesIO()
    wb_f.save(buf)
    return buf.getvalue()
