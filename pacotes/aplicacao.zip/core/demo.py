"""Base de demonstração: empresa fictícia com dados inventados, para mostrar a aplicação sem dados reais.

Cria o ano anterior completo e o ano atual até ao mês corrente: faturas, salários, custos (com renda e retenção),
impostos, IVA trimestral e despesas avulsas. Os valores são aleatórios a cada criação: duas demonstrações nunca são iguais.
"""
from __future__ import annotations

import calendar
import random
import sqlite3
from datetime import date, timedelta
from pathlib import Path

from .calc import calcular_mapa, carregar_ano, iva_trimestres, r2
from .calendario import dias_uteis
from .db import criar_ano, get_conn, gravar_nome_empresa

NOMES_A = ["Atlântico", "Horizonte", "Norte", "Vértice", "Lusitânia", "Prisma", "Alameda", "Farol", "Douro", "Quinta Nova", "Rossio", "Mondego"]
NOMES_B = ["Consultoria", "Digital", "Sistemas", "Engenharia", "Serviços", "Tecnologia", "Projetos", "Software"]
CLIENTES = ["Alfa Indústria, SA", "Beta Sistemas, Lda", "Gama Digital, Lda", "Delta Energia, SA", "Ómega Retalho, SA",
            "Sigma Logística, Lda", "Kappa Seguros, SA", "Zeta Saúde, Lda"]


def nome_aleatorio(rnd: random.Random | None = None) -> str:
    rnd = rnd or random.Random()
    return f"{rnd.choice(NOMES_A)} {rnd.choice(NOMES_B)}, Lda"
DESCR_DESPESA = {
    "Combustível": ["Combustível", "Abastecimento viagem cliente", "Gasóleo"],
    "Restauração": ["Almoço com cliente", "Jantar de equipa", "Refeição em deslocação"],
    "Outras despesas": ["Material de escritório", "Portagens", "Estacionamento", "Livro técnico", "Licença de software"],
}


def _ultimo_dia(ano: int, mes: int) -> date:
    return date(ano, mes, calendar.monthrange(ano, mes)[1])


def _mais(d: date, dias: int, limite: date) -> str | None:
    """Data de pagamento (d + dias), ou None se ainda não chegou."""
    x = d + timedelta(days=dias)
    return x.isoformat() if x <= limite else None


def _mov(conn, ano, mes, rubrica, valor, *, pago_em=None, **extra):
    campos = {"ano": ano, "mes": mes, "rubrica": rubrica, "valor": r2(valor), "pago": 1 if pago_em else 0, "data_pagamento": pago_em, **extra}
    cols = ", ".join(campos)
    conn.execute(f"INSERT INTO movimento ({cols}) VALUES ({', '.join('?' * len(campos))})", list(campos.values()))


def _parametros(rnd: random.Random) -> dict:
    """Características da empresa fictícia (mudam de demonstração para demonstração)."""
    clientes = rnd.sample(CLIENTES, 3)
    return {"valor_dia": float(rnd.randrange(200, 341, 10)), "vencimento": float(rnd.choice([870, 900, 950, 1000, 1100, 1200])),
            "renda": float(rnd.choice([0, 500, 650, 800, 950, 1200])), "contabilista": float(rnd.choice([120, 135, 150, 175, 200])),
            "carro": rnd.random() < 0.7, "p_extra": rnd.uniform(0.15, 0.5), "clientes": clientes,
            "irc": float(rnd.randrange(900, 2600, 50)), "pag_conta": float(rnd.randrange(400, 1000, 50))}


def _preencher_ano(conn: sqlite3.Connection, ano: int, ate_mes: int, hoje: date, rnd: random.Random, par: dict) -> None:
    criar_ano(conn, ano)
    conn.execute("UPDATE config_ano SET irc_taxa=0.15, valor_dia=? WHERE ano=?", (par["valor_dia"], ano))
    cfg = dict(conn.execute("SELECT * FROM config_ano WHERE ano=?", (ano,)).fetchone())
    k_iva = 1 + cfg["iva"]
    for mes in range(1, ate_mes + 1):
        fim = _ultimo_dia(ano, mes)
        # --- faturas: avença por dias úteis e, às vezes, um extra
        dias = dias_uteis(ano, mes) - rnd.choice([0, 0, 0, 1, 2])
        base = r2(dias * cfg["valor_dia"])
        _mov(conn, ano, mes, "avenca", base * k_iva, data=fim.isoformat(), cliente=par["clientes"][0], quantidade=dias,
             preco_unit=cfg["valor_dia"], base=base, pago_em=_mais(fim, rnd.randint(12, 25), hoje))
        if rnd.random() < par["p_extra"]:
            base_x = float(rnd.choice([600, 850, 1200, 1500, 2000]))
            _mov(conn, ano, mes, "extra", base_x * k_iva, data=fim.isoformat(), cliente=rnd.choice(par["clientes"][1:]), base=base_x,
                 pago_em=_mais(fim, rnd.randint(20, 45), hoje))
        # --- salário (com estado de pagamento)
        for rub, valor, q, p in (("vencimento", par["vencimento"], None, None), ("sub_ferias", r2(par["vencimento"] / 12), None, None),
                                 ("sub_natal", r2(par["vencimento"] / 12), None, None),
                                 ("sub_alim", dias * cfg["subs_alim_dia"], dias, cfg["subs_alim_dia"])):
            _mov(conn, ano, mes, rub, valor, quantidade=q, preco_unit=p)
        kms = rnd.choice([0, 0, 120, 240, 310])
        if kms:
            _mov(conn, ano, mes, "kms", kms * cfg["km_valor"], quantidade=kms, preco_unit=cfg["km_valor"])
        liq = _mais(fim, 0, hoje)
        est = _mais(fim, 20, hoje)
        conn.execute("INSERT INTO salario_estado (ano, mes, liquido_pago, liquido_data, estado_pago, estado_data) VALUES (?,?,?,?,?,?)",
                     (ano, mes, 1 if liq else 0, liq, 1 if est else 0, est))
        # --- custos fixos
        _mov(conn, ano, mes, "contabilista", par["contabilista"] * k_iva, base=par["contabilista"], pago_em=_mais(fim, 5, hoje))
        _mov(conn, ano, mes, "custos_banc", rnd.choice([1.04, 2.08, 3.12]), pago_em=fim.isoformat() if fim <= hoje else None)
        if par["renda"]:
            _mov(conn, ano, mes, "renda", par["renda"], retencao=r2(par["renda"] * 0.25), pago_em=_mais(date(ano, mes, 8), 0, hoje),
                 retencao_pago=1 if _mais(fim, 20, hoje) else 0, retencao_data=_mais(fim, 20, hoje))
        if par["carro"] and mes % 2 == 0:
            _mov(conn, ano, mes, "carro", rnd.uniform(250, 450), descricao="Manutenção e seguro", pago_em=_mais(fim, 3, hoje))
        _mov(conn, ano, mes, "outras", rnd.uniform(60, 260), descricao="Telecomunicações e software", pago_em=_mais(fim, 3, hoje))
        # --- despesas avulsas (a maioria paga pelo sócio e reembolsada mais tarde)
        for _ in range(rnd.randint(3, 7)):
            dia = date(ano, mes, rnd.randint(1, fim.day))
            if dia > hoje:
                continue
            tipo = rnd.choices(list(DESCR_DESPESA), weights=[4, 3, 3])[0]
            valor = {"Combustível": rnd.uniform(35, 80), "Restauração": rnd.uniform(9, 45), "Outras despesas": rnd.uniform(4, 60)}[tipo]
            por = "empresa" if rnd.random() < 0.2 else "socio"
            reemb = _mais(fim, 10, hoje) if fim.month != hoje.month or fim.year != hoje.year else None
            conn.execute("INSERT INTO despesa (data, valor, descricao, tipo, meio, notas, pago, data_pagamento, pago_por) VALUES (?,?,?,?,?,?,?,?,?)",
                         (dia.isoformat(), r2(valor), rnd.choice(DESCR_DESPESA[tipo]), tipo, None,
                          None, 1 if reemb else 0, reemb, por))
    # --- impostos do ano anterior pagos neste ano
    for mes, rub, valor in ((5, "irc", par["irc"]), (7, "ies", 80.0), (7, "pag_conta", par["pag_conta"]), (9, "pag_conta", par["pag_conta"]),
                            (12, "pag_conta", par["pag_conta"])):
        if mes <= ate_mes:
            dia = _ultimo_dia(ano, mes) - timedelta(days=10)
            _mov(conn, ano, mes, rub, valor, data=dia.isoformat(), ano_ref=ano if rub == "pag_conta" else ano - 1,
                 pago_em=_mais(dia, 0, hoje))
    conn.commit()
    # --- IVA trimestral: trimestres terminados pagos pelo valor estimado (dia 20 do 2.º mês seguinte)
    d = carregar_ano(conn, ano)
    for t in iva_trimestres(d, calcular_mapa(d)):
        m = t["trimestre"] * 3
        if m > ate_mes:
            continue
        a2, m2 = (ano, m + 2) if m + 2 <= 12 else (ano + 1, m + 2 - 12)
        quando = date(a2, m2, 20)
        if quando <= hoje:
            conn.execute("UPDATE iva_trimestre SET pago=?, data_pagamento=? WHERE ano=? AND trimestre=?",
                         (r2(t["estimativa"]), quando.isoformat(), ano, t["trimestre"]))
    conn.commit()


def criar_demo(caminho: Path, hoje: date | None = None, empresa: str = "") -> str:
    """Cria (num ficheiro novo) uma base de demonstração com dados aleatórios. Devolve o nome da empresa."""
    hoje = hoje or date.today()
    rnd = random.Random()  # sem semente: cada demonstração é diferente
    empresa = " ".join((empresa or "").split()) or nome_aleatorio(rnd)
    par = _parametros(rnd)
    conn = get_conn(caminho)
    try:
        gravar_nome_empresa(conn, empresa)
        conn.execute("INSERT INTO definicao (chave, valor) VALUES ('demo', '1') ON CONFLICT(chave) DO UPDATE SET valor='1'")
        _preencher_ano(conn, hoje.year - 1, 12, hoje, rnd, par)
        _preencher_ano(conn, hoje.year, hoje.month, hoje, rnd, par)
        conn.commit()
    finally:
        conn.close()
    return empresa


def e_demo(conn: sqlite3.Connection) -> bool:
    r = conn.execute("SELECT valor FROM definicao WHERE chave='demo'").fetchone()
    return bool(r and r[0] == "1")
