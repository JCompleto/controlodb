"""Cálculos do mapa mensal, saldo e impostos (replicam as fórmulas do Excel)."""
from __future__ import annotations

import sqlite3
from decimal import ROUND_HALF_UP, Decimal

MESES = ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"]

RECEITAS = ["avenca", "extra", "premio", "isento"]
SALARIO_ENTRADAS = ["vencimento", "isencao", "sub_ferias", "sub_natal", "sub_alim", "kms", "ajudas"]
CUSTOS_ANTES_SS = ["contabilista", "man_conta", "mcontab_conta", "luz", "custos_banc", "renda", "carro", "outras", "irs"]
CUSTOS_FIM = ["fct", "fgct"]

# Linhas do bloco "Saldo" (ordem do Excel). 'receitas' trata-se à parte.
SALDO_LINHAS = [
    ("irc_etc", "IRC, TA, IES, Pag. p/ Conta"),
    ("salario", "Total Custos Salário"),
    ("iva", "IVA"),
    ("contabilista", "Contabilista"),
    ("man_conta", "Man. Conta"),
    ("mcontab_conta", "MContabilidade - Conta"),
    ("luz", "Luz"),
    ("custos_banc", "Custos Bancários Transf."),
    ("renda", "Renda"),
    ("carro", "Carro"),
    ("outras", "Outras despesas"),
    ("irs", "IRS"),
    ("ss_empresa", "SS Empresa"),
    ("ss_colab", "SS Colaborador"),
    ("fct", "FCT"),
    ("fgct", "FGCT"),
    ("retirar", "Total a retirar (despesas de controlo)"),
    ("tesouraria", "Cauções e outros movimentos (não são custo)"),
]
SALDO_CODIGOS_REAL = [("receitas", "Receitas")] + SALDO_LINHAS


def r2(x: float) -> float:
    """ROUND do Excel (meio para cima, afastando de zero)."""
    return float(Decimal(repr(float(x))).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))


def _soma(listas: list[list[float]]) -> list[float]:
    return [sum(v) for v in zip(*listas)] if listas else [0.0] * 12


def carregar_ano(conn: sqlite3.Connection, ano: int) -> dict:
    cfg = conn.execute("SELECT * FROM config_ano WHERE ano=?", (ano,)).fetchone()
    if cfg is None:
        raise KeyError(f"Ano {ano} não existe")
    rubricas = [dict(r) for r in conn.execute("SELECT * FROM rubrica ORDER BY ordem")]
    inp = {r["codigo"]: [0.0] * 12 for r in rubricas}
    for r in conn.execute("SELECT rubrica, mes, SUM(valor) v FROM movimento WHERE ano=? GROUP BY rubrica, mes", (ano,)):
        inp[r["rubrica"]][r["mes"] - 1] = r["v"]
    tipos = [r["nome"] for r in conn.execute("SELECT nome FROM tipo_despesa ORDER BY rowid")]
    desp: dict[str, list[float]] = {t: [0.0] * 12 for t in tipos}
    for r in conn.execute(
        "SELECT tipo, CAST(strftime('%m', data) AS INTEGER) m, SUM(valor) v FROM despesa "
        "WHERE strftime('%Y', data)=? GROUP BY tipo, m",
        (str(ano),),
    ):
        desp.setdefault(r["tipo"], [0.0] * 12)[r["m"] - 1] = r["v"]
    iva_pago = {r["trimestre"]: r["pago"] for r in conn.execute("SELECT * FROM iva_trimestre WHERE ano=?", (ano,))}
    imp = {c: sum(inp[c]) for c in ("irc", "ta", "ies", "pag_conta")}
    # o que já entrou/saiu da conta (estado «pago» de cada lançamento)
    inp_pago = {r["codigo"]: [0.0] * 12 for r in rubricas}
    for r in conn.execute("SELECT rubrica, mes, SUM(valor) v FROM movimento WHERE ano=? AND pago=1 GROUP BY rubrica, mes", (ano,)):
        inp_pago[r["rubrica"]][r["mes"] - 1] = r["v"]
    sal_estado = {r["mes"]: dict(r) for r in conn.execute("SELECT * FROM salario_estado WHERE ano=?", (ano,))}
    desp_pago = conn.execute("SELECT COALESCE(SUM(valor),0) FROM despesa WHERE pago=1 AND strftime('%Y', data)=?", (str(ano),)).fetchone()[0]
    # renda: parte paga ao senhorio (valor − retenção) e retenção entregue ao Estado, cada uma com o seu estado
    renda_pago = conn.execute(
        "SELECT COALESCE(SUM(CASE WHEN pago=1 THEN valor-retencao ELSE 0 END),0)"
        " + COALESCE(SUM(CASE WHEN retencao_pago=1 THEN retencao ELSE 0 END),0) FROM movimento WHERE ano=? AND rubrica='renda'", (ano,)
    ).fetchone()[0]
    ajustes = {r["rubrica"]: r["v"] for r in conn.execute("SELECT rubrica, SUM(valor) v FROM pagamento WHERE ano=? GROUP BY rubrica", (ano,))}
    # tesouraria: líquido do que sai (saídas − entradas); o «real» só com o que já passou pela conta
    tes = {"est": 0.0, "real": 0.0}
    if conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='tesouraria'").fetchone():
        for r in conn.execute("SELECT sentido, valor, pago FROM tesouraria WHERE strftime('%Y', data)=?", (str(ano),)):
            x = r["valor"] if r["sentido"] == "saida" else -r["valor"]
            tes["est"] += x
            if r["pago"]:
                tes["real"] += x
    return {
        "ano": ano, "cfg": dict(cfg), "rubricas": rubricas, "inp": inp, "desp": desp, "iva_pago": iva_pago, "imp": imp,
        "inp_pago": inp_pago, "sal_estado": sal_estado, "desp_pago": desp_pago, "ajustes": ajustes, "renda_pago": renda_pago,
        "tes": tes,
    }


def calcular_mapa(d: dict) -> dict:
    """Devolve {'linhas': [...], 'v': {codigo: [12 valores]}, 'tot': {codigo: total}}."""
    cfg, inp = d["cfg"], d["inp"]
    nome = {r["codigo"]: r["nome"] for r in d["rubricas"]}
    opcional = {r["codigo"] for r in d["rubricas"] if r["opcional"]}
    v: dict[str, list[float]] = {k: list(x) for k, x in inp.items()}

    base_ss = _soma([v["vencimento"], v["isencao"], v["sub_ferias"], v["sub_natal"]])
    v["ss_empresa"] = [r2(b * cfg["ss_empresa"]) for b in base_ss]
    v["ss_colab"] = [r2(b * cfg["ss_colab"]) for b in base_ss]
    v["irs_ss"] = [-(v["irs"][i] + v["ss_colab"][i]) for i in range(12)]
    v["total_salario"] = _soma([v[c] for c in SALARIO_ENTRADAS] + [v["irs_ss"]])
    k = 1 + cfg["iva"]
    v["iva"] = [
        r2((v["avenca"][i] + v["extra"][i] + v["premio"][i]) - v["avenca"][i] / k - v["extra"][i] / k - v["premio"][i] / k)
        for i in range(12)
    ]
    custos = CUSTOS_ANTES_SS + ["ss_empresa", "ss_colab"] + CUSTOS_FIM
    receitas = _soma([v[c] for c in RECEITAS])
    gastos = _soma([v["total_salario"], v["iva"]] + [v[c] for c in custos])
    v["receitas"] = receitas
    v["rend_gastos"] = [receitas[i] - gastos[i] for i in range(12)]
    desp_linhas = []
    for t, vals in d["desp"].items():
        v[f"desp:{t}"] = vals
        desp_linhas.append(f"desp:{t}")
    tot_desp = _soma([v[c] for c in desp_linhas]) if desp_linhas else [0.0] * 12
    v["total_desp"] = tot_desp
    v["rend_gastos_desp"] = [v["rend_gastos"][i] - tot_desp[i] for i in range(12)]

    def todos_zero(c):
        return all(abs(x) < 0.005 for x in v[c])

    linhas: list[dict] = []

    def add(codigo, label, tipo):
        vals = v[codigo]
        linhas.append({"codigo": codigo, "nome": label, "tipo": tipo, "valores": vals, "total": sum(vals)})

    for c in RECEITAS:
        add(c, nome[c], "entrada")
    for c in SALARIO_ENTRADAS:
        add(c, nome[c], "entrada")
    add("irs_ss", "IRS+SS", "calculo")
    add("total_salario", "Total Custos Salário", "total")
    add("iva", "IVA", "calculo")
    for c in CUSTOS_ANTES_SS:
        if c in opcional and todos_zero(c):
            continue
        add(c, nome[c], "entrada")
    add("ss_empresa", "SS Empresa", "calculo")
    add("ss_colab", "SS Colaborador", "calculo")
    for c in CUSTOS_FIM:
        add(c, nome[c], "entrada")
    add("rend_gastos", "Rendimentos - Gastos", "destaque")
    linhas.append({"codigo": "", "nome": "Despesas para controlo", "tipo": "cabecalho", "valores": None, "total": None})
    for c in desp_linhas:
        add(c, c.split(":", 1)[1], "despesa")
    add("rend_gastos_desp", "Rendimentos - Gastos - Despesas", "destaque")

    tot = {k: sum(x) for k, x in v.items()}
    return {"linhas": linhas, "v": v, "tot": tot, "desp_codigos": desp_linhas}


def iva_trimestres(d: dict, mapa: dict) -> list[dict]:
    iva = mapa["v"]["iva"]
    out = []
    for t in range(1, 5):
        est = sum(iva[(t - 1) * 3 : t * 3])
        pago = d["iva_pago"].get(t)
        # Sem pagamento registado (trimestre por pagar) não há diferença a contar.
        out.append({"trimestre": t, "estimativa": est, "pago": pago, "devolvido": (est - pago) if pago is not None else 0.0})
    return out


def linhas_reais(d: dict, mapa: dict) -> dict[str, float]:
    """Linhas do saldo «Real»: só o que já entrou/saiu da conta."""
    v, pago = mapa["v"], d["inp_pago"]
    se = d["sal_estado"]
    meses_liq = [m - 1 for m, e in se.items() if e["liquido_pago"]]
    meses_est = [m - 1 for m, e in se.items() if e["estado_pago"]]
    real = {
        "receitas": sum(sum(pago[c]) for c in RECEITAS),
        "irc_etc": sum(sum(pago[c]) for c in ("irc", "ta", "ies", "pag_conta")),
        "salario": sum(v["total_salario"][m] for m in meses_liq),
        # IVA dos trimestres já pagos (estimativa); a diferença para o valor pago entra em «IVA ganho»
        "iva": sum(sum(v["iva"][(t - 1) * 3 : t * 3]) for t, x in d["iva_pago"].items() if x is not None),
        "retirar": d["desp_pago"],
        "tesouraria": d.get("tes", {}).get("real", 0.0),
    }
    for c in CUSTOS_ANTES_SS + CUSTOS_FIM:
        if c == "irs":
            continue
        real[c] = d["renda_pago"] if c == "renda" else sum(pago[c])
    for c in ("irs", "ss_empresa", "ss_colab"):
        real[c] = sum(v[c][m] for m in meses_est)
    for c, x in d["ajustes"].items():
        real[c] = real.get(c, 0.0) + x
    return real


def tributacoes_autonomas(v: dict, cfg: dict, n: int = 12) -> dict:
    """Tributações autónomas estimadas (art.º 88.º CIRC) nos primeiros `n` meses, por categoria:
    representação = despesas de «Restauração» × taxa de restauração (10 %);
    viaturas = custos do «Carro» + despesas de «Combustível» × taxa de viaturas (8 % / 25 % / 32 % pelo custo de aquisição);
    deslocações = kms em viatura própria + ajudas de custo × taxa de ajudas (5 %)."""
    z = [0.0] * 12
    base_repr = sum(v.get("desp:Restauração", z)[:n])
    base_viat = sum(v.get("carro", z)[:n]) + sum(v.get("desp:Combustível", z)[:n])
    base_desl = sum(v.get("kms", z)[:n]) + sum(v.get("ajudas", z)[:n])
    linhas = [
        {"chave": "repr", "nome": "Representação (restauração)", "base": base_repr, "taxa": cfg["ta_taxa_rest"]},
        {"chave": "viaturas", "nome": "Viaturas (carro + combustível)", "base": base_viat, "taxa": cfg.get("ta_taxa_viaturas", 0.08)},
        {"chave": "deslocacoes", "nome": "Kms em viatura própria e ajudas de custo", "base": base_desl, "taxa": cfg["ta_taxa_ajudas"]},
    ]
    for l in linhas:
        l["valor"] = l["base"] * l["taxa"]
    return {"linhas": linhas, "total": sum(l["valor"] for l in linhas), **{l["chave"]: l["valor"] for l in linhas}}


def calcular_saldo(conn: sqlite3.Connection, ano: int) -> dict:
    """Bloco Saldo (Estimativa vs Real), encadeando o saldo transitório do ano anterior."""
    d = carregar_ano(conn, ano)
    cfg = d["cfg"]
    mapa = calcular_mapa(d)
    tot = mapa["tot"]
    trims = iva_trimestres(d, mapa)
    iva_ganho = sum(t["devolvido"] for t in trims)
    imp = d["imp"]
    irc_etc = imp["irc"] + imp["ta"] + imp["ies"] + imp["pag_conta"]

    if conn.execute("SELECT 1 FROM config_ano WHERE ano=?", (ano - 1,)).fetchone():
        prev = calcular_saldo(conn, ano - 1)
        ant_est, ant_real = prev["est"]["saldo_trans"], prev["real"]["saldo_trans"]
    else:
        ant_est, ant_real = cfg["saldo_inicial_est"], cfg["saldo_inicial_real"]

    est_linhas = {
        "irc_etc": irc_etc,
        "salario": tot["total_salario"],
        "iva": tot["iva"],
        **{c: tot[c] for c in CUSTOS_ANTES_SS + ["ss_empresa", "ss_colab"] + CUSTOS_FIM},
        "retirar": tot["total_desp"],
        "tesouraria": d.get("tes", {}).get("est", 0.0),
    }
    real = linhas_reais(d, mapa)
    real_linhas = {c: real.get(c, 0.0) for c, _ in SALDO_LINHAS}

    def fechar(receitas, linhas, anterior):
        total_rec = receitas + iva_ganho
        total_gastos = sum(linhas.values())
        conta = cfg["capital_social"] + anterior + total_rec - total_gastos
        return {
            "capital": cfg["capital_social"], "anterior": anterior, "receitas": receitas, "iva_ganho": iva_ganho,
            "linhas": linhas, "total_receitas": total_rec, "total_gastos": total_gastos,
            "saldo_conta": conta, "saldo_trans": conta - cfg["capital_social"],
        }

    est = fechar(sum(tot[c] for c in RECEITAS), est_linhas, ant_est)
    rl = fechar(real.get("receitas", 0.0), real_linhas, ant_real)

    # Lucro / IRC / dividendos (estimativa). Lucro = saldo transitório - saldo anterior + impostos já lançados
    # (obtém-se o resultado antes de IRC, TA, IES e pagamentos por conta).
    # a tesouraria (cauções…) mexe no saldo mas não é custo nem receita: volta a somar-se para não entrar no lucro
    lucro_antes = est["saldo_trans"] - est["anterior"] + irc_etc + est_linhas["tesouraria"]  # antes de IRC, TA, IES e pagamentos por conta
    lucro = lucro_antes  # o «Lucro» é antes de IRC, TA, IES e pagamentos por conta (como no Excel de 2024 e 2025)
    lucro_depois = lucro_antes - irc_etc  # só informativo: depois dos impostos já lançados
    base_fact = tot["avenca"] + tot["extra"] + tot["premio"] - tot["iva"]
    irc_est = max(0.0, lucro_antes) * cfg["irc_taxa"]  # com prejuízo não há IRC
    ta_info = tributacoes_autonomas(mapa["v"], cfg)
    ta_est = ta_info["total"]
    irc_pago = sum(d["inp_pago"]["irc"])
    imposto = {
        "lucro": lucro,
        "lucro_antes": lucro_antes,
        "lucro_depois": lucro_depois,
        "impostos_lancados": irc_etc,
        "iva_ganho": iva_ganho,
        "margem": (lucro / base_fact) if base_fact else None,
        "irc_taxa": cfg["irc_taxa"],
        "irc_est": irc_est,
        "ta_est": ta_est, "ta_linhas": ta_info["linhas"],
        "div_taxa": cfg["dividendos_taxa"],
        "apos_irc_est": lucro_antes - irc_est,
        "estado_est": max(0.0, lucro_antes - irc_est) * cfg["dividendos_taxa"],
        "liquido_est": max(0.0, lucro_antes - irc_est) * (1 - cfg["dividendos_taxa"]),  # com prejuízo não há nada a distribuir
        "irc_pago": irc_pago,
        "apos_irc_real": lucro_antes - irc_pago,
        "estado_real": max(0.0, lucro_antes - irc_pago) * cfg["dividendos_taxa"],
        "liquido_real": max(0.0, lucro_antes - irc_pago) * (1 - cfg["dividendos_taxa"]),
    }
    return {"ano": ano, "est": est, "real": rl, "iva_trimestres": trims, "imposto": imposto, "imp": imp, "mapa": mapa, "ajustes": d["ajustes"],
            "imp_pago": {k: sum(d["inp_pago"][k]) for k in ("irc", "ta", "ies", "pag_conta")}}
