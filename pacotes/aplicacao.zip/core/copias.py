"""Cópias de segurança automáticas da base de dados (v1.11.0).

As cópias ficam numa pasta «copias» ao lado da base, numa subpasta com o nome da base:
    dados/copias/<nome da base>/<nome>_2026-10-29_073100_abrir.db
Guarda-se uma cópia por dia ao abrir a base, outra antes de importar ou de repor, e as que se pedem à mão.
Só ficam as N mais recentes (por omissão 10).
"""
from __future__ import annotations

import re
import sqlite3
from datetime import datetime, timedelta
from pathlib import Path

MOTIVOS = {"abrir": "ao abrir", "manual": "manual", "importar": "antes de importar", "repor": "antes de repor"}
MANTER_PADRAO = 10
_NOME = re.compile(r"^(?P<base>.+)_(?P<d>\d{4}-\d{2}-\d{2})_(?P<h>\d{6})_(?P<motivo>[a-z]+)\.db$")


class ErroCopia(ValueError):
    """Mensagem pensada para o utilizador."""


def pasta(db_path: str | Path) -> Path:
    p = Path(db_path)
    return p.parent / "copias" / p.stem


def _def(conn: sqlite3.Connection, chave: str, padrao: str) -> str:
    r = conn.execute("SELECT valor FROM definicao WHERE chave=?", (chave,)).fetchone()
    return r[0] if r and r[0] is not None else padrao


def definicoes(conn: sqlite3.Connection) -> dict:
    try:
        manter = int(_def(conn, "copias_manter", str(MANTER_PADRAO)))
    except ValueError:
        manter = MANTER_PADRAO
    return {"auto": _def(conn, "copias_auto", "1") == "1", "manter": max(1, min(50, manter))}


def gravar_definicoes(conn: sqlite3.Connection, auto: bool, manter: int) -> None:
    if not 1 <= manter <= 50:
        raise ErroCopia("Escolha entre 1 e 50 cópias.")
    for k, v in (("copias_auto", "1" if auto else "0"), ("copias_manter", str(manter))):
        conn.execute("INSERT INTO definicao (chave, valor) VALUES (?, ?) ON CONFLICT(chave) DO UPDATE SET valor=excluded.valor", (k, v))
    conn.commit()


def listar(db_path: str | Path) -> list[dict]:
    """Cópias desta base, da mais recente para a mais antiga."""
    d = pasta(db_path)
    if not d.is_dir():
        return []
    out = []
    for f in d.glob("*.db"):
        m = _NOME.match(f.name)
        if not m:
            continue
        quando = datetime.strptime(f"{m['d']} {m['h']}", "%Y-%m-%d %H%M%S")
        out.append({"ficheiro": f.name, "caminho": f, "quando": quando, "motivo": m["motivo"],
                    "motivo_txt": MOTIVOS.get(m["motivo"], m["motivo"]), "tamanho_kb": max(1, f.stat().st_size // 1024)})
    out.sort(key=lambda c: c["quando"], reverse=True)
    return out


def contar_lancamentos(caminho: Path) -> int | None:
    try:
        c = sqlite3.connect(f"file:{caminho}?mode=ro", uri=True)
        try:
            n = c.execute("SELECT (SELECT COUNT(*) FROM movimento) + (SELECT COUNT(*) FROM despesa)").fetchone()[0]
        finally:
            c.close()
        return n
    except sqlite3.Error:
        return None


def fazer(db_path: str | Path, motivo: str, manter: int = MANTER_PADRAO) -> Path:
    """Copia a base (com a cópia do próprio SQLite, segura mesmo com a base aberta) e apaga as mais antigas."""
    if motivo not in MOTIVOS:
        raise ErroCopia("Motivo de cópia desconhecido.")
    origem = Path(db_path)
    if not origem.is_file():
        raise ErroCopia("A base de dados não existe.")
    d = pasta(origem)
    d.mkdir(parents=True, exist_ok=True)
    agora = datetime.now().replace(microsecond=0)
    destino = d / f"{origem.stem}_{agora:%Y-%m-%d_%H%M%S}_{motivo}.db"
    while destino.exists():  # duas cópias no mesmo segundo: a seguinte fica com o segundo seguinte
        agora += timedelta(seconds=1)
        destino = d / f"{origem.stem}_{agora:%Y-%m-%d_%H%M%S}_{motivo}.db"
    src = sqlite3.connect(str(origem))
    dst = sqlite3.connect(str(destino))
    try:
        src.backup(dst)
    finally:
        dst.close()
        src.close()
    limpar(origem, manter)
    return destino


def limpar(db_path: str | Path, manter: int) -> int:
    apagadas = 0
    for c in listar(db_path)[manter:]:
        try:
            c["caminho"].unlink()
            apagadas += 1
        except OSError:
            pass
    return apagadas


def ao_abrir(db_path: str | Path) -> Path | None:
    """Uma cópia por dia, na primeira vez que a base é aberta (se estiver ligado)."""
    origem = Path(db_path)
    if not origem.is_file():
        return None
    try:
        c = sqlite3.connect(f"file:{origem}?mode=ro", uri=True)
        try:
            tem = c.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='definicao'").fetchone()
            cfg = definicoes(c) if tem else {"auto": True, "manter": MANTER_PADRAO}
        finally:
            c.close()
    except sqlite3.Error:
        return None
    if not cfg["auto"]:
        return None
    hoje = datetime.now().date()
    if any(x["motivo"] == "abrir" and x["quando"].date() == hoje for x in listar(origem)):
        return None
    return fazer(origem, "abrir", cfg["manter"])


def repor(db_path: str | Path, ficheiro: str, manter: int = MANTER_PADRAO) -> Path:
    """Repõe a base a partir de uma cópia. Antes, guarda o estado atual como cópia «antes de repor»."""
    origem = Path(db_path)
    escolhida = pasta(origem) / ficheiro
    if Path(ficheiro).name != ficheiro or not _NOME.match(ficheiro) or not escolhida.is_file():
        raise ErroCopia("Essa cópia já não existe.")
    with escolhida.open("rb") as f:
        if f.read(16) != b"SQLite format 3\x00":
            raise ErroCopia("Essa cópia não é uma base de dados válida.")
    antes = fazer(origem, "repor", manter + 1)  # +1: a escolhida não pode ser apagada pela limpeza
    src = sqlite3.connect(str(escolhida))
    dst = sqlite3.connect(str(origem))
    try:
        src.backup(dst)
    finally:
        dst.close()
        src.close()
    limpar(origem, manter + 1)
    return antes
