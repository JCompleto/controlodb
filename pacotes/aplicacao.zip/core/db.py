"""Base de dados SQLite do Controlo Empresa."""
from __future__ import annotations

import os
import re
import shutil
import sqlite3
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
DB_PATH = Path(os.environ.get("CONTROLO_DB", RAIZ / "dados" / "controlo.db"))

# (codigo, nome, grupo, ordem, opcional)
RUBRICAS = [
    ("avenca", "Factura Avença", "receita", 10, 0),
    ("extra", "Factura Extra", "receita", 11, 0),
    ("premio", "Fatura Prémio", "receita", 12, 0),
    ("isento", "Factura Isento de IVA", "receita", 13, 0),
    ("vencimento", "Vencimento Base", "salario", 20, 0),
    ("isencao", "Isenção Horário de Trabalho", "salario", 21, 0),
    ("sub_ferias", "Subs. Férias (100% c/duodécimos)", "salario", 22, 0),
    ("sub_natal", "Subs. Natal (100% c/duodécimos)", "salario", 23, 0),
    ("sub_alim", "Subs. Alimentação", "salario", 24, 0),
    ("kms", "Kms em viatura própria", "salario", 25, 0),
    ("ajudas", "Ajudas Custo Nacional", "salario", 26, 0),
    ("contabilista", "Contabilista", "custo", 40, 0),
    ("man_conta", "Man. Conta", "custo", 41, 0),
    ("mcontab_conta", "MContabilidade - Conta", "custo", 42, 1),
    ("luz", "Luz", "custo", 43, 1),
    ("custos_banc", "Custos Bancários Transf.", "custo", 44, 0),
    ("renda", "Renda", "custo", 45, 0),
    ("carro", "Carro", "custo", 46, 0),
    ("outras", "Outras despesas", "custo", 47, 0),
    ("irs", "IRS", "custo", 48, 0),
    ("fct", "FCT", "custo", 51, 0),
    ("fgct", "FGCT", "custo", 52, 0),
    ("irc", "IRC", "imposto", 60, 0),
    ("ta", "Tributações autónomas", "imposto", 61, 0),
    ("ies", "IES", "imposto", 62, 0),
    ("pag_conta", "Pagamento por conta", "imposto", 63, 0),
]

IMPOSTOS = ["irc", "ta", "ies", "pag_conta"]
# tipos de despesa usados nos cálculos pelo nome (TA sobre restauração; conta 6242 na Simulação): não se mudam nem apagam
TIPOS_DESPESA_FIXOS = ["Restauração", "Combustível", "Outras despesas"]
EMPRESA_PADRAO = "A minha empresa"
VERSAO_ESQUEMA = 4  # 4 = retenção na renda e «quem pagou» nas despesas; 3 = repara ajustes de despesas da conversão inicial; 2 = estado «pago» em cada lançamento (o «real» deixou de ser uma lista de pagamentos soltos)

SCHEMA = """
CREATE TABLE IF NOT EXISTS config_ano (
    ano INTEGER PRIMARY KEY,
    iva REAL NOT NULL DEFAULT 0.23,
    ss_empresa REAL NOT NULL DEFAULT 0.2375,
    ss_colab REAL NOT NULL DEFAULT 0.11,
    irc_taxa REAL NOT NULL DEFAULT 0.16,
    dividendos_taxa REAL NOT NULL DEFAULT 0.28,
    ta_taxa_ajudas REAL NOT NULL DEFAULT 0.05,
    ta_taxa_rest REAL NOT NULL DEFAULT 0.10,
    subs_alim_dia REAL NOT NULL DEFAULT 6,
    km_valor REAL NOT NULL DEFAULT 0.40,
    ajuda_custo_dia REAL NOT NULL DEFAULT 69.19,
    capital_social REAL NOT NULL DEFAULT 600,
    saldo_inicial_est REAL NOT NULL DEFAULT 0,
    saldo_inicial_real REAL NOT NULL DEFAULT 0,
    valor_dia REAL NOT NULL DEFAULT 260
);
CREATE TABLE IF NOT EXISTS rubrica (
    codigo TEXT PRIMARY KEY,
    nome TEXT NOT NULL,
    grupo TEXT NOT NULL,
    ordem INTEGER NOT NULL,
    opcional INTEGER NOT NULL DEFAULT 0
);
-- Mapa mensal (o que o Excel tinha nas colunas Jan..Dez). Valores como no Excel:
-- receitas e contabilista com IVA incluído.
CREATE TABLE IF NOT EXISTS movimento (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ano INTEGER NOT NULL,
    mes INTEGER NOT NULL CHECK (mes BETWEEN 1 AND 12),
    rubrica TEXT NOT NULL REFERENCES rubrica(codigo),
    valor REAL NOT NULL,
    descricao TEXT,
    nota TEXT,
    data TEXT,
    cliente TEXT,
    quantidade REAL,
    preco_unit REAL,
    base REAL,
    pago INTEGER NOT NULL DEFAULT 0,      -- 1 = já entrou/saiu da conta
    data_pagamento TEXT,
    retencao REAL NOT NULL DEFAULT 0,     -- renda: imposto retido na fonte (pago à parte ao Estado)
    retencao_pago INTEGER NOT NULL DEFAULT 0,
    retencao_data TEXT
);
CREATE INDEX IF NOT EXISTS ix_mov_ano ON movimento(ano, rubrica, mes);
-- Ajustes ao saldo «Real» vindos do Excel que não correspondem a nenhum lançamento (normalmente vazia).
-- O «real» passou a vir do estado pago de cada lançamento.
CREATE TABLE IF NOT EXISTS pagamento (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ano INTEGER NOT NULL,
    rubrica TEXT NOT NULL,
    valor REAL NOT NULL,
    data TEXT,
    descricao TEXT
);
CREATE INDEX IF NOT EXISTS ix_pag_ano ON pagamento(ano, rubrica);
-- Folha "Despesas" do Excel
CREATE TABLE IF NOT EXISTS despesa (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    data TEXT NOT NULL,
    valor REAL NOT NULL,
    descricao TEXT,
    tipo TEXT NOT NULL,
    meio TEXT,
    notas TEXT,
    pago INTEGER NOT NULL DEFAULT 0,      -- 1 = já saiu da conta (paga pela empresa, ou reembolsada ao sócio)
    data_pagamento TEXT,
    pago_por TEXT NOT NULL DEFAULT 'socio' -- 'socio' (depois reembolsado) ou 'empresa' (paga direto da conta)
);
CREATE INDEX IF NOT EXISTS ix_desp_data ON despesa(data);
CREATE TABLE IF NOT EXISTS tipo_despesa (nome TEXT PRIMARY KEY);  -- configurável em Configurações
CREATE TABLE IF NOT EXISTS meio_pagamento (nome TEXT PRIMARY KEY);
CREATE TABLE IF NOT EXISTS iva_trimestre (
    ano INTEGER NOT NULL,
    trimestre INTEGER NOT NULL CHECK (trimestre BETWEEN 1 AND 4),
    pago REAL,                            -- valor pago; NULL = por pagar
    data_pagamento TEXT,
    PRIMARY KEY (ano, trimestre)
);
-- Estado do pagamento de cada salário: líquido ao colaborador e SS + IRS ao Estado
CREATE TABLE IF NOT EXISTS salario_estado (
    ano INTEGER NOT NULL,
    mes INTEGER NOT NULL CHECK (mes BETWEEN 1 AND 12),
    liquido_pago INTEGER NOT NULL DEFAULT 0,
    liquido_data TEXT,
    estado_pago INTEGER NOT NULL DEFAULT 0,
    estado_data TEXT,
    PRIMARY KEY (ano, mes)
);
-- Mapas de exploração enviados pela contabilidade (o conteúdo já lido, em JSON; o Excel não se guarda)
CREATE TABLE IF NOT EXISTS mapa_exploracao (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ano INTEGER NOT NULL,
    ate_mes INTEGER NOT NULL,          -- último mês com movimento (1-12)
    ficheiro TEXT NOT NULL,
    carregado TEXT NOT NULL,           -- data e hora (AAAA-MM-DD HH:MM)
    dados TEXT NOT NULL
);
-- v1.16.0: dinheiro que sai ou entra sem ser custo nem receita (cauções, empréstimos do sócio…).
-- Conta no saldo da conta (estimativa e real), mas não no lucro, no IVA nem nas tributações autónomas.
CREATE TABLE IF NOT EXISTS tesouraria (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    data TEXT NOT NULL,
    sentido TEXT NOT NULL CHECK (sentido IN ('saida', 'entrada')),
    valor REAL NOT NULL,                  -- sempre positivo; o sentido diz se sai ou entra
    descricao TEXT,
    pago INTEGER NOT NULL DEFAULT 0,      -- 1 = já saiu/entrou na conta
    data_pagamento TEXT,
    documento TEXT
);
CREATE TABLE IF NOT EXISTS definicao (
    chave TEXT PRIMARY KEY,
    valor TEXT
);
CREATE TABLE IF NOT EXISTS imposto_ano (
    ano INTEGER PRIMARY KEY,
    irc REAL NOT NULL DEFAULT 0,
    ta REAL NOT NULL DEFAULT 0,
    ies REAL NOT NULL DEFAULT 0,
    pag_conta REAL NOT NULL DEFAULT 0
);
"""


# Bases já preparadas (esquema e migrações) neste arranque: caminho -> (tamanho, data de alteração) do ficheiro.
# Preparar a base a cada pedido obrigava a dezenas de idas ao ficheiro; numa pasta do Google Drive isso nota-se.
_PREPARADAS: dict[str, tuple[int, int]] = {}


def _marca(p: Path) -> tuple[int, int] | None:
    try:
        st = p.stat()
    except OSError:
        return None
    return st.st_size, st.st_mtime_ns


def get_conn(path: Path | str | None = None) -> sqlite3.Connection:
    p = Path(path) if path else DB_PATH
    memoria = str(p) == ":memory:"
    if not memoria:
        p.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(p))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    chave = None if memoria else str(p.resolve())
    # o mesmo ficheiro, sem alterações desde que foi preparado (nem substituído por outra cópia): não é preciso repetir
    marca = None if memoria else _marca(p)
    if marca is None or _PREPARADAS.get(chave) != marca:
        init_db(conn, None if memoria else p)
        if not memoria:
            _PREPARADAS[chave] = _marca(p)
    return conn


COLUNAS_NOVAS = {
    "movimento": [("data", "TEXT"), ("cliente", "TEXT"), ("quantidade", "REAL"), ("preco_unit", "REAL"), ("base", "REAL"),
                  ("pago", "INTEGER NOT NULL DEFAULT 0"), ("data_pagamento", "TEXT"),
                  ("retencao", "REAL NOT NULL DEFAULT 0"), ("retencao_pago", "INTEGER NOT NULL DEFAULT 0"), ("retencao_data", "TEXT"),
                  ("ano_ref", "INTEGER"),  # impostos: ano a que o imposto respeita (ex.: IRC de 2025 pago em 2026)
                  ("documento", "TEXT")],  # v1.11.0: fatura (PDF/imagem), caminho relativo à pasta da empresa
    "despesa": [("pago", "INTEGER NOT NULL DEFAULT 0"), ("data_pagamento", "TEXT"), ("pago_por", "TEXT NOT NULL DEFAULT 'socio'"),
                ("documento", "TEXT"), ("sem_fatura", "INTEGER NOT NULL DEFAULT 0")],  # v1.12.0: 1 = não tem fatura (acertos)
    "iva_trimestre": [("data_pagamento", "TEXT")],
    "config_ano": [("valor_dia", "REAL NOT NULL DEFAULT 260"),
                   # subsídios de férias e de Natal: 1 = em duodécimos (1/12 todos os meses); 0 = por inteiro no mês indicado
                   ("subs_duodecimos", "INTEGER NOT NULL DEFAULT 1"), ("subs_mes_ferias", "INTEGER NOT NULL DEFAULT 6"),
                   ("subs_mes_natal", "INTEGER NOT NULL DEFAULT 12"),
                   # tributação autónoma sobre encargos com a viatura (art.º 88.º, n.º 3 CIRC): 8 % se custo de aquisição < 37 500 €
                   ("ta_taxa_viaturas", "REAL NOT NULL DEFAULT 0.08")],
}


def _migrar_colunas(conn: sqlite3.Connection) -> None:
    """Acrescenta a bases de versões anteriores as colunas que faltam."""
    for tabela, colunas in COLUNAS_NOVAS.items():
        existentes = {r["name"] for r in conn.execute(f"PRAGMA table_info({tabela})")}
        for col, tipo in colunas:
            if col not in existentes:
                conn.execute(f"ALTER TABLE {tabela} ADD COLUMN {col} {tipo}")


def _copia_de_seguranca(caminho: Path) -> Path:
    destino = caminho.with_name(f"{caminho.name}.antes-do-estado-pago.bak")
    n = 1
    while destino.exists():
        n += 1
        destino = caminho.with_name(f"{caminho.name}.antes-do-estado-pago-{n}.bak")
    shutil.copy2(caminho, destino)
    return destino


def init_db(conn: sqlite3.Connection, caminho: Path | None = None) -> None:
    versao = conn.execute("PRAGMA user_version").fetchone()[0]
    tinha_dados = conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='movimento'").fetchone() is not None
    if versao < VERSAO_ESQUEMA and tinha_dados and caminho is not None:
        conn.commit()
        _copia_de_seguranca(caminho)  # antes de mexer numa base que já tem dados
    conn.executescript(SCHEMA)
    _migrar_colunas(conn)
    conn.executemany(
        "INSERT OR IGNORE INTO rubrica (codigo, nome, grupo, ordem, opcional) VALUES (?,?,?,?,?)",
        RUBRICAS,
    )
    conn.executemany(
        "INSERT OR IGNORE INTO tipo_despesa (nome) VALUES (?)",
        [(t,) for t in ("Restauração", "Outras despesas", "Combustível")],
    )
    conn.executemany(
        "INSERT OR IGNORE INTO meio_pagamento (nome) VALUES (?)",
        [("Cartão de Crédito",), ("Dinheiro",)],
    )
    # nome da empresa (aparece na barra lateral); as bases que já tinham dados ficam com o nome por omissão
    conn.execute("INSERT OR IGNORE INTO definicao (chave, valor) VALUES ('empresa', ?)",
                  (EMPRESA_PADRAO if tinha_dados else "A minha empresa",))
    if versao < VERSAO_ESQUEMA:
        if tinha_dados:
            from . import legado  # import tardio: legado usa o cálculo, que não depende deste módulo

            if versao < 2:
                legado.converter_tudo(conn)
            else:
                legado.reparar_ajustes(conn)
        conn.execute(f"PRAGMA user_version = {VERSAO_ESQUEMA}")
    conn.commit()


def anos(conn: sqlite3.Connection) -> list[int]:
    return [r["ano"] for r in conn.execute("SELECT ano FROM config_ano ORDER BY ano")]


def criar_ano(conn: sqlite3.Connection, ano: int) -> None:
    """Cria um ano novo copiando as taxas do ano anterior (ou valores por omissão)."""
    if conn.execute("SELECT 1 FROM config_ano WHERE ano=?", (ano,)).fetchone():
        return
    ant = conn.execute("SELECT * FROM config_ano WHERE ano < ? ORDER BY ano DESC LIMIT 1", (ano,)).fetchone()
    if ant:
        d = dict(ant)
        d["ano"] = ano
        cols = ", ".join(d)
        marks = ", ".join("?" for _ in d)
        conn.execute(f"INSERT INTO config_ano ({cols}) VALUES ({marks})", list(d.values()))
    else:
        conn.execute("INSERT INTO config_ano (ano) VALUES (?)", (ano,))
    conn.execute("INSERT OR IGNORE INTO imposto_ano (ano) VALUES (?)", (ano,))
    for t in range(1, 5):
        conn.execute("INSERT OR IGNORE INTO iva_trimestre (ano, trimestre, pago) VALUES (?,?,NULL)", (ano, t))
    conn.commit()


def nome_empresa(conn: sqlite3.Connection) -> str:
    r = conn.execute("SELECT valor FROM definicao WHERE chave='empresa'").fetchone()
    return (r[0] if r and r[0] else "").strip() or EMPRESA_PADRAO


def iniciais(nome: str) -> str:
    """«Exemplo Silva, LDA» -> «ES» (ignora LDA, SA, Unipessoal, de, da...)."""
    ignorar = {"lda", "sa", "s.a", "unipessoal", "de", "da", "do", "das", "dos", "e"}
    palavras = [w for w in re.split(r"[\s,.\-]+", nome) if w and w.lower() not in ignorar]
    return "".join(w[0] for w in palavras[:2]).upper() or "?"


def gravar_nome_empresa(conn: sqlite3.Connection, nome: str) -> None:
    nome = " ".join((nome or "").split())
    if not nome:
        raise ValueError("Indique o nome da empresa.")
    if len(nome) > 80:
        raise ValueError("O nome é demasiado comprido (máximo 80 caracteres).")
    conn.execute("INSERT INTO definicao (chave, valor) VALUES ('empresa', ?) ON CONFLICT(chave) DO UPDATE SET valor=excluded.valor", (nome,))
    conn.commit()
