"""Faturas (PDF ou imagem) ligadas aos lançamentos (v1.11.0).

Na base guarda-se só o caminho relativo à pasta da empresa (por omissão, a pasta onde está a pasta da
aplicação, ou seja «Empresa …» no Google Drive). Assim o mesmo lançamento abre a fatura em qualquer PC
que tenha o Drive, e a base pode ir para o telemóvel sem levar ficheiros.
"""
from __future__ import annotations

import re
import sqlite3
import unicodedata
from datetime import date
from pathlib import Path

from .db import RAIZ

EXTENSOES = {".pdf": "application/pdf", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png",
             ".webp": "image/webp", ".heic": "image/heic"}
MESES_NOMES = ["janeiro", "fevereiro", "marco", "abril", "maio", "junho", "julho", "agosto", "setembro", "outubro",
               "novembro", "dezembro"]
_IGNORAR = {"controlo app", "$recycle.bin", ".encrypted", ".shortcut-targets-by-id"}


class ErroDocumento(ValueError):
    """Mensagem pensada para o utilizador."""


def _sem_acentos(s: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFD", s.lower()) if unicodedata.category(c) != "Mn")


def raiz(conn: sqlite3.Connection) -> Path:
    r = conn.execute("SELECT valor FROM definicao WHERE chave='pasta_documentos'").fetchone()
    if r and r[0]:
        return Path(r[0])
    return RAIZ.parent


def gravar_raiz(conn: sqlite3.Connection, texto: str) -> Path | None:
    texto = (texto or "").strip().strip('"')
    if not texto:
        conn.execute("DELETE FROM definicao WHERE chave='pasta_documentos'")
        conn.commit()
        return None
    p = Path(texto).expanduser()
    if not p.is_absolute():
        raise ErroDocumento("A pasta tem de ser um caminho completo.")
    if not p.is_dir():
        raise ErroDocumento(f"Não encontro a pasta «{p}».")
    conn.execute("INSERT INTO definicao (chave, valor) VALUES ('pasta_documentos', ?) ON CONFLICT(chave) DO UPDATE SET valor=excluded.valor", (str(p),))
    conn.commit()
    return p


def resolver(conn: sqlite3.Connection, rel: str) -> Path:
    """Caminho relativo -> ficheiro dentro da pasta da empresa (recusa tudo o que saia dela)."""
    base = raiz(conn).resolve()
    rel = (rel or "").replace("\\", "/").strip("/")
    p = (base / rel).resolve()
    if p != base and base not in p.parents:
        raise ErroDocumento("Esse caminho está fora da pasta da empresa.")
    return p


def relativo(conn: sqlite3.Connection, p: Path) -> str:
    return p.resolve().relative_to(raiz(conn).resolve()).as_posix()


def validar(conn: sqlite3.Connection, rel: str) -> str | None:
    """Valida o caminho escolhido no formulário; devolve-o normalizado (ou None se vazio)."""
    rel = (rel or "").strip()
    if not rel:
        return None
    p = resolver(conn, rel)
    if p.suffix.lower() not in EXTENSOES:
        raise ErroDocumento("A fatura tem de ser um PDF ou uma imagem (JPG, PNG).")
    if not p.is_file():
        raise ErroDocumento(f"Não encontro o ficheiro «{p.name}» na pasta da empresa.")
    return relativo(conn, p)


def tipo_mime(rel: str) -> str:
    return EXTENSOES.get(Path(rel).suffix.lower(), "application/octet-stream")


def _filho(pai: Path, testa) -> Path | None:
    try:
        for d in sorted(x for x in pai.iterdir() if x.is_dir()):
            if testa(_sem_acentos(d.name)):
                return d
    except OSError:
        return None
    return None


def sugerir_pasta(conn: sqlite3.Connection, data: str | None, ano: int, mes: int | None, socio: bool) -> str:
    """Pasta onde a fatura deve estar: ano › mês › Faturas › Sócio (até onde existir)."""
    if data:
        try:
            d = date.fromisoformat(data)
            ano, mes = d.year, d.month
        except ValueError:
            pass
    base = raiz(conn)
    atual = base
    p = _filho(atual, lambda n: n == str(ano))
    if not p:
        return ""
    atual = p
    if mes:
        nome = MESES_NOMES[mes - 1]
        numeros = {str(mes), f"{mes:02d}"}

        def e_mes(n: str) -> bool:
            partes = set(re.split(r"[\s._\-]+", n))
            return bool(partes & numeros) or nome in n or nome[:3] in partes

        p = _filho(atual, e_mes)
        if p:
            atual = p
            p = _filho(atual, lambda n: n.startswith("fatura") or n.startswith("factura"))
            if p:
                atual = p
                if socio:
                    p = _filho(atual, lambda n: n.startswith("socio"))
                    if p:
                        atual = p
    return relativo(conn, atual)


def listar_pasta(conn: sqlite3.Connection, rel: str) -> dict:
    p = resolver(conn, rel)
    if not p.is_dir():
        raise ErroDocumento("Essa pasta já não existe.")
    pastas, ficheiros = [], []
    try:
        for x in sorted(p.iterdir(), key=lambda x: _sem_acentos(x.name)):
            if x.name.startswith((".", "~$")) or _sem_acentos(x.name) in _IGNORAR:
                continue
            if x.is_dir():
                pastas.append({"nome": x.name, "rel": relativo(conn, x)})
            elif x.suffix.lower() in EXTENSOES:
                ficheiros.append({"nome": x.name, "rel": relativo(conn, x), "kb": max(1, x.stat().st_size // 1024)})
    except OSError as e:
        raise ErroDocumento(f"Não consegui ler a pasta: {e}") from None
    cam = relativo(conn, p) if p != raiz(conn).resolve() else ""
    migalhas = [{"nome": raiz(conn).name or str(raiz(conn)), "rel": ""}]
    acc = []
    for parte in [x for x in cam.split("/") if x]:
        acc.append(parte)
        migalhas.append({"nome": parte, "rel": "/".join(acc)})
    return {"rel": cam, "migalhas": migalhas, "pastas": pastas, "ficheiros": ficheiros}


def nome_seguro(nome: str) -> str:
    nome = Path(nome or "").name
    nome = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", nome).strip(" .")
    return nome[:120] or "fatura.pdf"


def guardar_carregado(conn: sqlite3.Connection, ficheiro, pasta_rel: str) -> str:
    """Guarda na pasta sugerida um ficheiro carregado do computador; devolve o caminho relativo."""
    nome = nome_seguro(ficheiro.filename)
    if Path(nome).suffix.lower() not in EXTENSOES:
        raise ErroDocumento("A fatura tem de ser um PDF ou uma imagem (JPG, PNG).")
    destino_dir = resolver(conn, pasta_rel)
    if not destino_dir.is_dir():
        destino_dir = raiz(conn)
    destino = destino_dir / nome
    n = 1
    while destino.exists():
        n += 1
        destino = destino_dir / f"{Path(nome).stem} ({n}){Path(nome).suffix}"
    try:
        ficheiro.save(str(destino))
    except OSError as e:
        raise ErroDocumento(f"Não consegui guardar a fatura: {e}") from None
    return relativo(conn, destino)
