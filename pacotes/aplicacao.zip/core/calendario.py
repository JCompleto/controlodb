"""Dias úteis em Portugal (feriados nacionais), para sugerir os dias do mês nos formulários."""
from __future__ import annotations

from datetime import date, timedelta


def pascoa(ano: int) -> date:
    """Domingo de Páscoa (algoritmo gregoriano)."""
    a, b, c = ano % 19, ano // 100, ano % 100
    d, e = b // 4, b % 4
    f = (b + 8) // 25
    g = (b - f + 1) // 3
    h = (19 * a + b - d - g + 15) % 30
    i, k = c // 4, c % 4
    l = (32 + 2 * e + 2 * i - h - k) % 7
    m = (a + 11 * h + 22 * l) // 451
    mes = (h + l - 7 * m + 114) // 31
    dia = (h + l - 7 * m + 114) % 31 + 1
    return date(ano, mes, dia)


def feriados(ano: int) -> set[date]:
    p = pascoa(ano)
    return {
        date(ano, 1, 1), p - timedelta(days=2), p, date(ano, 4, 25), date(ano, 5, 1),
        p + timedelta(days=60),  # Corpo de Deus
        date(ano, 6, 10), date(ano, 8, 15), date(ano, 10, 5), date(ano, 11, 1),
        date(ano, 12, 1), date(ano, 12, 8), date(ano, 12, 25),
    }


def dias_uteis(ano: int, mes: int) -> int:
    """Dias de segunda a sexta do mês, sem feriados nacionais."""
    fer = feriados(ano)
    d, n = date(ano, mes, 1), 0
    while d.month == mes:
        if d.weekday() < 5 and d not in fer:
            n += 1
        d += timedelta(days=1)
    return n
