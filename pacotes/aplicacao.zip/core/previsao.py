"""Previsões para o resto do ano (separadores «Fim do ano» e «Ordenado» da Simulação).

Pega no ano tal como está lançado, completa os meses que faltam com valores previstos e calcula o lucro com
exatamente as mesmas contas do Painel (calc.calcular_mapa + IVA ganho; lucro antes de IRC, TA, IES e pagamentos
por conta). Nada é gravado.

Meses previstos (os que vêm depois do último mês faturado):
  - avença: dias úteis do mês × valor por dia (+ IVA), como nas faturas; extra por mês opcional;
  - salário: o do último mês lançado (vencimento, isenção, kms, ajudas), subsídio de alimentação pelos dias úteis,
    subsídios de férias e de Natal pela definição do ano e IRS pela tabela oficial;
  - custos da empresa (contabilista, renda, carro, ...): mediana mensal dos meses já faturados (ignora valores
    pontuais, como a compra de um carro) ou, se escolhido, a média simples;
  - despesas avulsas: o mesmo, por tipo (+ despesa extra por mês, se indicada);
  - impostos (IRC, TA, IES, pagamentos por conta) não entram: o lucro é antes deles.
"""
from __future__ import annotations

import copy
import sqlite3
from statistics import median

from . import irs
from .calc import CUSTOS_ANTES_SS, CUSTOS_FIM, RECEITAS, calcular_mapa, carregar_ano, iva_trimestres, r2
from .calendario import dias_uteis

CUSTOS_PREVER = [c for c in CUSTOS_ANTES_SS + CUSTOS_FIM if c != "irs"]
DESPESA_EXTRA = "Despesa extra (simulação)"


def subsidios(cfg: dict, mes: int, vencimento: float, isencao: float) -> tuple[float, float]:
    """Subsídios de férias e de Natal do mês, pela definição do ano.
    Férias = vencimento + isenção de horário; Natal = só vencimento base (Código do Trabalho, art.os 262.º a 264.º).
    Em duodécimos: 1/12 de cada, todos os meses. Por inteiro: o subsídio todo no mês indicado."""
    ferias, natal = vencimento + isencao, vencimento
    if cfg.get("subs_duodecimos", 1):
        return r2(ferias / 12), r2(natal / 12)
    return (r2(ferias) if mes == cfg.get("subs_mes_ferias", 6) else 0.0), (r2(natal) if mes == cfg.get("subs_mes_natal", 12) else 0.0)


def irs_mes(ano: int, cfg: dict, mes: int, rem: float, subs: float, tabela: str, dep: int) -> float:
    """IRS a reter pela tabela (0 se não houver tabela para o ano)."""
    if cfg.get("subs_duodecimos", 1):
        c = irs.calcular(ano, mes, rem, subs, tabela, dep)
    else:
        c = irs.calcular(ano, mes, rem, 0.0, tabela, dep, subsidio_inteiro=subs)
    return c["total"] if c else 0.0


def lucro_antes(d: dict, mapa: dict) -> float:
    """Lucro antes de IRC, TA, IES e pagamentos por conta — a mesma conta do Painel (calc.calcular_saldo)."""
    tot = mapa["tot"]
    iva_ganho = sum(t["devolvido"] for t in iva_trimestres(d, mapa))
    gastos = tot["total_salario"] + tot["iva"] + sum(tot[c] for c in CUSTOS_ANTES_SS + ["ss_empresa", "ss_colab"] + CUSTOS_FIM) + tot["total_desp"]
    return sum(tot[c] for c in RECEITAS) + iva_ganho - gastos


def ultimo_mes_faturado(d: dict) -> int:
    rec = [sum(d["inp"][c][i] for c in RECEITAS) for i in range(12)]
    return max([i + 1 for i in range(12) if abs(rec[i]) > 0.005], default=0)


def _salario_base(d: dict) -> dict:
    """Valores do último salário lançado (para repetir nos meses seguintes)."""
    inp = d["inp"]
    meses = [i for i in range(12) if inp["vencimento"][i] > 0]
    if not meses:
        return {"mes": 0, "vencimento": 0.0, "isencao": 0.0, "kms": 0.0, "ajudas": 0.0}
    i = meses[-1]
    return {"mes": i + 1, "vencimento": inp["vencimento"][i], "isencao": inp["isencao"][i], "kms": inp["kms"][i], "ajudas": inp["ajudas"][i]}


def _por_salario(d: dict, mes: int, venc: float, ise: float, kms: float, ajudas: float, tabela: str, dep: int) -> None:
    """Escreve no mapa um salário completo para o mês (substitui o que lá estiver)."""
    cfg, inp, ano = d["cfg"], d["inp"], d["ano"]
    i = mes - 1
    sf, sn = subsidios(cfg, mes, venc, ise)
    inp["vencimento"][i], inp["isencao"][i], inp["sub_ferias"][i], inp["sub_natal"][i] = venc, ise, sf, sn
    inp["sub_alim"][i] = r2(dias_uteis(ano, mes) * cfg["subs_alim_dia"]) if venc > 0 else 0.0
    inp["kms"][i], inp["ajudas"][i] = kms, ajudas
    inp["irs"][i] = irs_mes(ano, cfg, mes, venc + ise, sf + sn, tabela, dep) if venc > 0 else 0.0


def prever(conn: sqlite3.Connection, ano: int, *, valor_dia: float | None = None, extra_mes: float = 0.0, desp_extra_mes: float = 0.0,
           salario: dict | None = None, tabela: str = "I", dependentes: int = 0, metodo: str = "mediana",
           com_despesas: bool = True) -> dict:
    """Ano completo (lançado + previsto). salario = {'vencimento', 'isencao', 'desde'} para simular outro ordenado."""
    base = carregar_ano(conn, ano)
    d = copy.deepcopy(base)
    cfg, inp = d["cfg"], d["inp"]
    k = 1 + cfg["iva"]
    m_real = ultimo_mes_faturado(base)
    vd = cfg["valor_dia"] if valor_dia is None else valor_dia
    meses_prev = list(range(m_real + 1, 13))
    sal = _salario_base(base)

    # custos e despesas: mediana (ou média) mensal dos meses já faturados
    def tipico(vals: list[float]) -> float:
        vals = vals[:m_real]
        if not vals:
            return 0.0
        return median(vals) if metodo == "mediana" else sum(vals) / len(vals)
    media_custo = {c: tipico(base["inp"][c]) for c in CUSTOS_PREVER}
    media_desp = {t: tipico(v) for t, v in base["desp"].items()} if com_despesas else {}  # sem: meses previstos sem despesas avulsas

    for m in meses_prev:
        i = m - 1
        inp["avenca"][i] = r2(dias_uteis(ano, m) * vd * k)
        inp["extra"][i] = r2(extra_mes * k)
        inp["premio"][i] = inp["isento"][i] = 0.0
        if base["inp"]["vencimento"][i] <= 0:  # salário ainda não lançado neste mês
            _por_salario(d, m, sal["vencimento"], sal["isencao"], sal["kms"], sal["ajudas"], tabela, dependentes)
        for c in CUSTOS_PREVER:
            if abs(base["inp"][c][i]) < 0.005:
                inp[c][i] = r2(media_custo[c])
        for t, med in media_desp.items():
            if abs(base["desp"][t][i]) < 0.005:
                d["desp"][t][i] = r2(med)
    if desp_extra_mes:
        d["desp"][DESPESA_EXTRA] = [0.0] * 12
        for m in meses_prev:
            d["desp"][DESPESA_EXTRA][m - 1] = r2(desp_extra_mes)

    # outro ordenado, a partir do mês indicado (também em meses já passados, para ver «e se tivesse sido»)
    if salario:
        desde = max(1, min(12, int(salario.get("desde") or 1)))
        for m in range(desde, 13):
            i = m - 1
            kms = inp["kms"][i] if inp["vencimento"][i] > 0 else sal["kms"]
            aj = inp["ajudas"][i] if inp["vencimento"][i] > 0 else sal["ajudas"]
            _por_salario(d, m, salario["vencimento"], salario.get("isencao", 0.0), kms, aj, tabela, dependentes)

    mapa = calcular_mapa(d)
    v, tot = mapa["v"], mapa["tot"]
    lucro = lucro_antes(d, mapa)
    irc_est = max(0.0, lucro) * cfg["irc_taxa"]
    apos_irc = lucro - irc_est
    div_liq = max(0.0, apos_irc) * (1 - cfg["dividendos_taxa"])
    iva_ganho = sum(t["devolvido"] for t in iva_trimestres(d, mapa))
    gastos_mes = [v["receitas"][i] - v["rend_gastos_desp"][i] for i in range(12)]

    sal_bruto = sum(tot[c] for c in ("vencimento", "isencao", "sub_ferias", "sub_natal"))
    salario_res = {
        "bruto": sal_bruto,  # vencimento + isenção + subsídios (base da SS)
        "outros": tot["sub_alim"] + tot["kms"] + tot["ajudas"],  # não pagam SS nem IRS (dentro dos limites)
        "ss_empresa": tot["ss_empresa"], "ss_colab": tot["ss_colab"], "irs": tot["irs"],
        "custo_empresa": sal_bruto + tot["sub_alim"] + tot["kms"] + tot["ajudas"] + tot["ss_empresa"],
        "liquido": tot["total_salario"],  # o que chega à conta do sócio
        "estado": tot["irs"] + tot["ss_colab"] + tot["ss_empresa"],
    }
    acumulado, ac = [], 0.0
    for i in range(12):
        ac += v["rend_gastos_desp"][i]
        acumulado.append(ac)
    meses = [{"mes": i + 1, "previsto": (i + 1) in meses_prev, "receitas": v["receitas"][i], "gastos": gastos_mes[i],
              "resultado": v["rend_gastos_desp"][i], "acumulado": acumulado[i]} for i in range(12)]
    return {
        "ano": ano, "m_real": m_real, "metodo": metodo, "com_despesas": com_despesas, "meses_prev": meses_prev, "valor_dia": vd, "extra_mes": extra_mes, "desp_extra_mes": desp_extra_mes,
        "meses": meses, "iva_ganho": iva_ganho, "lucro": lucro, "irc_est": irc_est, "irc_taxa": cfg["irc_taxa"], "apos_irc": apos_irc,
        "div_taxa": cfg["dividendos_taxa"], "div_liquido": div_liq, "salario": salario_res, "sal_base": sal,
        "total_socio": salario_res["liquido"] + div_liq,
        "receitas": sum(v["receitas"]), "gastos": sum(gastos_mes),
        "medias": {"custos": sum(media_custo.values()), "despesas": sum(media_desp.values())},
    }
