"""Mapas de exploração da contabilidade guardados na base de dados (Configurações → Contabilidade).

Guarda-se o conteúdo já lido do Excel (core.simulacao.ler_mapa), em JSON: é pequeno e chega para refazer a
comparação. O último mapa de cada ano é o que a Simulação e o Painel usam.
"""
from __future__ import annotations

import json
import sqlite3
from datetime import datetime

from . import simulacao


def guardar(conn: sqlite3.Connection, caminho: str, ficheiro: str) -> dict:
    """Lê o Excel, confere-o contra a aplicação (para validar) e guarda-o. Devolve o resultado da comparação."""
    mapa = simulacao.ler_mapa(caminho)
    res = simulacao.comparar(conn, mapa)  # levanta ErroMapa se o ano não existir ou não houver movimento
    conn.execute("INSERT INTO mapa_exploracao (ano, ate_mes, ficheiro, carregado, dados) VALUES (?,?,?,?,?)",
                 (mapa["ano"], res["meses"][-1] + 1, ficheiro, datetime.now().strftime("%Y-%m-%d %H:%M"), json.dumps(mapa, ensure_ascii=False)))
    conn.commit()
    return res


def listar(conn: sqlite3.Connection) -> list[dict]:
    ultimos = {r[0]: r[1] for r in conn.execute("SELECT ano, MAX(id) FROM mapa_exploracao GROUP BY ano")}
    return [{**dict(r), "ultimo": ultimos.get(r["ano"]) == r["id"]}
            for r in conn.execute("SELECT id, ano, ate_mes, ficheiro, carregado FROM mapa_exploracao ORDER BY ano DESC, id DESC")]


def obter(conn: sqlite3.Connection, ano: int, id_: int | None = None) -> tuple[dict, dict] | None:
    """(info, mapa) do mapa pedido ou, sem id, do último carregado para o ano."""
    if id_:
        r = conn.execute("SELECT * FROM mapa_exploracao WHERE id=? AND ano=?", (id_, ano)).fetchone()
    else:
        r = conn.execute("SELECT * FROM mapa_exploracao WHERE ano=? ORDER BY id DESC LIMIT 1", (ano,)).fetchone()
    if r is None:
        return None
    info = {k: r[k] for k in ("id", "ano", "ate_mes", "ficheiro", "carregado")}
    return info, json.loads(r["dados"])


def comparar_guardado(conn: sqlite3.Connection, ano: int, id_: int | None = None) -> tuple[dict, dict] | None:
    """(info, resultado da comparação) com o mapa guardado, ou None se não houver."""
    m = obter(conn, ano, id_)
    if m is None:
        return None
    info, mapa = m
    try:
        return info, simulacao.comparar(conn, mapa)
    except simulacao.ErroMapa:
        return None


def apagar(conn: sqlite3.Connection, id_: int) -> bool:
    n = conn.execute("DELETE FROM mapa_exploracao WHERE id=?", (id_,)).rowcount
    conn.commit()
    return bool(n)
