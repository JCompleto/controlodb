"""Conta-corrente do sócio (v1.11.0): despesas pagas por ele e os reembolsos que a empresa lhe fez.

Não há uma tabela própria: cada despesa com «Paguei eu (sócio)» é uma entrada (a empresa passa a dever-lhe
o valor, na data da despesa) e, quando é marcada como reembolsada, uma saída (na data do reembolso).
Os reembolsos feitos no mesmo dia juntam-se numa só linha, como na transferência do banco.
"""
from __future__ import annotations

import json
import sqlite3

DESCRICAO_INICIAL = "Dívida ao sócio no início"


def inicial(conn: sqlite3.Connection) -> dict | None:
    """Dívida ao sócio que já existia quando a empresa começou a usar a aplicação (v1.14.0)."""
    r = conn.execute("SELECT valor FROM definicao WHERE chave='socio_inicial'").fetchone()
    if not r or not r[0]:
        return None
    try:
        d = json.loads(r[0])
        return {"valor": float(d["valor"]), "data": d["data"], "pago": d.get("pago")}
    except (ValueError, KeyError, TypeError):
        return None


def gravar_inicial(conn: sqlite3.Connection, valor: float, data: str) -> None:
    conn.execute("INSERT INTO definicao (chave, valor) VALUES ('socio_inicial', ?) ON CONFLICT(chave) DO UPDATE SET valor=excluded.valor",
                 (json.dumps({"valor": round(valor, 2), "data": data, "pago": None}),))


def reembolsar_inicial(conn: sqlite3.Connection, dia: str) -> float:
    """Marca a dívida inicial como reembolsada. Como não é uma despesa (não é custo deste período), a saída do
    dinheiro entra no saldo «Real» como ajuste (tabela «pagamento»), no ano do reembolso."""
    i = inicial(conn)
    if not i or i["pago"]:
        return 0.0
    conn.execute("INSERT INTO pagamento (ano, rubrica, valor, data, descricao) VALUES (?, 'retirar', ?, ?, ?)",
                 (int(dia[:4]), i["valor"], dia, "Reembolso da dívida ao sócio que vinha de antes"))
    conn.execute("UPDATE definicao SET valor=? WHERE chave='socio_inicial'",
                 (json.dumps({"valor": i["valor"], "data": i["data"], "pago": dia}),))
    return i["valor"]


def movimentos(conn: sqlite3.Connection) -> list[dict]:
    """Todos os movimentos, por ordem de data, com o saldo (dívida ao sócio) depois de cada um."""
    linhas: list[dict] = []
    reembolsos: dict[str, dict] = {}
    ini = inicial(conn)
    if ini:
        linhas.append({"data": ini["data"], "tipo": "inicial", "id": None, "descricao": DESCRICAO_INICIAL,
                       "det": "o que a empresa já lhe devia quando começou a usar a aplicação", "entrada": ini["valor"],
                       "saida": 0.0, "documento": None, "reembolsada": bool(ini["pago"])})
        if ini["pago"]:
            reembolsos[ini["pago"]] = {"data": ini["pago"], "tipo": "reembolso", "id": None, "descricao": "Reembolso ao sócio",
                                       "det": "", "entrada": 0.0, "saida": ini["valor"], "n": 0, "documento": None, "inicial": True}
    for r in conn.execute("SELECT * FROM despesa WHERE COALESCE(pago_por, 'socio') <> 'empresa' ORDER BY data, id"):
        doc = r["documento"] if "documento" in r.keys() else None
        linhas.append({"data": r["data"], "tipo": "despesa", "id": r["id"], "descricao": r["descricao"] or r["tipo"],
                       "det": r["tipo"], "entrada": r["valor"], "saida": 0.0, "documento": doc,
                       "reembolsada": bool(r["pago"])})
        if r["pago"]:
            dia = r["data_pagamento"] or r["data"]  # reembolsada sem data: conta no dia da despesa
            g = reembolsos.setdefault(dia, {"data": dia, "tipo": "reembolso", "id": None, "descricao": "Reembolso ao sócio",
                                            "det": "", "entrada": 0.0, "saida": 0.0, "n": 0, "documento": None})
            g["saida"] += r["valor"]
            g["n"] += 1
    for g in reembolsos.values():
        g["det"] = (f"{g['n']} despesa{'s' if g['n'] != 1 else ''}" if g["n"] else "") + \
                   (" + dívida que vinha de antes" if g.get("inicial") and g["n"] else ("dívida que vinha de antes" if g.get("inicial") else ""))
        linhas.append(g)
    # no mesmo dia: primeiro as despesas, depois o reembolso
    linhas.sort(key=lambda l: (l["data"], l["tipo"] != "inicial", l["tipo"] == "reembolso", l["id"] or 0))
    saldo = 0.0
    for l in linhas:
        saldo = round(saldo + l["entrada"] - l["saida"], 2)
        l["saldo"] = saldo
    return linhas


def resumo_ano(conn: sqlite3.Connection, ano: int) -> dict:
    todos = movimentos(conn)
    a = str(ano)
    antes = [l for l in todos if l["data"][:4] < a]
    doano = [l for l in todos if l["data"][:4] == a]
    depois = [l for l in todos if l["data"][:4] > a]
    inicial_v = antes[-1]["saldo"] if antes else 0.0
    final = doano[-1]["saldo"] if doano else inicial_v
    pendentes = [dict(r) for r in conn.execute(
        "SELECT id, data, valor, descricao, tipo FROM despesa WHERE COALESCE(pago_por, 'socio') <> 'empresa' AND pago=0 ORDER BY data, id")]
    ini = inicial(conn)
    return {"linhas": list(reversed(doano)), "inicial": inicial_v, "final": final, "divida_antes": ini if ini and not ini["pago"] else None,
            "pago": round(sum(l["entrada"] for l in doano if l["tipo"] == "despesa"), 2), "reembolsado": round(sum(l["saida"] for l in doano), 2),
            "atual": todos[-1]["saldo"] if todos else 0.0, "tem_seguintes": bool(depois), "pendentes": pendentes}


def contabilidade(conn: sqlite3.Connection, ano: int) -> dict | None:
    r = conn.execute("SELECT valor FROM definicao WHERE chave=?", (f"socio_contab_{ano}",)).fetchone()
    if not r or not r[0]:
        return None
    try:
        valor, data = r[0].split("|", 1)
        return {"valor": float(valor), "data": data or None}
    except ValueError:
        return None


def gravar_contabilidade(conn: sqlite3.Connection, ano: int, valor: float | None, data: str | None) -> None:
    chave = f"socio_contab_{ano}"
    if valor is None:
        conn.execute("DELETE FROM definicao WHERE chave=?", (chave,))
    else:
        conn.execute("INSERT INTO definicao (chave, valor) VALUES (?, ?) ON CONFLICT(chave) DO UPDATE SET valor=excluded.valor",
                     (chave, f"{valor:.2f}|{data or ''}"))
    conn.commit()


def explicar_diferenca(pendentes: list[dict], todos: list[dict], dif: float) -> dict | None:
    """Se a diferença for igual a uma despesa recente, aponta-a (é quase sempre uma despesa ainda não lançada na contabilidade)."""
    if abs(dif) < 0.005:
        return None
    cand = [l for l in todos if l["tipo"] == "despesa" and abs(l["entrada"] - abs(dif)) < 0.005]
    return cand[-1] if cand else None
