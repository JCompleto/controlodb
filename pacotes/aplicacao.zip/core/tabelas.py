"""Verificações: compara as taxas configuradas com as tabelas oficiais guardadas em tabelas_fiscais.json."""
from __future__ import annotations

import json
import sqlite3
from pathlib import Path

FICHEIRO = Path(__file__).with_name("tabelas_fiscais.json")


def carregar() -> dict:
    try:
        return json.loads(FICHEIRO.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def verificar(conn: sqlite3.Connection, ano: int) -> dict:
    """Devolve {'anos_com_tabela': bool, 'linhas': [...]} para o ano pedido."""
    cfg = conn.execute("SELECT * FROM config_ano WHERE ano=?", (ano,)).fetchone()
    tab = carregar().get(str(ano), {})
    linhas = []
    for campo, ref in tab.items():
        app_v = cfg[campo]
        igual = abs(app_v - ref["valor"]) < 1e-9
        linhas.append({"campo": campo, "nome": ref["nome"], "app": app_v, "ref": ref["valor"], "ok": igual,
                       "nota": ref.get("nota"), "fonte": ref.get("fonte"), "url": ref.get("url"), "confirmado": ref.get("confirmado")})
    return {"tem_tabela": bool(tab), "linhas": linhas}


def valor_oficial(ano: int, campo: str) -> float | None:
    ref = carregar().get(str(ano), {}).get(campo)
    return ref["valor"] if ref else None
