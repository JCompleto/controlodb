"""Escolha da base de dados no arranque: listar, abrir, criar e lembrar a última usada."""
from __future__ import annotations

import json
import re
import sqlite3
from datetime import datetime
from pathlib import Path

from .db import EMPRESA_PADRAO, RAIZ, get_conn, gravar_nome_empresa

PASTA_DADOS = RAIZ / "dados"
FICHEIRO_ESTADO = PASTA_DADOS / "bases.json"
CABECALHO_SQLITE = b"SQLite format 3\x00"
NOME_VALIDO = re.compile(r"^[\w .()-]{1,80}$", re.UNICODE)


class ErroBase(ValueError):
    """Mensagem pensada para o utilizador."""


def _ler_estado() -> dict:
    try:
        return json.loads(FICHEIRO_ESTADO.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _gravar_estado(estado: dict) -> None:
    try:
        PASTA_DADOS.mkdir(parents=True, exist_ok=True)
        FICHEIRO_ESTADO.write_text(json.dumps(estado, ensure_ascii=False, indent=1), encoding="utf-8")
    except OSError:
        pass  # lembrar a última base é um extra; nunca deve impedir o uso


def ultima() -> Path | None:
    p = _ler_estado().get("ultima")
    return Path(p) if p and Path(p).is_file() else None


def lembrar(caminho: Path) -> None:
    est = _ler_estado()
    c = str(caminho)
    rec = [x for x in est.get("recentes", []) if x != c and Path(x).is_file()]
    est["ultima"], est["recentes"] = c, ([c] + rec)[:8]
    _gravar_estado(est)


def _resumo(p: Path) -> dict:
    info = {"caminho": str(p), "nome": p.name, "pasta": str(p.parent), "tamanho_kb": max(1, p.stat().st_size // 1024),
            "alterada": datetime.fromtimestamp(p.stat().st_mtime).strftime("%d/%m/%Y %H:%M"), "anos": "", "empresa": "", "demo": False}
    try:
        c = sqlite3.connect(f"file:{p}?mode=ro", uri=True)
        anos = [r[0] for r in c.execute("SELECT ano FROM config_ano ORDER BY ano")]
        tem_def = c.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='definicao'").fetchone()
        r = c.execute("SELECT valor FROM definicao WHERE chave='empresa'").fetchone() if tem_def else None
        info["demo"] = bool(tem_def and c.execute("SELECT 1 FROM definicao WHERE chave='demo' AND valor='1'").fetchone())
        c.close()
        info["empresa"] = (r[0] if r and r[0] else "") or (EMPRESA_PADRAO if anos else "")
        info["anos"] = f"{anos[0]}–{anos[-1]}" if len(anos) > 1 else (str(anos[0]) if anos else "vazia")
    except sqlite3.Error:
        info["anos"] = "?"
    return info


def disponiveis() -> list[dict]:
    """Bases na pasta «dados» e as usadas recentemente noutras pastas (a última primeiro)."""
    vistos: dict[str, Path] = {}
    if PASTA_DADOS.is_dir():
        for p in sorted(PASTA_DADOS.glob("*.db")):
            vistos[str(p)] = p
    for c in _ler_estado().get("recentes", []):
        if Path(c).is_file():
            vistos.setdefault(c, Path(c))
    ult = str(ultima() or "")
    out = [_resumo(p) for p in vistos.values()]
    for i in out:
        i["ultima"] = i["caminho"] == ult
    out.sort(key=lambda i: (not i["ultima"], i["nome"].lower()))
    return out


def validar_existente(texto: str) -> Path:
    texto = (texto or "").strip().strip('"')
    if not texto:
        raise ErroBase("Indique o ficheiro da base de dados.")
    p = Path(texto).expanduser()
    if not p.is_absolute():
        p = PASTA_DADOS / p
    if not p.is_file():
        raise ErroBase(f"Não encontro o ficheiro «{p}».")
    with p.open("rb") as f:
        if f.read(16) != CABECALHO_SQLITE:
            raise ErroBase("Esse ficheiro não é uma base de dados SQLite.")
    try:
        c = sqlite3.connect(f"file:{p}?mode=ro", uri=True)
        tabelas = {r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        c.close()
    except sqlite3.Error as e:
        raise ErroBase(f"Não consegui abrir a base: {e}") from None
    if tabelas and "config_ano" not in tabelas:
        raise ErroBase("Essa base de dados não é do Controlo Empresa.")
    return p.resolve()


def caminho_novo(nome: str, pasta: str = "") -> Path:
    nome = (nome or "").strip()
    if nome.lower().endswith(".db"):
        nome = nome[:-3].strip()
    if not nome or not NOME_VALIDO.match(nome) or nome.strip(".") == "":
        raise ErroBase("Escolha um nome com letras, números, espaços, «-» ou «_» (até 80 caracteres).")
    destino = Path(pasta.strip().strip('"')).expanduser() if (pasta or "").strip() else PASTA_DADOS
    if not destino.is_absolute():
        raise ErroBase("A pasta tem de ser um caminho completo, por exemplo C:\\Users\\…\\Documentos.")
    p = destino / f"{nome}.db"
    if p.exists():
        raise ErroBase(f"Já existe «{p.name}» nessa pasta. Escolha outro nome ou abra a existente.")
    try:
        destino.mkdir(parents=True, exist_ok=True)
    except OSError as e:
        raise ErroBase(f"Não consegui usar a pasta: {e}") from None
    return p


def renomear(caminho: str, nome: str) -> Path:
    """Muda o nome do ficheiro da base (fica na mesma pasta) e acerta a lista das bases recentes."""
    antigo = validar_existente(caminho)
    novo = caminho_novo(nome, str(antigo.parent))  # valida o nome e recusa um que já exista
    try:
        antigo.rename(novo)
        for suf in ("-wal", "-shm", "-journal"):
            extra = antigo.with_name(antigo.name + suf)
            if extra.exists():
                extra.rename(novo.with_name(novo.name + suf))
    except OSError as e:
        raise ErroBase(f"Não consegui mudar o nome (feche outros programas que usem o ficheiro): {e}") from None
    est = _ler_estado()
    a, n = str(antigo), str(novo.resolve())
    est["recentes"] = [n if x == a else x for x in est.get("recentes", [])]
    if est.get("ultima") == a:
        est["ultima"] = n
    _gravar_estado(est)
    return novo.resolve()


def mudar_empresa(caminho: str, nome: str) -> None:
    """Grava o nome da empresa dentro de uma base de dados (não precisa de estar aberta)."""
    p = validar_existente(caminho)
    try:
        conn = get_conn(p)
        try:
            gravar_nome_empresa(conn, nome)
        finally:
            conn.close()
    except ValueError as e:
        raise ErroBase(str(e)) from None
    except sqlite3.Error as e:
        raise ErroBase(f"Não consegui gravar o nome da empresa: {e}") from None


def eliminar_demo(caminho: str) -> Path:
    """Apaga uma base de demonstração (recusa qualquer outra) e tira-a da lista das recentes."""
    p = validar_existente(caminho)
    try:
        c = sqlite3.connect(f"file:{p}?mode=ro", uri=True)
        tem_def = c.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='definicao'").fetchone()
        e_demo = bool(tem_def and c.execute("SELECT 1 FROM definicao WHERE chave='demo' AND valor='1'").fetchone())
        c.close()
    except sqlite3.Error as e:
        raise ErroBase(f"Não consegui ler a base: {e}") from None
    if not e_demo:
        raise ErroBase("Só se podem eliminar bases de demonstração. As bases com dados reais não se apagam aqui.")
    try:
        for suf in ("", "-wal", "-shm", "-journal"):
            f = p.with_name(p.name + suf)
            if f.exists():
                f.unlink()
    except OSError as e:
        raise ErroBase(f"Não consegui eliminar (feche outros programas que usem o ficheiro): {e}") from None
    est = _ler_estado()
    est["recentes"] = [x for x in est.get("recentes", []) if Path(x).resolve() != p]
    if est.get("ultima") and Path(est["ultima"]).resolve() == p:
        est["ultima"] = est["recentes"][0] if est["recentes"] else None
    _gravar_estado(est)
    return p
