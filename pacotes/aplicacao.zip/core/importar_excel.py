"""Importa o Excel "Controlo Empresa.xlsx" (folhas por ano + folha Despesas) para a base de dados.

Uso:  python -m core.importar_excel "Controlo Empresa.xlsx" [--limpar]
"""
from __future__ import annotations

import re
import sqlite3
import sys
import unicodedata
from datetime import date, datetime

import openpyxl

from .db import criar_ano, get_conn

GRELHA = {  # etiqueta normalizada -> código da rubrica
    "factura avenca": "avenca", "factura extra": "extra", "fatura premio": "premio",
    "factura isento de iva": "isento", "vencimento base": "vencimento",
    "isencao horario de trabalho": "isencao", "subs. ferias (100% c/duodecimos)": "sub_ferias",
    "subs. natal (100% c/duodecimos)": "sub_natal", "subs. alimentacao": "sub_alim",
    "kms em viatura propria": "kms", "ajudas custo nacional": "ajudas", "contabilista": "contabilista",
    "man. conta": "man_conta", "mcontabilidade - conta": "mcontab_conta", "luz": "luz",
    "custos bancarios transf": "custos_banc", "renda": "renda", "carro": "carro",
    "outras despesas": "outras", "irs": "irs", "fct": "fct", "fgct": "fgct",
}
SALDO = {  # etiqueta normalizada do bloco Saldo -> código de pagamento real
    "receitas": "receitas", "irc,ta,ies,pag p/ conta": "irc_etc", "total custos salario": "salario",
    "iva": "iva", "contabilista": "contabilista", "man. conta": "man_conta",
    "mcontabilidade - conta": "mcontab_conta", "luz": "luz", "custos bancarios transf": "custos_banc",
    "renda": "renda", "carro": "carro", "outras despesas": "outras", "irs": "irs",
    "ss empresa": "ss_empresa", "ss colaborador": "ss_colab", "fct": "fct", "fgct": "fgct",
    "total a retirar": "retirar",
}
_NUM = re.compile(r"[+-]?\d+(?:\.\d+)?")
_SOMA_PURA = re.compile(r"^=\s*[-+]?\d+(?:\.\d+)?(?:\s*[-+]\s*\d+(?:\.\d+)?)*\s*$")


def _norm(s) -> str:
    s = unicodedata.normalize("NFKD", str(s)).encode("ascii", "ignore").decode().lower().strip()
    return s.rstrip(".").strip()


def _num(x) -> float:
    return float(x) if isinstance(x, (int, float)) else 0.0


def _parcelas(formula, cache) -> list[float]:
    """'=750+750+250' -> [750, 750, 250]; fórmulas com referências -> valor calculado em cache."""
    if isinstance(formula, str) and _SOMA_PURA.match(formula):
        return [float(t.replace(" ", "")) for t in _NUM.findall(formula)]
    return [] if cache in (None, 0, 0.0) else [float(cache)]


def _importar_ano(conn, ws_f, ws_v, ano: int, rel: dict) -> None:
    criar_ano(conn, ano)
    linha_saldo = next((r for r in range(1, ws_f.max_row + 1) if _norm(ws_f.cell(r, 1).value or "") == "saldo"), None)
    if linha_saldo is None:
        raise ValueError(f"Folha {ano}: não encontrei o bloco 'Saldo'")

    # --- mapa mensal (linhas 4..28, só rubricas de entrada)
    n = 0
    for r in range(4, 29):
        cod = GRELHA.get(_norm(ws_f.cell(r, 1).value or ""))
        if not cod:
            continue
        for mes in range(1, 13):
            f, c = ws_f.cell(r, 1 + mes).value, ws_v.cell(r, 1 + mes).value
            if f is None:
                continue
            if isinstance(f, str) and f.startswith("=") and c is None:
                raise ValueError(f"{ano} {ws_f.cell(r,1).value} mês {mes}: fórmula sem valor em cache (abra e grave o Excel)")
            valor = _num(c if isinstance(f, str) and f.startswith("=") else f)
            if abs(valor) < 0.005:
                continue
            nota = f"Excel: {f}" if isinstance(f, str) and f.startswith("=") else None
            conn.execute("INSERT INTO movimento (ano, mes, rubrica, valor, nota) VALUES (?,?,?,?,?)", (ano, mes, cod, valor, nota))
            n += 1
    rel["movimentos"] += n

    # --- bloco Saldo: Capital, Saldo anterior, coluna Real
    cap = _num(ws_v.cell(linha_saldo + 2, 2).value)
    ant = _num(ws_v.cell(linha_saldo + 3, 2).value) if not str(ws_f.cell(linha_saldo + 3, 2).value).startswith("='") else 0.0
    ant_real = _num(ws_v.cell(linha_saldo + 3, 3).value) if not str(ws_f.cell(linha_saldo + 3, 3).value).startswith("='") else 0.0
    conn.execute("UPDATE config_ano SET capital_social=?, saldo_inicial_est=?, saldo_inicial_real=? WHERE ano=?", (cap, ant, ant_real, ano))
    for r in range(linha_saldo + 4, linha_saldo + 25):
        lab = _norm(ws_f.cell(r, 1).value or "")
        if lab.startswith("total receitas"):
            break
        cod = SALDO.get(lab)
        if not cod:
            continue
        f, c = ws_f.cell(r, 3).value, ws_v.cell(r, 3).value
        for p in _parcelas(f, c):
            conn.execute("INSERT INTO pagamento (ano, rubrica, valor, descricao) VALUES (?,?,?,?)", (ano, cod, p, "Importado do Excel (coluna Real)"))
            rel["pagamentos"] += 1

    # --- IVA trimestral, impostos, taxas
    for r in range(1, ws_f.max_row + 1):
        lab = str(ws_f.cell(r, 6).value or "")
        if lab.startswith("1º Trimestre"):
            for t in range(4):
                pago = ws_v.cell(r + t, 8).value
                conn.execute("UPDATE iva_trimestre SET pago=? WHERE ano=? AND trimestre=?", (pago if isinstance(pago, (int, float)) else None, ano, t + 1))
        if _norm(lab) in ("irc", "ta", "ies", "pag. p/ conta") and isinstance(ws_v.cell(r, 7).value, (int, float)):
            col = {"irc": "irc", "ta": "ta", "ies": "ies", "pag. p/ conta": "pag_conta"}[_norm(lab)]
            conn.execute(f"UPDATE imposto_ano SET {col}=? WHERE ano=?", (ws_v.cell(r, 7).value, ano))
        if str(ws_f.cell(r, 8).value or "") == "IRC Estimado" and isinstance(ws_v.cell(r, 10).value, (int, float)):
            conn.execute("UPDATE config_ano SET irc_taxa=? WHERE ano=?", (ws_v.cell(r, 10).value, ano))
        if str(ws_f.cell(r, 9).value or "") == "Dividendos":
            for rr in range(r + 1, r + 4):
                if isinstance(ws_v.cell(rr, 10).value, (int, float)):
                    conn.execute("UPDATE config_ano SET dividendos_taxa=? WHERE ano=?", (ws_v.cell(rr, 10).value, ano))
                    break


def _importar_despesas(conn, ws, rel: dict) -> None:
    for r in range(2, ws.max_row + 1):
        d, valor = ws.cell(r, 1).value, ws.cell(r, 2).value
        if d is None or valor is None:
            continue
        if isinstance(d, datetime):
            d = d.date()
        if not isinstance(d, date):
            continue
        tipo = ws.cell(r, 4).value or "Outras despesas"
        conn.execute("INSERT OR IGNORE INTO tipo_despesa (nome) VALUES (?)", (tipo,))
        conn.execute(
            "INSERT INTO despesa (data, valor, descricao, tipo, meio, notas) VALUES (?,?,?,?,?,?)",
            (d.isoformat(), float(valor), ws.cell(r, 3).value, tipo, None, ws.cell(r, 5).value),
        )
        rel["despesas"] += 1


def limpar(conn: sqlite3.Connection) -> None:
    for t in ("movimento", "pagamento", "despesa", "iva_trimestre", "imposto_ano", "config_ano"):
        conn.execute(f"DELETE FROM {t}")
    conn.commit()


def importar(caminho, conn: sqlite3.Connection, substituir: bool = False) -> dict:
    if conn.execute("SELECT COUNT(*) FROM config_ano").fetchone()[0] and not substituir:
        raise RuntimeError("A base de dados já tem dados. Use 'substituir' para a limpar primeiro.")
    wb_f = openpyxl.load_workbook(caminho)
    wb_v = openpyxl.load_workbook(caminho, data_only=True)
    rel = {"anos": [], "movimentos": 0, "pagamentos": 0, "despesas": 0}
    try:
        if substituir:
            limpar(conn)
        anos = sorted(int(n) for n in wb_f.sheetnames if n.isdigit())
        for ano in anos:
            _importar_ano(conn, wb_f[str(ano)], wb_v[str(ano)], ano, rel)
            rel["anos"].append(ano)
        if "Despesas" in wb_f.sheetnames:
            _importar_despesas(conn, wb_v["Despesas"], rel)
        from . import legado

        rel["conversao"] = legado.converter_tudo(conn)  # «Real» do Excel -> lançamentos pagos
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    return rel


if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    c = get_conn()
    print(importar(sys.argv[1], c, substituir="--limpar" in sys.argv))
