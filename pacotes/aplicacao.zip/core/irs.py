"""Retenção na fonte de IRS sobre o salário (trabalho dependente, Continente), pelas tabelas oficiais em tabelas_fiscais.json.

Retenção = R × taxa marginal máxima − parcela a abater − n.º de dependentes × parcela adicional (nunca abaixo de zero),
em que R é a remuneração mensal (vencimento + isenção de horário). Os subsídios de férias e de Natal em duodécimos
levam a mesma taxa efetiva (estimativa: o despacho não traz regra própria para duodécimos). Kms, ajudas de custo e
subsídio de alimentação dentro dos limites legais não pagam IRS.
"""
from __future__ import annotations

from .tabelas import carregar

TABELAS = ("I", "II", "III")


def dados(ano: int) -> dict | None:
    return carregar().get("irs_retencao", {}).get(str(ano))


def _linha(linhas: list, r: float) -> tuple[int, list]:
    for i, l in enumerate(linhas):
        if l[0] is None or r <= l[0] + 1e-9:
            return i, l
    return len(linhas) - 1, linhas[-1]


def _reter(linhas: list, r: float, dependentes: int) -> tuple[float, int, float]:
    i, (_, taxa, parcela, adicional) = _linha(linhas, r)
    if isinstance(parcela, dict):
        parcela = taxa * parcela["k"] * (parcela["c"] - r)
    return max(0.0, r * taxa - parcela - max(dependentes, 0) * adicional), i, taxa


def calcular(ano: int, mes: int, remuneracao: float, duodecimos: float = 0.0, tabela: str = "I", dependentes: int = 0,
             subsidio_inteiro: float = 0.0) -> dict | None:
    """Retenção esperada de um mês. None se não houver tabela para esse ano.
    duodecimos: subsídios pagos em duodécimos (mesma taxa efetiva do vencimento).
    subsidio_inteiro: subsídio pago por inteiro neste mês (retenção autónoma: a tabela aplica-se ao subsídio sozinho)."""
    d = dados(ano)
    if not d or tabela not in d["tabelas"]:
        return None
    linhas = d["tabelas"][tabela]["linhas"]
    r = max(remuneracao, 0.0)
    base, i, taxa = _reter(linhas, r, dependentes)
    efetiva = base / r if r else 0.0
    sub = duodecimos * efetiva
    if subsidio_inteiro > 0:
        sub += _reter(linhas, subsidio_inteiro, dependentes)[0]
    ajuste = None
    for a in d.get("ajustes", []):
        penultimo = linhas[-2][0]
        if a["mes"] == mes and not (a.get("exceto_acima_penultimo") and r > penultimo):
            ajuste = a
            base, sub = base * a["fator"], sub * a["fator"]
    total = round(base + sub, 2)  # o despacho não fixa arredondamento: ao cêntimo
    return {"total": total, "base": round(base, 2), "duodecimos": round(sub, 2), "taxa": taxa, "efetiva": efetiva,
            "escalao": i + 1, "isento": taxa == 0, "ajuste": ajuste, "tabela": tabela, "dependentes": dependentes,
            "nome_tabela": d["tabelas"][tabela]["nome"], "fonte": d["fonte"], "url": d["url"]}


def tabela_para_js(ano: int) -> dict | None:
    """Só o necessário para o formulário do salário calcular em direto."""
    d = dados(ano)
    if not d:
        return None
    return {"tabelas": {k: v["linhas"] for k, v in d["tabelas"].items()}, "ajustes": d.get("ajustes", [])}
