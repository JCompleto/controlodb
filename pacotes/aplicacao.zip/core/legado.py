"""Conversão do modelo antigo («pagamentos reais» soltos) para o estado «pago» em cada lançamento.

Antes: a coluna «Real» do saldo era uma lista de pagamentos por rubrica, sem ligação aos lançamentos.
Agora: cada lançamento diz se já foi pago/recebido. Para não perder nada, os pagamentos antigos são
casados com os lançamentos por ordem cronológica (soma acumulada em cêntimos); o que sobrar fica como
«ajuste» na tabela `pagamento`, para o Real continuar a bater certo com o Excel.
"""
from __future__ import annotations

import sqlite3

from . import calc

IMPOSTOS = ["irc", "ta", "ies", "pag_conta"]
LINHAS_ESTADO = ["irs", "ss_empresa", "ss_colab"]


def _c(x: float) -> int:
    return int(round(float(x) * 100))


def _prefixo(itens: list[tuple[object, float]], alvo: float) -> tuple[list[object], float]:
    """Escolhe, por ordem, os primeiros itens cuja soma é o alvo (pode haver notas de crédito, negativas).
    Se nenhum prefixo der exatamente o alvo, fica o maior prefixo que não o ultrapassa."""
    alvo_c = _c(alvo)
    if alvo_c <= 0:
        return [], 0.0
    acum, melhor, exato, ate = 0, 0, None, []
    for ident, valor in itens:
        vc = _c(valor)
        if vc == 0:
            continue
        if vc > 0 and acum + vc > alvo_c and exato is None:
            break
        acum += vc
        ate.append(ident)
        if acum == alvo_c:
            exato = len(ate)
        melhor = len(ate)
    n = exato if exato is not None else melhor
    pagos = ate[:n]
    soma = sum(_c(v) for i_, v in itens if i_ in set(pagos))
    return pagos, soma / 100


def converter_tudo(conn: sqlite3.Connection) -> dict:
    rel = {"ajustes": [], "impostos": 0}
    anos = [r[0] for r in conn.execute("SELECT ano FROM config_ano ORDER BY ano")]
    for ano in anos:
        _converter_ano(conn, ano, rel)
    conn.commit()
    return rel


def _converter_ano(conn: sqlite3.Connection, ano: int, rel: dict) -> None:
    # 1) impostos do ano passam a ser lançamentos (mês 12 quando a data real é desconhecida)
    imp = conn.execute("SELECT * FROM imposto_ano WHERE ano=?", (ano,)).fetchone()
    if imp:
        for cod in IMPOSTOS:
            v = imp[cod] or 0.0
            if abs(v) >= 0.005:
                conn.execute(
                    "INSERT INTO movimento (ano, mes, rubrica, valor, nota) VALUES (?,?,?,?,?)",
                    (ano, 12, cod, v, "Convertido do mapa de impostos anterior (mês assumido: Dezembro)"),
                )
                rel["impostos"] += 1
        conn.execute("DELETE FROM imposto_ano WHERE ano=?", (ano,))

    d = calc.carregar_ano(conn, ano)
    mapa = calc.calcular_mapa(d)
    v = mapa["v"]
    legado: dict[str, float] = {}
    for r in conn.execute("SELECT rubrica, SUM(valor) s FROM pagamento WHERE ano=? GROUP BY rubrica", (ano,)):
        legado[r["rubrica"]] = r["s"]
    conn.execute("DELETE FROM pagamento WHERE ano=?", (ano,))
    residuos: dict[str, float] = {}

    def ajusta(cod: str, alvo: float, pago: float) -> None:
        if abs(alvo - pago) >= 0.005:
            residuos[cod] = alvo - pago

    # 2) receitas e custos ordinários: um item por lançamento
    def por_lancamentos(cod_linha: str, rubricas: list[str]) -> None:
        marc = ",".join("?" * len(rubricas))
        itens = [
            (r["id"], r["valor"])
            for r in conn.execute(
                f"SELECT id, valor FROM movimento WHERE ano=? AND rubrica IN ({marc}) ORDER BY mes, id", (ano, *rubricas)
            )
        ]
        alvo = legado.pop(cod_linha, 0.0)
        ids, pago = _prefixo(itens, alvo)
        for i in ids:
            conn.execute("UPDATE movimento SET pago=1 WHERE id=?", (i,))
        ajusta(cod_linha, alvo, pago)

    por_lancamentos("receitas", calc.RECEITAS)
    for cod in calc.CUSTOS_ANTES_SS + calc.CUSTOS_FIM:
        if cod == "irs":
            continue  # o IRS segue o estado do salário
        por_lancamentos(cod, [cod])
    por_lancamentos("irc_etc", IMPOSTOS)

    # 3) salário: líquido (1 item por mês) e Estado (IRS + SS)
    meses = [m for m in range(12) if abs(v["total_salario"][m]) >= 0.005 or abs(v["irs"][m]) >= 0.005]
    alvo_liq = legado.pop("salario", 0.0)
    ids, pago_liq = _prefixo([(m, v["total_salario"][m]) for m in meses], alvo_liq)
    for m in ids:
        conn.execute(
            "INSERT INTO salario_estado (ano, mes, liquido_pago) VALUES (?,?,1) "
            "ON CONFLICT(ano, mes) DO UPDATE SET liquido_pago=1",
            (ano, m + 1),
        )
    ajusta("salario", alvo_liq, pago_liq)

    alvos = {c: legado.pop(c, 0.0) for c in LINHAS_ESTADO}
    itens = [(m, v["irs"][m] + v["ss_empresa"][m] + v["ss_colab"][m]) for m in meses]
    ids, _ = _prefixo(itens, sum(alvos.values()))
    for m in ids:
        conn.execute(
            "INSERT INTO salario_estado (ano, mes, estado_pago) VALUES (?,?,1) "
            "ON CONFLICT(ano, mes) DO UPDATE SET estado_pago=1",
            (ano, m + 1),
        )
    for c in LINHAS_ESTADO:
        ajusta(c, alvos[c], sum(v[c][m] for m in ids))

    # 4) IVA: o valor pago vem dos trimestres
    alvo_iva = legado.pop("iva", 0.0)
    pago_iva = sum(sum(v["iva"][(t - 1) * 3 : t * 3]) for t, x in d["iva_pago"].items() if x is not None)
    ajusta("iva", alvo_iva, pago_iva)

    # 5) despesas avulsas (total a retirar)
    itens = [(r["id"], r["valor"]) for r in conn.execute("SELECT id, valor FROM despesa WHERE strftime('%Y', data)=? ORDER BY data, id", (str(ano),))]
    alvo = legado.pop("retirar", 0.0)
    ids, pago = _prefixo(itens, alvo)
    for i in ids:
        conn.execute("UPDATE despesa SET pago=1 WHERE id=?", (i,))
    ajusta("retirar", alvo, pago)

    # 6) qualquer outra rubrica antiga que não case com lançamentos fica como ajuste
    for cod, alvo in legado.items():
        ajusta(cod, alvo, 0.0)

    for cod, valor in residuos.items():
        conn.execute(
            "INSERT INTO pagamento (ano, rubrica, valor, descricao) VALUES (?,?,?,?)",
            (ano, cod, valor, "Ajuste do Real vindo do Excel (sem lançamento correspondente)"),
        )
        rel["ajustes"].append((ano, cod, round(valor, 2)))


def reparar_ajustes(conn: sqlite3.Connection) -> int:
    """Bases convertidas pela 1.ª versão do estado «pago» podem ter ficado com um ajuste de despesas
    (notas de crédito, valores negativos, não eram casadas). Se um conjunto pequeno de despesas por pagar
    somar exatamente o ajuste, marca-as como pagas e retira o ajuste (assim não se conta duas vezes)."""
    from itertools import combinations

    corrigidos = 0
    for aj in conn.execute("SELECT id, ano, valor FROM pagamento WHERE rubrica='retirar'").fetchall():
        itens = conn.execute("SELECT id, valor FROM despesa WHERE pago=0 AND strftime('%Y', data)=? ORDER BY data, id", (str(aj["ano"]),)).fetchall()
        alvo = _c(aj["valor"])
        for n in (1, 2, 3):
            achado = next((c for c in combinations(itens, n) if sum(_c(x["valor"]) for x in c) == alvo), None)
            if achado:
                for x in achado:
                    conn.execute("UPDATE despesa SET pago=1 WHERE id=?", (x["id"],))
                conn.execute("DELETE FROM pagamento WHERE id=?", (aj["id"],))
                corrigidos += 1
                break
    return corrigidos
