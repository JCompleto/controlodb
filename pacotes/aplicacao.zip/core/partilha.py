"""Versão para partilhar (v1.13.0): um zip da aplicação instalada, pronto a dar a outra pessoa.

Leva o código e os ficheiros da aplicação; deixa de fora tudo o que é da empresa:
a pasta «dados» (bases, cópias, bases recentes), o modelo do Excel com os dados reais, os testes
(usam o Excel real) e o ambiente do Python. O nome da empresa por omissão passa a «A minha empresa»
e o LEIA-ME é substituído por um escrito para quem recebe.
"""
from __future__ import annotations

import zipfile
from datetime import datetime
from pathlib import Path

from .db import EMPRESA_PADRAO, RAIZ

PREFIXO = "Controlo App - para partilhar"
NOME_GENERICO = "A minha empresa"
_PASTAS_FORA = {".venv", "venv", "dados", "tests", "__pycache__", ".git", ".idea", ".vscode"}
_FICHEIROS_FORA = {"core/modelo_excel.xlsx", "LEIA-ME.md"}
_TEXTO = {".py", ".html", ".js", ".css", ".md", ".txt", ".bat", ".json"}


class ErroPartilha(ValueError):
    """Mensagem pensada para o utilizador."""


def _entra(rel: Path) -> bool:
    if any(p in _PASTAS_FORA for p in rel.parts):
        return False
    if rel.as_posix() in _FICHEIROS_FORA:
        return False
    if len(rel.parts) == 1 and rel.suffix.lower() in (".zip", ".db", ".bak", ".tmp"):
        return False  # zips anteriores e bases soltas na pasta da aplicação
    return not rel.name.endswith((".pyc", ".db-journal", ".db-wal", ".db-shm"))


def existentes(pasta: Path = RAIZ) -> list[dict]:
    """Zips já criados, do mais antigo para o mais recente (pela data do ficheiro, não pelo nome)."""
    out = []
    for f in pasta.glob(f"{PREFIXO}*.zip"):
        st = f.stat()
        out.append({"nome": f.name, "caminho": f, "kb": max(1, st.st_size // 1024), "mtime": st.st_mtime,
                    "quando": datetime.fromtimestamp(st.st_mtime).strftime("%d/%m/%Y %H:%M")})
    out.sort(key=lambda z: z["mtime"])
    return out


def criar(versao: str, nomes_proibidos: list[str], pasta: Path = RAIZ) -> tuple[Path, list[str]]:
    """Cria o zip na pasta da aplicação (apaga os anteriores) e devolve o caminho.
    Recusa-se a criar se algum ficheiro ainda tiver um dos nomes proibidos (ex.: o nome da empresa).
    Devolve também os zips antigos que não se conseguiram apagar (numa pasta do Google Drive pode acontecer)."""
    proibidos = [n for n in {*(nomes_proibidos or []), EMPRESA_PADRAO} if n and n.strip() and n != NOME_GENERICO]
    destino = pasta / f"{PREFIXO} v{versao}.zip"
    tmp = destino.with_suffix(".tmp")
    raiz_zip = "Controlo App"
    try:
        with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
            for p in sorted(RAIZ.rglob("*")):
                if not p.is_file():
                    continue
                rel = p.relative_to(RAIZ)
                if not _entra(rel):
                    continue
                if p.suffix.lower() in _TEXTO:
                    texto = p.read_text(encoding="utf-8")
                    if rel.as_posix() == "core/db.py":
                        texto = texto.replace(f'EMPRESA_PADRAO = "{EMPRESA_PADRAO}"', f'EMPRESA_PADRAO = "{NOME_GENERICO}"')
                    for n in proibidos:
                        if n.lower() in texto.lower():
                            raise ErroPartilha(f"Não criei o zip: o ficheiro «{rel.as_posix()}» ainda tem «{n}».")
                    z.writestr(f"{raiz_zip}/{rel.as_posix()}", texto)
                else:
                    z.write(p, f"{raiz_zip}/{rel.as_posix()}")
            z.writestr(f"{raiz_zip}/LEIA-ME.md", (RAIZ / "core" / "partilha_leiame.md").read_text(encoding="utf-8"))
        tmp.replace(destino)
    finally:
        tmp.unlink(missing_ok=True)
    ficaram = []
    for antigo in existentes(pasta):  # só depois de o novo estar no sítio
        if antigo["caminho"].name != destino.name:
            try:
                antigo["caminho"].unlink()
            except OSError:
                pass
            if antigo["caminho"].exists():
                ficaram.append(antigo["nome"])
    return destino, ficaram
