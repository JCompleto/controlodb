"""Simulação: confronta o «Mapa de Exploração» da contabilidade com os valores lançados na aplicação.

Só lê o ficheiro (valores já calculados, nunca executa macros) e não grava nada.
"""
from __future__ import annotations

import re
import sqlite3
import unicodedata

import openpyxl

from . import calc

TOLERANCIA = 0.05  # € por mês (arredondamentos)
MESES_COL = range(3, 15)  # colunas C..N = Jan..Dez


class ErroMapa(ValueError):
    """Mensagem pensada para o utilizador."""


def _norm(s) -> str:
    return unicodedata.normalize("NFKD", str(s or "")).encode("ascii", "ignore").decode().lower().strip()


def ler_mapa(caminho) -> dict:
    try:
        wb = openpyxl.load_workbook(caminho, data_only=True, keep_vba=False)
    except Exception as e:  # noqa: BLE001 - ficheiro inválido
        raise ErroMapa(f"Não consegui abrir o ficheiro: {e}") from None
    folha = next((ws for ws in wb.worksheets if "explora" in _norm(ws.title)), None)
    if folha is None:
        raise ErroMapa("Não encontrei a folha «Mapa de exploração» neste ficheiro.")
    ano = None
    for r in range(1, 6):
        m = re.search(r"\bano\s*:?\s*(\d{4})", _norm(folha.cell(r, 1).value))
        if m:
            ano = int(m.group(1))
            break
    if ano is None:
        raise ErroMapa("Não encontrei o ano (esperava «Ano: 2026» no topo da folha).")
    contas: dict[str, dict] = {}
    for r in range(4, folha.max_row + 1):
        a, b = folha.cell(r, 1).value, folha.cell(r, 2).value
        if isinstance(a, (int, float)) and not isinstance(a, bool):
            chave, nome = str(int(a)), str(b or "").strip()
        elif a and not b and any(isinstance(folha.cell(r, c).value, (int, float)) for c in MESES_COL):
            chave, nome = _norm(a), str(a).strip()
        else:
            continue
        valores = [folha.cell(r, c).value for c in MESES_COL]
        contas[chave] = {"nome": nome, "valores": [float(x) if isinstance(x, (int, float)) else 0.0 for x in valores],
                         "vazio": all(x is None for x in valores)}
    base = contas.get("72")
    if base is None or base["vazio"]:
        raise ErroMapa("A folha não tem valores calculados (a conta 72 está vazia). Abra o ficheiro no Excel, grave-o e carregue-o outra vez.")
    contas["_titulo"] = {"nome": str(folha.cell(1, 1).value or "").strip()}
    return {"ano": ano, "contas": contas, "resumo": _ler_resumo(wb)}


def _procura(ws, rotulo: str, col_rotulo: int, col_valor: int, inicio: bool = True):
    """Valor numérico da primeira linha cujo rótulo (normalizado) começa por / é `rotulo`."""
    alvo = _norm(rotulo)
    for r in range(1, ws.max_row + 1):
        t = _norm(ws.cell(r, col_rotulo).value)
        if t and (t.startswith(alvo) if inicio else t == alvo):
            v = ws.cell(r, col_valor).value
            if isinstance(v, (int, float)) and not isinstance(v, bool):
                return float(v)
    return None


def _folha(wb, *partes):
    return next((ws for ws in wb.worksheets if all(p in _norm(ws.title) for p in partes)), None)


def _ler_resumo(wb) -> dict:
    """Lucro e imposto estimados pela contabilidade (folhas «DR por naturezas», «Q10 - RG», «TA», «Pag Conta»). Tudo opcional."""
    out: dict = {}
    dr = _folha(wb, "dr")
    if dr:
        out["rai"] = _procura(dr, "Resultado antes de impostos", 1, 3)
        out["imposto_dr"] = _procura(dr, "Imposto sobre o rendimento", 1, 3)
        out["resultado_liquido"] = _procura(dr, "Resultado liquido", 1, 3)
        out["depreciacoes"] = _procura(dr, "Gastos/reversoes de depreciacao", 1, 3)
        mes = dr.cell(2, 3).value
        out["periodo"] = str(mes).strip() if mes else ""
    q = _folha(wb, "q10")
    if q:
        base = _procura(q, "Imposto a taxa normal - <", 2, 5)
        out["materia_coletavel"] = base
        out["irc"] = _procura(q, "Imposto a taxa normal - <", 2, 6)
        out["derrama"] = _procura(q, "Derrama municipal", 2, 6)
        out["ta"] = _procura(q, "Tributacoes Autonomas", 2, 6)
        out["ppc"] = _procura(q, "Pagamentos por conta", 2, 6)
        out["estimativa_imposto"] = _procura(q, "Estimativa de Imposto", 2, 7)
        out["a_pagar"] = _procura(q, "TOTAL A PAGAR", 2, 7)
        out["a_recuperar"] = _procura(q, "TOTAL A RECUPERAR", 2, 7)
        out["taxa_irc"] = (out["irc"] / base) if base and out.get("irc") is not None else None
    ta = _folha(wb, "ta")
    if ta and ta.title.strip().lower() == "ta":
        out["ta_repr"] = _procura(ta, "Despesas de representacao", 2, 6)
        out["ta_viaturas"] = _procura(ta, "Encargos com Viaturas", 2, 6)
    return {k: v for k, v in out.items() if v is not None}


def _valores_app(conn: sqlite3.Connection, ano: int) -> dict[str, list[float]]:
    d = calc.carregar_ano(conn, ano)
    v = calc.calcular_mapa(d)["v"]
    k = 1 + d["cfg"]["iva"]
    z = [0.0] * 12
    desp = lambda nome: v.get(f"desp:{nome}", z)  # noqa: E731
    soma = lambda *ls: [sum(x) for x in zip(*ls)]  # noqa: E731
    rec = [(v["avenca"][i] + v["extra"][i] + v["premio"][i]) / k + v["isento"][i] for i in range(12)]
    rem = soma(v["vencimento"], v["isencao"], v["sub_ferias"], v["sub_natal"], v["sub_alim"])
    banc = soma(v["man_conta"], v["custos_banc"])
    fse = soma([x / k for x in v["contabilista"]], v["man_conta"], v["mcontab_conta"], v["luz"], v["custos_banc"], v["renda"],
               v["carro"], v["outras"], v["total_desp"])
    pessoal = soma(rem, v["ss_empresa"])
    return {
        "72": rec, "63": pessoal, "631": rem, "63111": soma(v["vencimento"], v["isencao"]), "63112": v["sub_ferias"],
        "63113": v["sub_natal"], "63114": v["sub_alim"], "635": v["ss_empresa"],
        "6221": [x / k for x in v["contabilista"]], "6228": banc, "6242": desp("Combustível"), "6266": desp("Restauração"),
        "62": fse, "gastos": soma(fse, pessoal), "rendimentos": rec,
        "kmaj": soma(v["kms"], v["ajudas"]),
    }


def _lucro_imposto(conn: sqlite3.Connection, ano: int, ate: int, mapa: dict) -> dict:
    """Lucro e imposto da aplicação até ao mês `ate` (0-11), com o mesmo método do Painel."""
    d = calc.carregar_ano(conn, ano)
    m = calc.calcular_mapa(d)
    v, cfg = m["v"], d["cfg"]
    n = ate + 1
    iva_ganho = sum(t["devolvido"] for t in calc.iva_trimestres(d, m) if t["trimestre"] * 3 <= n)
    rgd = sum(v["rend_gastos_desp"][:n])
    lucro = rgd + iva_ganho
    k = 1 + cfg["iva"]
    iva_pend = [t["trimestre"] for t in calc.iva_trimestres(d, m) if t["trimestre"] * 3 <= n and t["pago"] is None and t["estimativa"] > 0.005]
    iva_contab = sum(v["contabilista"][:n]) - sum(x / k for x in v["contabilista"][:n])
    ta_info = calc.tributacoes_autonomas(v, cfg, n)
    ta = ta_info["total"]
    irc = max(lucro, 0.0) * cfg["irc_taxa"]
    ppc = sum(d["inp"]["pag_conta"])
    lancados = sum(d["imp"].values())
    return {"lucro": lucro, "lancados": lancados, "lucro_depois": lucro - lancados, "ppc_lancado": d["imp"]["pag_conta"], "iva_ganho": iva_ganho, "iva_contab": iva_contab, "iva_pendentes": iva_pend, "ta": ta, "ta_info": ta_info, "irc": irc, "irc_taxa": cfg["irc_taxa"], "ppc": ppc,
            "ppc_pagos": sum(d["inp_pago"]["pag_conta"]), "irc_lancado": sum(d["inp"]["irc"]), "total": irc + ta - ppc}


# (conta, descrição, exata?, nível de indentação, chave da app, chave no mapa da contabilidade)
LINHAS = [
    ("72", "Prestações de serviços (faturação sem IVA)", True, 0, "72", "72"),
    ("63", "Gastos com o pessoal", True, 0, "63", "63"),
    ("631", "Remunerações dos órgãos sociais", True, 1, "631", "631"),
    ("63111", "Salários (vencimento + isenção de horário)", True, 2, "63111", "63111"),
    ("63112", "Subsídio de férias", True, 2, "63112", "63112"),
    ("63113", "Subsídio de Natal", True, 2, "63113", "63113"),
    ("63114", "Subsídio de refeição", True, 2, "63114", "63114"),
    ("635", "Encargos sobre remunerações (SS empresa)", True, 1, "635", "635"),
    ("6221", "Trabalhos especializados (contabilista, sem IVA)", True, 0, "6221", "6221"),
    ("6228", "Serviços bancários + outros gastos (6228 + 68)", True, 0, "6228", ("6228", "68")),
    ("6242", "Combustíveis", True, 0, "6242", "6242"),
    ("6266", "Despesas de representação (restauração)", True, 0, "6266", "6266"),
    ("62", "FSE — total (informativo)", False, 0, "62", "62"),
    ("gastos", "Total de compras e gastos (informativo)", False, 0, "gastos", "total de compras e gastos"),
]
NOTAS_INFO = {
    "62": "Os custos da aplicação (renda, carro, outras despesas…) vêm normalmente com IVA, e a contabilidade lança-os sem IVA e reparte-os por contas. Diferenças aqui são esperadas.",
    "gastos": "A contabilidade inclui depreciações (conta 64) e outros gastos (68), que a aplicação não tem.",
}


def comparar(conn: sqlite3.Connection, mapa: dict) -> dict:
    ano = mapa["ano"]
    if ano not in [r[0] for r in conn.execute("SELECT ano FROM config_ano")]:
        raise ErroMapa(f"O ano {ano} ainda não existe na aplicação (crie-o em Configurações).")
    app = _valores_app(conn, ano)
    contas = mapa["contas"]
    # meses cobertos: aqueles em que a contabilidade tem movimento
    ref = [contas.get("total de compras e gastos", {"valores": [0] * 12})["valores"], contas["72"]["valores"]]
    cobertos = [i for i in range(12) if any(abs(r[i]) > 0.005 for r in ref)]
    if not cobertos:
        raise ErroMapa("O mapa não tem movimento em nenhum mês.")
    linhas = []
    for conta, nome, exata, nivel, k_app, k_cont in LINHAS:
        chaves = (k_cont,) if isinstance(k_cont, str) else k_cont
        partes = [contas.get(k) for k in chaves]
        if partes[0] is None:
            continue
        c = {"valores": [sum(p["valores"][i] for p in partes if p) for i in range(12)]}
        meses = []
        for i in cobertos:
            a, b = round(app[k_app][i], 2), round(c["valores"][i], 2)
            meses.append({"mes": i, "contab": b, "app": a, "dif": round(a - b, 2), "ok": abs(a - b) <= TOLERANCIA})
        tot_c = round(sum(m["contab"] for m in meses), 2)
        tot_a = round(sum(m["app"] for m in meses), 2)
        linhas.append({"conta": conta, "nome": nome, "exata": exata, "nivel": nivel, "meses": meses, "tot_contab": tot_c,
                       "tot_app": tot_a, "tot_dif": round(tot_a - tot_c, 2), "ok": all(m["ok"] for m in meses),
                       "nota": NOTAS_INFO.get(conta)})
    # resultado: rendimentos - gastos (com as duas fontes)
    rai_c = contas.get("resultado de exploracao (rai)")
    rai = None
    if rai_c:
        meses = []
        for i in cobertos:
            a, b = round(app["rendimentos"][i] - app["gastos"][i], 2), round(rai_c["valores"][i], 2)
            meses.append({"mes": i, "contab": b, "app": a, "dif": round(a - b, 2), "ok": abs(a - b) <= TOLERANCIA})
        rai = {"conta": "RAI", "nome": "Resultado de exploração (informativo)", "exata": False, "nivel": 0, "meses": meses,
               "tot_contab": round(sum(m["contab"] for m in meses), 2), "tot_app": round(sum(m["app"] for m in meses), 2),
               "ok": all(m["ok"] for m in meses), "nota": "Soma das diferenças acima: é o efeito de IVA, depreciações e classificação dos custos."}
        rai["tot_dif"] = round(rai["tot_app"] - rai["tot_contab"], 2)
        linhas.append(rai)
    lucro = _bloco_lucro(conn, mapa, app, linhas, cobertos)
    exatas = [l for l in linhas if l["exata"]]
    return {"ano": ano, "linhas": linhas, "meses": cobertos, "n_exatas": len(exatas), "n_ok": sum(1 for l in exatas if l["ok"]),
            "lucro": lucro, "elaborado": contas.get("_titulo", {}).get("nome", ""), "kmaj": round(sum(app["kmaj"][i] for i in cobertos), 2)}


def _bloco_lucro(conn, mapa, app, linhas, cobertos) -> dict | None:
    """Lucro até ao mês de leitura e imposto estimado: contabilidade vs aplicação (com a ponte entre os dois)."""
    r = mapa.get("resumo", {})
    ate = cobertos[-1]
    ano = mapa["ano"]
    ap = _lucro_imposto(conn, ano, ate, mapa)
    contas = mapa["contas"]
    n = ate + 1
    rai_ct = r.get("rai")
    if rai_ct is None and "resultado de exploracao (rai)" in contas:
        rai_ct = sum(contas["resultado de exploracao (rai)"]["valores"][:n])
    out: dict = {"mes": ate, "app": ap, "ct": r, "rai_ct": rai_ct}
    if rai_ct is None:
        return out
    por = {l["conta"]: l for l in linhas}
    exatas_fse = [por[c] for c in ("6221", "6228", "6242", "6266") if c in por]
    a_eff = round(sum(l["tot_app"] - l["tot_contab"] for l in exatas_fse), 2)
    deprec = abs(r.get("depreciacoes", contas.get("64", {}).get("valores") and sum(contas["64"]["valores"][:n]) or 0.0))
    l_sim = round(sum(app["rendimentos"][i] - app["gastos"][i] for i in range(n)), 2)
    # O «IVA ganho» da aplicação é o IVA dos custos que o Estado devolveu (IVA estimado das vendas − IVA realmente pago).
    # Já está dentro do lucro do Painel e torna os custos «sem IVA», como na contabilidade.
    passos = [("Lucro antes de impostos da aplicação (já inclui o IVA recuperado nos custos: «IVA ganho»)", round(ap["lucro"], 2), "total")]
    a_eff = round(a_eff, 2)
    passos.append(("Linhas conferidas que diferem (combustíveis, bancários…)", a_eff, ""))
    passos.append(("Depreciações que só a contabilidade tem (conta 64)", round(-deprec, 2), ""))
    resto = round(rai_ct - ap["lucro"] - a_eff + deprec, 2)
    passos.append(("Outras diferenças (IVA dedutível real vs estimado, classificação dos custos…)", resto, ""))
    passos.append(("Resultado antes de impostos da contabilidade", round(rai_ct, 2), "total"))
    out["iva_pendentes"] = ap["iva_pendentes"]
    out["passos"] = passos
    out["l_sim"] = l_sim
    # imposto
    linhas_imp = []

    def linha(nome, ct, app_v, nota="", exata=False):
        dif = None if ct is None or app_v is None else round(app_v - ct, 2)
        linhas_imp.append({"nome": nome, "ct": ct, "app": app_v, "dif": dif, "nota": nota, "exata": exata,
                           "ok": dif is not None and abs(dif) <= TOLERANCIA})

    taxa_ct = r.get("taxa_irc")
    linha("Lucro / resultado antes de impostos", rai_ct, round(ap["lucro"], 2), "Ver a ponte acima.")
    linha("IRC (colecta)", r.get("irc"), round(ap["irc"], 2),
          f"Taxa da contabilidade {taxa_ct * 100:.1f} % · taxa da aplicação {ap['irc_taxa'] * 100:.1f} % (Configurações). A contabilidade aplica-a à matéria coletável dela." if taxa_ct else "")
    linha("Derrama municipal", r.get("derrama"), 0.0, "A aplicação ainda não estima a derrama municipal.")
    linha("Tributações autónomas (total)", r.get("ta"), round(ap["ta"], 2), "Soma das três linhas seguintes.")
    ct_cat = {"repr": r.get("ta_repr"), "viaturas": r.get("ta_viaturas"), "deslocacoes": None}
    for l in ap["ta_info"]["linhas"]:
        linha(f"· {l['nome']}", ct_cat[l["chave"]], round(l["valor"], 2),
              f"{l['base']:,.2f} € × {l['taxa'] * 100:.1f} %".replace(",", " ").replace(".", ",") + (
                  " — taxa de viaturas das Configurações; a contabilidade usa os encargos dela (depreciações, seguros, combustível…)" if l["chave"] == "viaturas" else ""))
        linhas_imp[-1]["sub"] = True
    linha("Pagamentos por conta já feitos", r.get("ppc"), round(ap["ppc"], 2), "Deve bater certo.", exata=True)
    ct_total = None
    if r.get("a_pagar") is not None or r.get("a_recuperar") is not None:
        ct_total = (r.get("a_pagar") or 0.0) + (r.get("a_recuperar") or 0.0)  # a recuperar vem negativo
    linha("Total a pagar (+) / a recuperar (−)", ct_total, round(ap["total"], 2), "Imposto estimado menos pagamentos por conta.")
    out["imposto"] = linhas_imp
    return out
