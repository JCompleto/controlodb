"""Ecrãs próprios da versão telemóvel (v1.19.7), ao estilo de uma app de banco.

Só são usados quando a aplicação corre no iPhone (CONTROLO_TELEMOVEL): no PC estas rotas existem mas nada
liga para elas. As contas são sempre as da aplicação do PC (as mesmas funções), por isso os valores batem certo.

Barra em baixo: Início · Movimentos · + · Mês · Mais. Os formulários e a ficha de cada lançamento são os do PC,
com o aspeto do telemóvel (ver base.html e static/telemovel.css).
"""
from __future__ import annotations

from datetime import date

from flask import redirect, render_template, request, url_for

from core import socio
from core.calc import CUSTOS_ANTES_SS, CUSTOS_FIM, MESES, RECEITAS, SALARIO_ENTRADAS, SALDO_LINHAS, calcular_saldo

FILTROS_M = [("tudo", "Tudo"), ("porpagar", "Por pagar"), ("faturas", "Faturas"), ("despesas", "Despesas"),
             ("salarios", "Salários"), ("custos", "Custos"), ("impostos", "Impostos")]
LETRA = {"fatura": "F", "salario": "S", "custo": "C", "imposto": "§", "iva": "%", "despesa": "D", "tesouraria": "T"}
# páginas do PC que, no telemóvel, têm um ecrã próprio
SUBSTITUIR = {"painel": "m_inicio", "lancamentos": "m_movimentos", "socio_view": "m_socio", "saldo": "m_impostos", "mapa": "m_mes"}
_IVA_PRAZO = {1: (0, 5), 2: (0, 8), 3: (0, 11), 4: (1, 2)}  # trimestre -> (anos a somar, mês) do pagamento, até dia 25


def registar(app, h: dict) -> None:
    """Regista as rotas do telemóvel. `h` são as funções e constantes do app.py (o mesmo código do PC)."""
    db, exigir_ano, construir_itens = h["db"], h["exigir_ano"], h["construir_itens"]
    ETIQUETA = h["ETIQUETA"]

    if h["TELEMOVEL"]:
        @app.before_request
        def _ecras_telemovel():
            """No telemóvel, Painel, Lançamentos, Sócio, Saldo e Mapa abrem os ecrãs próprios (com os mesmos filtros)."""
            alvo = SUBSTITUIR.get(request.endpoint or "")
            if not alvo or request.method != "GET" or request.args.get("pc"):
                return None
            a = request.args
            kw = {"ano": a.get("ano")}
            if alvo == "m_movimentos":
                tipo = a.get("tipo", "tudo")
                kw.update(f=tipo if tipo in dict(FILTROS_M) else "tudo", mes=a.get("mes"), rubrica=a.get("rubrica"), tdesp=a.get("tdesp"))
            return redirect(url_for(alvo, **{k: v for k, v in kw.items() if v}))

    def _estado_linha(i: dict) -> dict:
        """Etiqueta do estado de um lançamento: a primeira parte por pagar ou, se tudo pago, a confirmação."""
        falta = [e for e in i["estado"] if not e["pago"]]
        if not falta:
            e = i["estado"][-1]
            return {"txt": "✓ " + e["sim"], "cls": "ok"}
        e = falta[0]
        if i.get("socio"):
            return {"txt": "A reembolsar", "cls": "sc"}  # «Por reembolsar ao sócio» é comprido demais para a linha
        elif i["kind"] == "fatura" or i.get("entrada"):
            cls = "rc"
        else:
            cls = "pp"
        return {"txt": e["nao"] + (f" +{len(falta) - 1}" if len(falta) > 1 else ""), "cls": cls}

    def _linha(i: dict, ano: int) -> dict:
        quando = f"{i['data'][8:10]}/{i['data'][5:7]}" if i.get("data") else MESES[i["mes"] - 1]
        entrada = i["kind"] == "fatura" or i.get("entrada")
        return {**i, "url": h["_url_item"](i, ano), "letra": LETRA.get(i["kind"], "·"), "quando": quando,
                "etiqueta": ETIQUETA.get(i["kind"], ""), "entrada": entrada, "st": _estado_linha(i)}

    # ------------------------------------------------------------------ Início
    @app.route("/m/")
    def m_inicio():
        ano = exigir_ano()
        s = calcular_saldo(db(), ano)
        por_pagar = construir_itens(ano, "porpagar", None, "", "")
        pend = h["_pend_painel"](por_pagar)
        det = h["_detalhe_pendentes"](por_pagar)
        tri = h["_lucro_por_trimestre"](ano)
        maior = max([abs(q["lucro"]) for q in tri if q["lucro"] is not None] + [1.0])
        for q in tri:
            q["alt"] = 0 if q["lucro"] is None else max(6, round(48 * abs(q["lucro"]) / maior))
        prazos = [p for p in h["_prazos"](ano) if not p["pago"]][:4]
        return render_template("m_inicio.html", aba="inicio", s=s, im=s["imposto"], pend=pend, n_receber=len(det["receber"]),
                               n_pagar=len(det["terceiros"]), n_socio=len(det["socio"]), tri=tri, irc=h["_irc_do_ano"](ano, s["imposto"]),
                               prazos=prazos, em_falta=h["_em_falta"](ano), fechado=ano < date.today().year)

    # ------------------------------------------------------------------ Movimentos
    @app.route("/m/movimentos")
    def m_movimentos():
        ano = exigir_ano()
        f = request.args.get("f", "tudo")
        f = f if f in dict(FILTROS_M) else "tudo"
        mes = request.args.get("mes", type=int)
        mes = mes if mes and 1 <= mes <= 12 else None
        rubrica, tdesp = request.args.get("rubrica", ""), request.args.get("tdesp", "")
        q = (request.args.get("q") or "").strip()
        itens = construir_itens(ano, "despesas" if tdesp else f, mes, rubrica, tdesp)
        if q:
            ql = q.lower()
            itens = [i for i in itens if ql in (i["titulo"] + " " + (i.get("detalhe") or "")).lower()]
        grupos: list[dict] = []
        for i in itens:
            if not grupos or grupos[-1]["mes"] != i["mes"]:
                grupos.append({"mes": i["mes"], "nome": MESES[i["mes"] - 1], "linhas": []})
            grupos[-1]["linhas"].append(_linha(i, ano))
        nomes = h["_nomes_rubricas"]()
        filtro_extra = None
        if mes or rubrica or tdesp:
            partes = [MESES[mes - 1] if mes else None, nomes.get(rubrica) if rubrica else None, tdesp or None]
            filtro_extra = " · ".join(p for p in partes if p)
        return render_template("m_movimentos.html", aba="movimentos", grupos=grupos, filtros=FILTROS_M, f=f, q=q, n=len(itens),
                               mes=mes, rubrica=rubrica, tdesp=tdesp, filtro_extra=filtro_extra)

    # ------------------------------------------------------------------ + (o que quer lançar?)
    @app.route("/m/novo")
    def m_novo():
        ano = exigir_ano()
        recentes = []
        vistos = set()
        for r in db().execute("SELECT data, valor, descricao, tipo, pago_por FROM despesa ORDER BY data DESC, id DESC LIMIT 40"):
            chave = (r["tipo"], r["descricao"] or "", r["pago_por"] or "socio")
            if chave in vistos:
                continue
            vistos.add(chave)
            recentes.append({"nome": (r["descricao"] or r["tipo"]) + (" · pago pelo sócio" if (r["pago_por"] or "socio") == "socio" else ""),
                             "valor": r["valor"],
                             "url": url_for("lancamento_form", tipo="despesa", ano=ano, d_tipo=r["tipo"], d_desc=r["descricao"] or "",
                                            d_valor=f"{r['valor']:.2f}".replace(".", ","), d_por=r["pago_por"] or "socio")})
            if len(recentes) == 3:
                break
        return render_template("m_novo.html", aba="novo", em_falta=h["_em_falta"](ano), recentes=recentes)

    # ------------------------------------------------------------------ Mês (substitui o mapa mensal)
    @app.route("/m/mes")
    def m_mes():
        ano = exigir_ano()
        hoje = date.today()
        mes = request.args.get("mes", type=int)
        if not mes or not 1 <= mes <= 12:
            mes = hoje.month if hoje.year == ano else 12
        s = calcular_saldo(db(), ano)
        m = s["mapa"]
        v = m["v"]
        i = mes - 1
        nome = {l["codigo"]: l["nome"] for l in m["linhas"] if l.get("codigo")}

        def filhos(codigos, link=True):
            out = []
            for c in codigos:
                x = v.get(c, [0.0] * 12)[i]
                if abs(x) >= 0.005:
                    out.append({"nome": nome.get(c, c), "valor": x,
                                "url": url_for("m_movimentos", ano=ano, mes=mes, rubrica=c) if link else None})
            return out

        grupos = []
        fat = filhos(RECEITAS)
        if fat:
            grupos.append({"nome": "Faturação", "valor": v["receitas"][i], "filhos": fat, "entrada": True, "aberto": True})
        sal = filhos(SALARIO_ENTRADAS) + [{"nome": "IRS + SS retidos", "valor": v["irs_ss"][i], "url": None}] if abs(v["total_salario"][i]) >= 0.005 else []
        if sal:
            grupos.append({"nome": "Salário", "valor": v["total_salario"][i], "filhos": sal,
                           "url": url_for("lancamento_form", tipo="salario", ano=ano, mes=mes)})
        if abs(v["iva"][i]) >= 0.005:
            grupos.append({"nome": "IVA", "valor": v["iva"][i], "filhos": [], "url": url_for("m_impostos", ano=ano)})
        custos = filhos(CUSTOS_ANTES_SS + CUSTOS_FIM)
        if custos:
            grupos.append({"nome": "Custos", "valor": sum(c["valor"] for c in custos), "filhos": custos})
        ss = v["ss_empresa"][i] + v["ss_colab"][i]
        if abs(ss) >= 0.005:
            grupos.append({"nome": "Segurança Social", "valor": ss, "filhos": [
                {"nome": "SS empresa", "valor": v["ss_empresa"][i], "url": None}, {"nome": "SS colaborador", "valor": v["ss_colab"][i], "url": None}]})
        desp = []
        for c in [c for c in v if c.startswith("desp:")]:
            x = v[c][i]
            if abs(x) >= 0.005:
                desp.append({"nome": c.split(":", 1)[1], "valor": x,
                             "url": url_for("m_movimentos", ano=ano, mes=mes, f="despesas", tdesp=c.split(":", 1)[1])})
        if desp:
            grupos.append({"nome": "Despesas avulsas", "valor": v["total_desp"][i], "filhos": desp})
        resultado = v["rend_gastos_desp"][i]
        anterior = v["rend_gastos_desp"][i - 1] if i > 0 else None
        delta = None
        if anterior is not None and abs(anterior) >= 1 and (abs(v["receitas"][i]) >= 0.005 or abs(resultado) >= 0.005):
            delta = round(100 * (resultado - anterior) / abs(anterior))
        ate = sum(v["rend_gastos_desp"][:mes])
        meses = [{"n": k + 1, "nome": MESES[k], "tem": abs(v["receitas"][k]) >= 0.005 or abs(v["rend_gastos_desp"][k]) >= 0.005}
                 for k in range(12)]
        return render_template("m_mes.html", aba="mes", mes=mes, nome_mes=MESES_LONGOS[i], grupos=grupos, entradas=v["receitas"][i],
                               saidas=v["receitas"][i] - resultado, resultado=resultado, delta=delta, ate=ate, meses=meses,
                               ant=mes - 1 if mes > 1 else None, seg=mes + 1 if mes < 12 else None)

    # ------------------------------------------------------------------ Sócio
    @app.route("/m/socio")
    def m_socio():
        ano = exigir_ano()
        con = db()
        r = socio.resumo_ano(con, ano)
        ct = socio.contabilidade(con, ano)
        comp = None
        if ct:
            dia = ct["data"] or date.today().isoformat()
            app_v = h["_saldo_em"](socio.movimentos(con), dia)
            comp = {"app": app_v, "dif": round(app_v - ct["valor"], 2), "dia": dia}
        antiga = r["pendentes"][0]["data"] if r["pendentes"] else None
        return render_template("m_socio.html", aba="mais", r=r, ct=ct, comp=comp, antiga=antiga, hoje_iso=date.today().isoformat())

    # ------------------------------------------------------------------ Impostos e saldo
    @app.route("/m/impostos")
    def m_impostos():
        ano = exigir_ano()
        s = calcular_saldo(db(), ano)
        hoje = date.today()
        trims = []
        for t in s["iva_trimestres"]:
            soma, mm = _IVA_PRAZO[t["trimestre"]]
            prazo = date(ano + soma, mm, 25)
            terminado = h["_trimestre_terminado"](ano, t["trimestre"])
            comecado = h["_trimestre_comecado"](ano, t["trimestre"])
            if t["pago"] is not None:
                st = {"txt": "Pago", "cls": "ok"}
            elif terminado:
                st = {"txt": f"até {prazo.day} {MESES[prazo.month - 1].lower()}", "cls": "pp" if prazo >= hoje else "at"}
            elif comecado:
                st = {"txt": "Em curso", "cls": "nt"}
            else:
                st = {"txt": "—", "cls": "nt"}
            trims.append({**t, "valor": t["pago"] if t["pago"] is not None else t["estimativa"], "st": st,
                          "url": url_for("lancamento_form", tipo="iva", id=t["trimestre"], ano=ano)})
        maior = max([abs(t["valor"]) for t in trims] + [1.0])
        for t in trims:
            t["larg"] = round(100 * abs(t["valor"]) / maior)
        dif = []
        if abs(s["est"]["receitas"] - s["real"]["receitas"]) >= 0.005:
            dif.append({"nome": "Faturas por receber", "valor": s["est"]["receitas"] - s["real"]["receitas"], "entrada": True})
        for cod, nome_l in SALDO_LINHAS:
            x = s["est"]["linhas"][cod] - s["real"]["linhas"][cod]
            if abs(x) >= 0.005:
                dif.append({"nome": nome_l, "valor": -x, "entrada": False})
        return render_template("m_impostos.html", aba="mais", s=s, im=s["imposto"], irc=h["_irc_do_ano"](ano, s["imposto"]), trims=trims, dif=dif)

    # ------------------------------------------------------------------ Mais
    @app.route("/m/mais")
    def m_mais():
        ano = exigir_ano()
        r = socio.resumo_ano(db(), ano)
        return render_template("m_mais.html", aba="mais", divida=r["atual"])


MESES_LONGOS = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"]
